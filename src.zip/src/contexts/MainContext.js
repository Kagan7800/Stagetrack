const MainContext = React.createContext();

const MainContextProvider = ({ children }) => {

    const [allSongs, setAllSongs] = React.useState([]);
    const [allBands, setAllBands] = React.useState([]);
    const [allNotes, setAllNotes] = React.useState([]);
    const [allResources, setAllResources] = React.useState([]);
    const [openedResource, setOpenedResource] = React.useState(null);
    const [ybMode, setYbMode] = React.useState("NOTES") // IMAGE, DOC, WHITEBOARD
    const [activeBand, setActiveBand] = React.useState(null);
    const [thisUserProfile, setThisUserProfile] = React.useState(null);

    const [bandData, setBandData] = React.useState(null);


    const [newTracks, setNewTracks] = React.useState([]);
    const [newVideos, setNewVideos] = React.useState([]);
    const [allVideos, setAllVideos] = React.useState([]);
    const [videosToAdd, setVideosToAdd] = React.useState([]);
    const [newSongVideoBlob, setNewSongVideoBlob] = React.useState(null);
    const [audioRecordMenu, setAudioRecordMenu] = React.useState(false);
    const [isVideoRecording, setIsVideoRecording] = React.useState(false);
    const [selectedPlaylistAction, setSelectedPlaylistAction] = React.useState(null);
    const [selectedPlaylistActionTrack, setSelectedPlaylistActionTrack] = React.useState(null);
    const [currentSongData, setCurrentSongData] = React.useState(null);
    const [thisSongId, setThisSongId] = React.useState(null);
    const [songListener, setSongListener] = React.useState(null);

    const [mediaStream, setMediaStream] = React.useState(null);
    const [userDisplayStream, setUserDisplayStream] = React.useState(null);
    const [isCalling, setIsCalling] = React.useState(false);
    const [remoteStreams, setRemoteStreams] = React.useState([]);

    const [currentPlaybackTime, setCurrentPlaybackTime] = React.useState(0);
    const [editorPlayhead, setEditorPlayhead] = React.useState(0);

    const [newAudioVideoBlob, setNewAudioVideoBlob] = React.useState({
        audio: null,
        video: null
    });

    const [drawingCanvas, setDrawingCanvas] = React.useState(null);

    //modes can be: "LOGIN", "SIGNUP", "CREATE", "EDIT"
    const [appState, setAppState] = React.useState({
        mode: 'LOGIN',
        loading: false
    });

    const [authState, setAuthState] = React.useState({
        signedIn: false,
        user: null,
    });

    const [songState, setSongState] = React.useState({
        song: null,
        isUserAdmin: false,
    });

    const updateAppState = (update) => {
        setAppState({ ...Object.assign(appState, update) });
    }
    const updateAuthState = (update) => {
        setAuthState({ ...Object.assign(authState, update) });
    }
    const updateSongState = (update) => {
        setSongState({ ...Object.assign(songState, update) });
    }
    const updateNewAudioVideoBlob = (update) => {
        setNewAudioVideoBlob({ ...Object.assign(newAudioVideoBlob, update) });
    }

    //following code will only run once for the first mounting of this context
    React.useEffect(() => {
        
        window.setDisplay = setDisplay;
        firebase.auth().onAuthStateChanged(async (user) => {
            if (user) {
                var userProfile;
                const userProfileDoc = await db.collection('userProfiles').where("email", "==", user.email).limit(1).get();
                if(userProfileDoc.docs.length > 0) {

                    // adding snapshot listener to userProfile
                    db.collection('userProfiles').doc(userProfileDoc.docs[0].id).onSnapshot(snap => {
                        setThisUserProfile(Object.assign(snap.data(), { id: snap.id }));

                        //get list of all accessible bands
                        db.collection('bands').get().then(function(querySnapshot) {
                            const objs = [];
                            querySnapshot.forEach(function(doc) {

                                if (doc.data().createdBy == user.uid ||
                                    snap.data().joinedBands.indexOf(doc.id) !== -1
                                ) {
                                    const obj = Object.assign(doc.data(), { id: doc.id });
                                    objs.push(obj);
                                }

                            });
                            setAllBands(objs);
                        });

                    })

                    userProfile = userProfileDoc.docs[0].data();
                    setThisUserProfile(userProfile);

                    // updating profile with uid
                    if (!userProfile.uid) {
                        db.collection('userProfiles').doc(userProfileDoc.docs[0].id).update({ uid: user.uid }).then(() => {
                            console.log('user profile updated with uid');
                        });
                    }

                    // updating profile with username
                    if (!userProfile.username) {

                        const updateWithUsername = () => {

                            const generateUsername = (userProfile) => {

                                var newUsername = userProfile.firstName.toLowerCase() + userProfile.lastName.toLowerCase();
                                newUsername = newUsername.trim();

                                // removing spaces if exist
                                if (newUsername.split(' ').length > 1) {
                                    const split = newUsername.split(' ');
                                    newUsername = '';
                                    for (let s of split) {
                                        newUsername += s;
                                    }
                                }
    
                                var length = 5,
                                    charset = "0123456789",
                                    hash = "";
                                for (var i = 0, n = charset.length; i < length; ++i) {
                                    hash += charset.charAt(Math.floor(Math.random() * n));
                                }
                                newUsername += `#${hash}`
                                return newUsername;
                            }
    
                            const username = generateUsername(userProfile);
    
                            db.collection('userProfiles').where("username", "==", username).limit(1).get().then(docs => {
    
                                if (docs.docs.length == 0) {
                                    // username is unique
                                    db.collection('userProfiles').doc(userProfileDoc.docs[0].id).update({ username: username }).then(() => {
                                        console.log('user profile updated with username');
                                        return;
                                    });
                                }
                                else {
                                    // username not unique
                                    console.log('username not unique, generating new hash...')
                                    updateWithUsername();
                                }
    
                            })

                        }

                        updateWithUsername();
                        
                    }

                    //check if default band exists for this user
                    const bandDoc = await db.collection('bands').where("createdBy", "==", user.uid).limit(1).get();
                    if (bandDoc.docs.length == 0) {
                        // no default band exists, create one
                        console.log('creating band...');
                        const bandName = (`${userProfile.firstName} ${userProfile.lastName}`).trim();
                        console.log('bandName: ', bandName);
                        db.collection('bands').add({
                            name: bandName,
                            createdBy: user.uid,
                            city: "",
                            state: "",
                            zip: "",
                            website: "",
                            estb: "",
                        }).then(band => {
                            console.log('band created: ', band);
                            setBandData(band);
                        });
                    }
                    else {
                        const thisBandData = bandDoc.docs[0];
                        setBandData(thisBandData);
                    }

                }

                if (user.emailVerified) {
                    // User is signed in.

                    // get list of all songs after logging in
                    db.collection('songs').onSnapshot(function(querySnapshot) {
                        const songs = [];
                        querySnapshot.forEach(function(doc) {
                            // const obj = { id: doc.id, name: doc.data().name }
                            const obj = Object.assign(doc.data(), { id: doc.id });
                            songs.push(obj);
                        });
                        setAllSongs(songs);

                        //get list of all accessible bands
                        db.collection('bands').get().then(function(bandDocs) {
                            const bands = [];
                            bandDocs.forEach(function(doc) {

                                if (doc.data().createdBy == user.uid ||
                                    userProfile.joinedBands.indexOf(doc.id) !== -1
                                ) {
                                    const obj = Object.assign(doc.data(), { id: doc.id });
                                    bands.push(obj);
                                }

                            });
                            setAllBands(bands);
                        });
                        
                    });

                    // get list of all resources after logging in
                    db.collection('resources').onSnapshot(function(querySnapshot) {
                        const resources = [];
                        querySnapshot.forEach(function(doc) {
                            // const obj = { id: doc.id, name: doc.data().name }
                            const obj = Object.assign(doc.data(), { id: doc.id });
                            resources.push(obj);
                        });
                        setAllResources(resources);
                        
                    });

                    updateAuthState({ signedIn: true, user: firebase.auth().currentUser });
                    updateAppState({ mode: "BAND" });
                } else {
                    signOut();
                    //email not verified
                    if (window.confirm('Please verify your email by clicking on the link sent to your email address')) {
                        updateAppState({ mode: "LOGIN" });
                        location.reload();
                    } else {
                        updateAppState({ mode: "LOGIN" });
                        location.reload();
                    }
                }
            } else {
                // No user is signed in.
                updateAuthState({ signedIn: false });
                updateAppState({ mode: "LOGIN" });
            }
        });

        
        playlistAction.registerListener(val => {
            setSelectedPlaylistAction(val);
        });
        playlistActionTrack.registerListener(val => {
            setSelectedPlaylistActionTrack(val);
        });


    }, []);

    //performing custom playlist actions
    React.useEffect(() => {

        if (selectedPlaylistAction == "DELETE") {
            deleteTrack(selectedPlaylistActionTrack);
            playlistAction.value = undefined;
        }

    }, [selectedPlaylistAction]);


    // ****** MAIN FUNCTIONS ************ 
    const startLoader = () => {
        updateAppState({ loading: true })
    }
    const endLoader = () => {
        updateAppState({ loading: false })
    }

    const setDisplay = (id, bool) => {
        const ele = document.getElementById(id);
        if (bool) {
            ele.style.display = 'block';
        } else {
            ele.style.display = 'none';
        }
    }

    const initPlaylist = () => {
        var newPlaylist = WaveformPlaylist.init({
            samplesPerPixel: 8000,
            waveHeight: 100,
            container: document.getElementById("playlist"),
            state: 'cursor',
            colors: {
                waveOutlineColor: '#E0EFF1',
                timeColor: 'black',
                fadeColor: 'black'
            },
            timescale: true,
            controls: {
                show: true, //whether or not to include the track controls
                width: 200 //width of controls in pixels
            },
            
            zoomLevels: [500, 1000, 3000, 5000, 6000, 7000, 8000]
        });
        
        var ee = newPlaylist.getEventEmitter();
        // ee on events
        ee.on('audiorenderingfinished', function (type, data) {
            if (type == 'wav'){
            
                const downloadUrl = window.URL.createObjectURL(data);
                //   displayDownloadLink(downloadUrl);

                
                var a = document.createElement('A');
                a.href = downloadUrl;
                a.download = downloadUrl.substr(downloadUrl.lastIndexOf('/') + 1);
                document.body.appendChild(a);
                a.click();
                document.body.removeChild(a);
            }
        });

        ee.on('select', (start, end, track) => {
            setEditorPlayhead(start);
        });
        ee.on('timeupdate', t => {
            setCurrentPlaybackTime(t);
        });

        window.playlist = newPlaylist;
        window.ee = ee;
    }

    const seekPlayback = (t) => {
        if (t < 0) t = 0;
        playlist.seek(t);
        playlist.updateEditor();
        setCurrentPlaybackTime(t);
        // setEditorPlayhead(t);
        
    }

    // Band functions
    const createBand = async (band, createdBy) => {
        startLoader();
        var bandDoc;

        db.collection('bands').add(Object.assign(band, { createdBy: createdBy })).then((doc) => {
            console.log('band was craeted');
            endLoader()
            bandDoc = doc;
        }).catch(e => {
            window.alert("there was an error creating new band");
            endLoader();
        });
        return bandDoc;
    }

    const signInGoogle = async () => {
        startLoader();
        firebase.auth().signInWithPopup(google_provider).then(async (result) => {
            // This gives you a Google Access Token. You can use it to access the Google API.
            var token = result.credential.accessToken;
            // The signed-in user info.
            var user = result.user;

            // create profile if doesnt exists
            const profileDoc = await db.collection('userProfiles').where("email", "==", user.email).limit(1).get();
            if (profileDoc.docs.length == 0) {
                // create profile
                db.collection('userProfiles').add({
                    uid: user.uid, 
                    firstName: user.displayName,
                    lastName: '',
                    phone: user.phoneNumber,
                    zip: '',
                    email: user.email,
                    joinedBands: [],
                }).then(profile => {
                    // create band
                    db.collection('bands').add({ name: user.displayName, createdBy: user.uid }).then(band => {
                        console.log('band was created');
                    });
                })
            }

            endLoader();

        }).catch((error) => {
            // Handle Errors here.
            var errorCode = error.code;
            var errorMessage = error.message;
            window.alert(errorMessage);
            endLoader();
        });
    }


    //for facebok sign in, app id and secret needs to be made by the company fb account
    const signInFacebook = async () => {
        firebase.auth().signInWithPopup(facebook_provider).then((result) => {
            // This gives you a Google Access Token. You can use it to access the Google API.
            var token = result.credential.accessToken;
            // The signed-in user info.
            var user = result.user;
            // ...
        }).catch((error) => {
            // Handle Errors here.
            var errorCode = error.code;
            var errorMessage = error.message;
            window.alert(errorMessage);
        });
    }

    const signIn = async (email, password) => {
        startLoader();
        firebase.auth().signInWithEmailAndPassword(email, password)
        .then(user => {
            endLoader();
        })
        .catch((error) => {
            endLoader();
            // Handle Errors here.
            var errorCode = error.code;
            var errorMessage = error.message;
            window.alert(errorMessage);
            // ...
        });
    }

    const signOut = () => {
        firebase.auth().signOut().then(() => {
            // Sign-out successful.
          }).catch((error) => {
            // An error happened.
            console.log(error);
        });
          
    }

    const signUp = async (email, password, profile) => {
        startLoader();

        // create profile first, then create user. If user creation fails, delete the created profile doc

        if (profile) {
            
            db.collection('userProfiles').add(Object.assign(profile, { email: email, joinedBands: [] })).then((doc) => {
                
                firebase.auth().createUserWithEmailAndPassword(email, password)
                .then(() => {

                    const currentUser = firebase.auth().currentUser;


                    currentUser.sendEmailVerification()
                        .then(() => {

                            endLoader();
                        })
                        .catch(error => {
                            var errorMessage = error.message;
                            window.alert(errorMessage);
                            endLoader();
                        });
                })
                .catch((error) => {

                    // delete the created profile
                    db.collection('userProfiles').doc(doc.id).delete().catch(e => console.log(e));

                    // Handle Errors here.
                    var errorCode = error.code;
                    var errorMessage = error.message;
                    window.alert(errorMessage);
                    endLoader();
                });

            }).catch(e => {
                console.log(e);
                endLoader();
            });

        }

    }

    const sendResetPasswordLink = (email) => {
        startLoader();
        firebase.auth().sendPasswordResetEmail(email).then(function() {
            endLoader();
            window.alert(`Reset password link has been sent to ${email}`);
        }).catch(function(error) {
            endLoader();
            window.alert(error.message);
        });
          
    }

    React.useEffect(() => {
        console.log("effecting currentSongData: ", currentSongData);
    }, [currentSongData]);

    const fetchSong = async (name, songId) => {
        if (authState.signedIn == false) {
            return console.log('not authorized!');
        }

        // var doc;

        if (songId) {
            const snap = await db.collection('songs').doc(songId).get();
            var doc = snap;
            name = doc.data().name;
            setCurrentSongData(doc.data());
        } else if (name) {
            const snap = await db.collection('songs').where('name', '==', name).limit(1).get();
            var doc = snap.docs[0];
            setCurrentSongData(doc.data());
        }
        
        const id = doc.id;
        
        const trackStates = doc.data().trackStates;
        const allowEdit = doc.data().allowEdit;
        const createdBy = doc.data().createdBy;
        const bandId = doc.data().bandId;

        // get band Name
        const bandDoc = await db.collection('bands').doc(bandId).get();
        const bandName = bandDoc.data().name;
        
        //returns follow video url and array of audio urls
        const videoFolder = storageRef.child(`songs/${id}/video`);
        // const videoRef = storageRef.child(`songs/${id}/video/video.webm`);

        //get full paths of all video and convert them to urls and store into array to return
        const videoListRes = await videoFolder.listAll();
        const videoPaths = [];
        videoListRes.items.forEach(item => {
            videoPaths.push(item.fullPath);
        });

        //convert video paths to urls
        const videos = [];
        for (let p of videoPaths) {
            const url = await storageRef.child(p).getDownloadURL();
            const split = p.split('/');
            const name = split[split.length - 1].split('.webm')[0];

            //create track id from name by removing existing spaces
            const nameSplit = name.split(' ');
            var TrackId = '';
            for (let substr of nameSplit) {
                TrackId += substr;
            }
            
            const video = {
                src: url,
                name: name,
                id: TrackId
            }
            videos.push(video);
        }


        const audioFolder = storageRef.child(`songs/${id}/audio`);
        //get full path of video in video folder and convert it into url and store url to return
        // const videoUrl = await videoRef.getDownloadURL();
        //get full paths of all audio and convert them to urls and store into array to return
        const audioListRes = await audioFolder.listAll();
        const audioPaths = [];
        audioListRes.items.forEach(item => {
            audioPaths.push(item.fullPath);
        });

        //convert audio paths to urls
        const tracks = [];
        for (let p of audioPaths) {
            const url = await storageRef.child(p).getDownloadURL();
            const split = p.split('/');
            const name = split[split.length - 1].split('.wav')[0];
            const track = {
                "src": url,
                "name": name
            }
            tracks.push(track);
        }

        //create video id for the follow video
        const nameSplit = name.split(' ');
        var videoId = '';
        for (let substr of nameSplit) {
            videoId += substr;
        }

        const song = {
            followVideoId: videoId,
            videos: videos,
            tracks: tracks,
            trackStates: trackStates,
            allowEdit: allowEdit,
            id: id,
            name: name,
            createdBy: createdBy,
            bandName: bandName,
        }
        
        return song;

    }

    const createSongObject = (videoUrl, audioUrls) => {
        return {
            video: videoUrl,
            tracks: audioUrls
        }
    }

    const getMediaStream = async () => {
        const constraints = {
            video: {
                width: { exact: 320 },
                height: { exact: 240 },
                facingMode: "user",
            },
            audio: true,
        };

        const stream = await navigator.mediaDevices.getUserMedia(constraints);
        setMediaStream(stream);
        return stream;
    }

    const stopMediaStream = (stream) => {
        stream.getTracks().forEach((track) => {
            track.stop();
        });
        setMediaStream(null);
    }

    const getUserDisplayStream = async () => {
        const constraints = {
            video: {
                cursor: 'always'
            },
            audio: false,
        };

        const stream = await navigator.mediaDevices.getDisplayMedia(constraints);
        setUserDisplayStream(stream);
        
        stream.getVideoTracks()[0].onended = function () {
          setYbMode("NOTES");
        };
        return stream;
    }

    const stopUserDisplayStream = (stream) => {
        stream.getTracks().forEach((track) => {
            track.stop();
        });
        setUserDisplayStream(null);
    }

    const deepDiffMapper =  function () {
        return {
            VALUE_CREATED: 'created',
            VALUE_UPDATED: 'updated',
            VALUE_DELETED: 'deleted',
            VALUE_UNCHANGED: 'unchanged',
            map: function (obj1, obj2) {
                if (this.isFunction(obj1) || this.isFunction(obj2)) {
                    throw 'Invalid argument. Function given, object expected.';
                }
                
                if (this.isValue(obj1) || this.isValue(obj2)) {
                    return {
                        type: this.compareValues(obj1, obj2),
                        data: obj1 === undefined ? obj2 : obj1
                    };
                }

                var diff = {};
                for (var key in obj1) {
                    if (this.isFunction(obj1[key])) {
                        continue;
                    }

                    var value2 = undefined;
                    if (obj2[key] !== undefined) {
                        value2 = obj2[key];
                    }

                    diff[key] = this.map(obj1[key], value2);
                }
                for (var key in obj2) {
                    if (this.isFunction(obj2[key]) || diff[key] !== undefined) {
                        continue;
                    }

                    diff[key] = this.map(undefined, obj2[key]);
                }

                return diff;

            },
            compareValues: function (value1, value2) {
                if (value1 === value2) {
                    return this.VALUE_UNCHANGED;
                }
                if (this.isDate(value1) && this.isDate(value2) && value1.getTime() === value2.getTime()) {
                    return this.VALUE_UNCHANGED;
                }
                if (value1 === undefined) {
                    return this.VALUE_CREATED;
                }
                if (value2 === undefined) {
                    return this.VALUE_DELETED;
                }
                return this.VALUE_UPDATED;
            },
            isFunction: function (x) {
                return Object.prototype.toString.call(x) === '[object Function]';
            },
            isArray: function (x) {
                return Object.prototype.toString.call(x) === '[object Array]';
            },
            isDate: function (x) {
                return Object.prototype.toString.call(x) === '[object Date]';
            },
            isObject: function (x) {
                return Object.prototype.toString.call(x) === '[object Object]';
            },
            isValue: function (x) {
                return !this.isObject(x) && !this.isArray(x);
            },
        }
    }();

    const updateLoadedSong = async (update) => {
        console.log("db was changed!");

        if(!currentSongData.trackStates) return;

        //compare and get changes between following elements:
        // audio, video, trackStates, allowEdit, activeCallingUsers

        //get changes between trackStates
        console.log('currentSongData before using: ', currentSongData);
        const currentTrackNames = currentSongData.trackStates.map(t => t.name);
        const currentPlaylistTrackNames = playlist.tracks.map(t => t.name);

        const newTracks = update.data().trackStates;

        if (currentTrackNames.length < newTracks.length) {
            //new track was added
            console.log("track was added");
            for (let track of newTracks) {
                if (currentTrackNames.indexOf(track.name) === -1 && currentPlaylistTrackNames.indexOf(track.name) === -1) {
                    //load this track in the song and video if it exists
        
                    //loading audio file for this track                
                    const audioUrl = await storageRef.child(`songs/${update.id}/audio/${track.name}.wav`).getDownloadURL();
                    const newTrack = { "src": audioUrl, "name": track.name }
                    playlist.load([newTrack]).then(() => {
                        //load states of tracks
                        playlist.tracks.forEach(t => {
                
                            if (t.name === track.name) {
                                t.setStartTime(track.startTime);
                                t.setGainLevel(track.gain);
                                if (!update.data().allowEdit) t.enabledStates = {cursor: true}
                                else t.enabledStates = {cursor: true, shift: true, fadein: true, fadeout: true, select: true}
                            }
                        });
                        playlist.updateEditor();
                        //updating current song state
                        // const newTracks = songState.song.tracks;
                        // newTracks.push(newTrack);
                        // const updatedSong = {...Object.assign(songState.song, { tracks: newTracks })};
                        // updateSongState({ song: updatedSong });
                        
                        //initialize the WAV exporter.
                        playlist.initExporter();
                    });
    
                    //loading video of this track if exists
                    storageRef.child(`songs/${update.id}/video/${track.name}.webm`).getDownloadURL()
                        .then(videoUrl => {
                            const nameSplit = track.name.split(' ');
                            var TrackId = '';
                            for (let substr of nameSplit) {
                                TrackId += substr;
                            }
                            const videoObject = {src: videoUrl, name: track.name.trim(), id: TrackId}
                            
                            setAllVideos(currentVideos => [...currentVideos, videoObject]);
                        }). catch(e => console.log(e.message));
                }
            }

        }

        if (currentTrackNames.length > newTracks.length) {
            // track was deleted
            console.log("track was deleted");
            const newTrackNames = newTracks.map(t => t.name);
            for (let trackName of currentTrackNames) {
                if (newTrackNames.indexOf(trackName) === -1) {
                    //delete this track in the song and video if it exists, delete locally
                    // const track = { name: trackName };
                    // console.log("deleting track...");
                    // deleteTrack(track);                   
                }
            }
    
        }

        //force update all states on doc change trigger
        const tracksToDelete = [];
        playlist.tracks.forEach((t, i) => {
            //get state for this track
            const state = update.data().trackStates.filter(state => state.name == t.name)[0];
            if (state) {
                t.setStartTime(state.startTime);
                t.setGainLevel(state.gain);
                if (!update.data().allowEdit) t.enabledStates = {cursor: true}
                else t.enabledStates = {cursor: true, shift: true, fadein: true, fadeout: true, select: true}
            } else {
                //track was deleted, remove from playlist and remove video if exists
                //get index of the track in playlist
                tracksToDelete.push(i);
                
                // const newAllVideos = allVideos.filter(vid => vid.name !== t.name);
                setAllVideos(prevVideos => prevVideos.filter(vid => vid.name !== t.name));
            }
        });
        for (let i of tracksToDelete) {
            playlist.tracks.splice(i, 1);
        }
        playlist.updateEditor();

        
        const newSongData = update.data();
        
        setCurrentSongData({...Object.assign(currentSongData, newSongData)});

    }

    React.useEffect(() => {
        console.log(allVideos);
    }, [allVideos]);

    React.useEffect(() => {

        if (songListener) songListener.unsubscribe();

        if (thisSongId !== null) {
            // adding listener for this loaded song
            var listener = db.collection('songs').doc(thisSongId).onSnapshot({ includeMetadataChanges: true }, async snap => {
                if (!snap.metadata.hasPendingWrites) {
                    updateLoadedSong(snap);
                }
            });
            setSongListener({unsubscribe: listener});
        }

    }, [thisSongId]);
    
    const loadSong = async (song, playlist, ee) => {
        if (authState.signedIn == false) {
            return console.log('not authorized!');
        }

        if (!window.playlist) initPlaylist();

        startLoader();

        setAllVideos(song.videos);
        setNewVideos([]);
    
        //set display for allow edit toggle container if current userId is same as createdBy id for this song
        const userId = firebase.auth().currentUser.uid;
        if (userId == song.createdBy) updateSongState({ song: song, isUserAdmin: true });
        else updateSongState({ song: song, isUserAdmin: false });

        updateAppState({ mode: "EDIT" });
        setThisSongId(song.id);
    
        //clear previous playlist and clear newTracks array
        playlist.clear();
        setNewTracks([]);
    
        playlist.load(song.tracks).then(() => {
            //load states of tracks and allow/disallow edit and create sliders
            playlist.tracks.forEach(t => {
    
                if (song.trackStates) {
                    //load states only if the states are available
                    const state = song.trackStates.filter(obj => {
                        return obj.name == t.name
                    })[0];
                    t.setStartTime(state.startTime);
                    t.setGainLevel(state.gain);
                    //only allow cursor if edit is not allowed
                    if (!song.allowEdit) t.enabledStates = {cursor: true}
                }
            });
            playlist.updateEditor();
    
            endLoader();
            //initialize the WAV exporter.
            playlist.initExporter();
        });

        // add listener to this loaded song to listen to changes in tracks and videos
        
        
    }

    const clearSong = () => {

        //unload the loaded song
        setNewTracks([]);
        setNewVideos([]);
        setAllVideos([]);
        setVideosToAdd([]);
        setNewSongVideoBlob(null);
        setAudioRecordMenu(false);
        setIsVideoRecording(false);
        setSelectedPlaylistAction(null);
        setSelectedPlaylistActionTrack(null);
        setCurrentSongData(null);

        setCurrentPlaybackTime(0);
        setEditorPlayhead(0);

        updateSongState({ song: null });

        playlist.clear();

    }

    
    const checkNewSongName = async (name) => {
        //check if the input song name already exists in the database
        var bool = true;

        const snap = await db.collection('songs').where('name', '==', name).get();
        snap.forEach(doc => {
            if (doc.data().name == name) bool = false;
        });
        return bool;
    }
    
    const createNewsong = async (name, video) => {
        if (authState.signedIn == false) {
            return console.log('not authorized!');
        }
    
        startLoader();
        // takes video as a blob
        if (authState.signedIn) {
            const userId = firebase.auth().currentUser.uid;
            const isValidName = await checkNewSongName(name);
            if (isValidName) {
    
                //if name is valid and unique, create a database entry for this song metadata
                db.collection('songs').add({
                    bandId: bandData.id,
                    name: name,
                    createdBy: userId,
                    allowEdit: true,
                    trackStates: [{
                        gain: 1,
                        name: name,
                        startTime: 0
                    }]
                })
                .then( async (song) => {
    
                    //storing the files in storage for this song
    
                    const videoFileRef = storageRef.child(`songs/${song.id}/video/${name}.webm`);
                    console.log('uploading video');
                    videoFileRef.put(video, { contentType: 'video/webm' }).then(async snap => {
                        console.log('file uploaded');

                        // extract audio and uplaod the audio track to song
                        const audioBlob = await extractAudioFromVideo(video);
                        const audioFileRef = storageRef.child(`songs/${song.id}/audio/${name}.wav`);
                        console.log('uploading audio');
                        audioFileRef.put(audioBlob, { contentType: audioBlob.type }).then( async snap => {
                            console.log('file uploaded');

                            endLoader();
                            //open this song after creating
                            const thisSong = await fetchSong(name);
                            updateSongState({song: thisSong});
                            updateAppState({mode: 'EDIT'});

                        });


                    })
                    .catch(err => {
                        endLoader();
                        // deleting the song doc with this id because videos failed to upload
                        db.collection('songs').doc(song.id).delete().then(() => {}).catch(e => console.log(e.message));
                        window.alert(err.message);
                    });
                    
    
                })
                .catch((error) => {
                    endLoader()
                    window.alert("There was an error while creating a song: ", error.message);
                });
    
            } else {
                endLoader();
                window.alert('song with this name already exists');
            }
        } else {
            endLoader();
            window.alert("please sign in to create a new song");
        }
    }
    
    const captureVideo = async (blobSetter, displayContainerId, startButtonId, stopButtonId, recordedVideoPlayerId, leadTime) => {
        blobSetter(null);
    
        const videoCapture = document.querySelector(displayContainerId);

        if (mediaStream) var stream = mediaStream;
        if (!mediaStream) var stream = await getMediaStream();
        const mediaRecorder = new MediaRecorder(stream, { mimeType: 'video/webm;codecs=vp8,opus' });
        const videoChunks = [];
        mediaRecorder.addEventListener("dataavailable", event => {
            videoChunks.push(event.data);
        });

        if (startButtonId == null) {
            const leadTimeBeforeRecord = leadTime;
                console.log("leadTime: ", leadTimeBeforeRecord);
                setTimeout(() => {
                    setIsVideoRecording(true);
                    mediaRecorder.start();
                    // document.querySelector(stopButtonId).disabled = false;
                }, leadTimeBeforeRecord*1000);
        } else {
            const onClickStartHandler = () => {
                const leadTimeBeforeRecord = leadTime;
                console.log("leadTime: ", leadTimeBeforeRecord);
                setTimeout(() => {
                    setIsVideoRecording(true);
                    mediaRecorder.start();
                    // document.querySelector(stopButtonId).disabled = false;
                }, leadTimeBeforeRecord*1000);
            }
    
            document.querySelector(startButtonId).addEventListener('click', onClickStartHandler);
        }

        const onClickStopHandler = () => {
            //load the recorded video
            const videoBlob = new Blob(videoChunks, { type: 'video/webm;codecs=vp8,opus' });
            blobSetter(videoBlob); 

            //remove the listener for start button
            if (startButtonId !== null) document.querySelector(startButtonId).removeEventListener('click', onClickStartHandler);
        }

        mediaRecorder.addEventListener("stop", onClickStopHandler);

        document.querySelector(stopButtonId).addEventListener('click', () => {
            //clear stream only if not calling, otherwise keep the stream
            if (!isCalling) {
                stream.getTracks().forEach((track) => {
                    track.stop();
                });
                setMediaStream(null);
            }
            mediaRecorder.stop();
        })

        videoCapture.srcObject = stream;
    }

    const bufferToWave = (abuffer, len) => {
        var numOfChan = abuffer.numberOfChannels,
            length = len * numOfChan * 2 + 44,
            buffer = new ArrayBuffer(length),
            view = new DataView(buffer),
            channels = [],
            i, sample,
            offset = 0,
            pos = 0;

        // write WAVE header
        setUint32(0x46464952); // "RIFF"
        setUint32(length - 8); // file length - 8
        setUint32(0x45564157); // "WAVE"

        setUint32(0x20746d66); // "fmt " chunk
        setUint32(16); // length = 16
        setUint16(1); // PCM (uncompressed)
        setUint16(numOfChan);
        setUint32(abuffer.sampleRate);
        setUint32(abuffer.sampleRate * 2 * numOfChan); // avg. bytes/sec
        setUint16(numOfChan * 2); // block-align
        setUint16(16); // 16-bit (hardcoded in this demo)

        setUint32(0x61746164); // "data" - chunk
        setUint32(length - pos - 4); // chunk length

        // write interleaved data
        for (i = 0; i < abuffer.numberOfChannels; i++)
            channels.push(abuffer.getChannelData(i));

        while (pos < length) {
            for (i = 0; i < numOfChan; i++) { // interleave channels
                sample = Math.max(-1, Math.min(1, channels[i][offset])); // clamp
                sample = (0.5 + sample < 0 ? sample * 32768 : sample * 32767) | 0; // scale to 16-bit signed int
                view.setInt16(pos, sample, true); // write 16-bit sample
                pos += 2;
            }
            offset++ // next source sample
        }

        // create Blob
        return new Blob([buffer], {
            type: "audio/wav"
        });

        function setUint16(data) {
            view.setUint16(pos, data, true);
            pos += 2;
        }

        function setUint32(data) {
            view.setUint32(pos, data, true);
            pos += 4;
        }
    }

    const extractAudioFromVideo = async (videoBlob) => {

        var audioContext = new(window.AudioContext || window.webkitAudioContext)();
        var myBuffer;

        const sampleRate = 32000;
        const numberOfChannels = 1;

        const videoFileAsBuffer = await videoBlob.arrayBuffer();
        const decodedAudioData = await audioContext.decodeAudioData(videoFileAsBuffer);

        var duration = decodedAudioData.duration;

        var offlineAudioContext = new OfflineAudioContext(numberOfChannels, sampleRate * duration, sampleRate);
        var soundSource = offlineAudioContext.createBufferSource();

        myBuffer = decodedAudioData;
        soundSource.buffer = myBuffer;
        soundSource.connect(offlineAudioContext.destination);
        soundSource.start();

        const renderedBuffer = await offlineAudioContext.startRendering();
        const audioBlob = bufferToWave(renderedBuffer, renderedBuffer.length)
        return audioBlob;

    }

    
    const deleteTrack = (track) => {
        if (authState.signedIn == false) {
            return console.log('not authorized!');
        }

        //delete the video too if video exists for this track
        const videoNames = allVideos.map(vid => vid.name);
        if (videoNames.indexOf(track.name) !== -1) {
            const newAllVideos = allVideos.filter(vid => vid.name !== track.name);
            if (songState.song !== null) {
                // delete the video from cloud if exists on cloud
                storageRef.child(`songs/${songState.song.id}/video/${track.name}.webm`).delete().then(() => {
                    console.log(`${track.name}.webm was deleted from cloud`);
                }).catch(e => {});
            }
            setAllVideos(newAllVideos);
        }
    
        //deletes the track. If the track is a song track (saved on cloud), user will be asked to confirm the task
    
        const playlistTrackNames = playlist.tracks.map(t => t.name);
        const index = playlistTrackNames.indexOf(track.name);

        if (songState.song !== null) {
            // delete audio from cloud if exists on cloud
            storageRef.child(`songs/${songState.song.id}/audio/${track.name}.wav`).delete().then(() => {
                console.log(`${track.name}.webm was deleted from cloud`);
                const newTrackStates = currentSongData.trackStates.filter(ts => ts.name !== track.name);
                db.collection('songs').doc(songState.song.id).update({ trackStates: newTrackStates }).then(snap => {
                    
                })
            }).catch(e => {});
        }

        // delete audio and video from newTracks and newVideos
        const newNewTracks = newTracks.filter(t => t.name !== track.name);
        const newNewVideos = newVideos.filter(vid => vid.name !== track.name);
        setNewTracks(newNewTracks);
        setNewVideos(newNewVideos);
    
        playlist.tracks.splice(index, 1);
        playlist.updateEditor();
    
        $('#deleteTrackModal').modal('hide');
    
    }
    
    const uploadTracks = async (id) => {
        if (authState.signedIn == false) {
            return console.log('not authorized!');
        }


        return new Promise((resolve, reject) => {
            const numNewTracks = newTracks.length;
            var numUploadedTracks = 0;
            if (newTracks.length > 0) {
                //get ref to audio folder of the current song
                for (let t of newTracks) {
                    const audioFileRef = storageRef.child(`songs/${id}/audio/${t.name}.wav`);
                    console.log('uploading file', t.name);
                    audioFileRef.put(t.blob, { contentType: t.blob.type }).then(snap => {
                        numUploadedTracks++;
                        console.log("track uploaded", t.name);
                        if (numUploadedTracks == numNewTracks) resolve(true);
                        
                    }).catch(e => reject(e));
                }
            } else {
                resolve(true);
            }
        })
        
    }

    const uploadVideos = async (id) => {
        if (authState.signedIn == false) {
            return console.log('not authorized!');
        }

        return new Promise((resolve, reject) => {
            const numNewVideos = newVideos.length;
            var numUploadedVideos = 0;
            if (numNewVideos > 0) {
                //get ref to video folder of current song
                for (let vid of newVideos) {
                    const videoFileRef = storageRef.child(`songs/${id}/video/${vid.name}.webm`);
                    console.log('uploading video', vid.name);
                    videoFileRef.put(vid.blob, { contentType: vid.blob.type }).then(snap => {
                        console.log('video uploaded', vid.name);
                        numUploadedVideos++;
                        if (numUploadedVideos == numNewVideos) resolve(true);
                        
                    }).catch(e => reject(e));
                }
            } else {
                resolve(true);
            }
        })
        
    }
    
    const createSongState = () => {
        const states = [];
        playlist.tracks.forEach(t => {
            const obj = {
                name: t.name,
                startTime: t.startTime,
                gain: t.gain
            }
            states.push(obj);
        });
        return states;
    }
    
    const allowEditSwitch = async (bool) => {
        //switches editing and saves the state to the db
        startLoader();
        const allowEdit = bool;
        db.collection('songs').doc(songState.song.id).update({ allowEdit: bool })
            .then(snap => {
                //enabling states on tracks
                playlist.tracks.forEach(t => {
                    if (!allowEdit) t.enabledStates = { cursor: true }
                    else t.enabledStates = { cursor: true, fadein: true, fadeout: true, select: true, shift: true }
                });
                playlist.updateEditor();
                endLoader();
            })
            .catch(e => console.log(e))
    }
    
    const saveSong = async (songId) => {
        // Video files and audio files should be done uploading before writing the songState in firestore

        if (authState.signedIn == false) {
            return console.log('not authorized!');
        }
        
        startLoader();

        return new Promise((resolve, reject) => {

            uploadTracks(songId).then((tracksDone) => {
                uploadVideos(songId).then((videoDone) => {
    
                    //reset newTracks and reset newVideos
                    setNewTracks([]);
                    setNewVideos([]);
    
                    const trackStates = createSongState();
                    db.collection('songs').doc(songId).update({trackStates: trackStates})
                        .then(snap => {
                            console.log('track states saved');
                            if (tracksDone && videoDone) {
                                endLoader();
                                resolve(true);
                            } else {
                                reject(new Error('Error uploading media files'));
                            }
                        })
                        .catch(e => {
                            window.alert("There was an error while saving the song: ", e.message);
                            endLoader();
                            reject(e);
                        });
                });
            });

        });
    
    }

    const saveNewSong = async (name) => {
        // 

        if (authState.signedIn == false) {
            return console.log('not authorized!');
        }

        const isValidName = await checkNewSongName(name);

        if (isValidName) {

            startLoader();

            const userId = firebase.auth().currentUser.uid;

            //if name is valid and unique, create a database entry for this song metadata
            db.collection('songs').add({
                bandId: activeBand.id,
                name: name,
                createdBy: userId,
                allowEdit: true,
            }).then(async (song) => {

                saveSong(song.id).then(async done => {
                    if (done) {
                        // load this newly created song
                        const newSong = await fetchSong(name);
                        loadSong(newSong, window.playlist, ee);
                        endLoader();
                    } else {
                        window.alert('Error occured while saving the new song');
                        endLoader();
                    }
                });

            }).catch(e => {
                window.alert(e.message);
                endLoader();
            });

        }
        
    
    }

    const saveNewResource = async (file) => {
        startLoader();

        const userId = firebase.auth().currentUser.uid;

        //if name is valid, create a database entry for this song metadata
        db.collection('resources').add({
            bandId: activeBand.id,
            name: file.name,
            createdBy: userId,
        }).then( (resource) => {

            storageRef.child(`resources/${resource.id}/${file.name}`).put(file, { contentType: file.type }).then(snap => {
                
                // updating the db entry with download url
                storageRef.child(`resources/${resource.id}/${file.name}`).getDownloadURL().then(url => {
                    db.collection('resources').doc(resource.id).update({ url: url }).then(() => {
                        // updated
                        endLoader();
                    })
                })
                
            }).catch(e => {
                // delete the db entry as the storage put failed
                db.collection('resources').doc(resource.id).delete().then(() => {
                    // db entry deleted
                    window.alert('There was an erorr saving the resource');
                    endLoader();
                })
            });

        }).catch(e => {
            window.alert('There was an erorr saving the resource');
            endLoader();
        });

    }

    const deleteResource = async (resourceId) => {
        // delete resource from storage then delete entry from db
        // generate idToken
        if (authState.signedIn == false) {
            return console.log('not authorized!');
        }
        startLoader();
        firebase.auth().currentUser.getIdToken(true).then(token => {
            // make api call to server for resource deletion
            fetch(`https://stagetrack.herokuapp.com/delete/resource/${resourceId}?t=${token}`).then(res => {
                if (res.status == 200) {
                    endLoader();
                } else {
                    window.alert('Resource deletion failed! :(');
                    endLoader();
                }
                
            })
        })
    }
    
    const deleteSong = async (songId) => {
        // delete resource from storage then delete entry from db
        // generate idToken
        if (authState.signedIn == false) {
            return console.log('not authorized!');
        }
        startLoader();
        firebase.auth().currentUser.getIdToken(true).then(token => {
            // make api call to server for resource deletion
            fetch(`https://stagetrack.herokuapp.com/delete/song/${songId}?t=${token}`).then(res => {
                if (res.status == 200) {
                    endLoader();
                } else {
                    window.alert('Song deletion failed! :(');
                    endLoader();
                }
            })
        })
    
    }

    const createNote = async (bandId, note) => {

        if (note.details == "") {
            window.alert("Note body cannot be empty");
            return;
        }
        if (note.title == "") {
            window.alert("Note title cannot be empty");
            return;
        }

        startLoader();
        // creates a note for the selected band
        db.collection('notes').add(Object.assign(note, { bandId: bandId })).then((doc) => {
            endLoader();
            console.log('note has been saved');
            window.alert('Note saved');
        }).catch(e => {
            endLoader();
            window.alert('There was a problem saving the note');
        });
    }

    
    const getFileBlob = (url, cb) => {
        var xhr = new XMLHttpRequest();
        xhr.open("GET", url);
        xhr.responseType = "blob";
        xhr.addEventListener('load', () => {
            cb(xhr.response);
        });
        xhr.send();
    };
    
    const recordHandler = (ee, startButtonId, stopButtonId, blobSetter, leadTime) => {
        blobSetter(null);

        navigator.mediaDevices.getUserMedia({
            audio: true
        })
        .then(stream => {
            const mediaRecorder = new MediaRecorder(stream, { mimeType: 'audio/webm' });

            if (startButtonId == null) {
                const leadTimeBeforeRecording = leadTime;
                    setTimeout(() => {
                        mediaRecorder.start();
                    }, leadTimeBeforeRecording*1000);
            } else {
                const onClickStartHandler = () => {
                    const leadTimeBeforeRecording = leadTime;
                    setTimeout(() => {
                        mediaRecorder.start();
                    }, leadTimeBeforeRecording*1000);
                }
    
                document.querySelector(startButtonId).addEventListener('click', onClickStartHandler);
            }
    
            const audioChunks = [];
            mediaRecorder.addEventListener("dataavailable", event => {
                audioChunks.push(event.data);
            });
            
            const onClickStopHandler = () => {
                //load the recorded audio and add the recorded audio blob to the newTracks array
                const audioBlob = new Blob(audioChunks, { type: 'audio/webm' });
                blobSetter(audioBlob);

                // removing listener for start button
                if (startButtonId !== null) document.querySelector(startButtonId).removeEventListener('click', onClickStartHandler);
            }

            mediaRecorder.addEventListener("stop", onClickStopHandler);
    
            document.querySelector(stopButtonId).addEventListener('click', () => {
                if (!isCalling) {
                    stream.getTracks().forEach((track) => {
                        track.stop();
                    });
                    setMediaStream(null);
                }
                mediaRecorder.stop();
            });
        });
    }


    //************//

    return (
        <MainContext.Provider value={{
            playlist,
            thisUserProfile,
            allSongs,
            allBands,
            allNotes,
            ybMode,
            setYbMode,
            allResources,
            openedResource,
            setOpenedResource,
            setAllNotes,
            setAllBands,
            activeBand,
            setActiveBand,
            bandData,
            createNote,
            setBandData,
            newTracks,
            setNewTracks,
            newVideos,
            setNewVideos,
            allVideos,
            setAllVideos,
            videosToAdd,
            setVideosToAdd,
            newSongVideoBlob,
            setNewSongVideoBlob,
            audioRecordMenu,
            setAudioRecordMenu,
            editorPlayhead,
            setEditorPlayhead,
            currentPlaybackTime,
            setCurrentPlaybackTime,
            seekPlayback,

            getMediaStream,
            mediaStream,
            stopMediaStream,
            setMediaStream,
            getUserDisplayStream,
            userDisplayStream,
            stopUserDisplayStream,
            setUserDisplayStream,
            isCalling,
            setIsCalling,
            remoteStreams,
            setRemoteStreams,

            drawingCanvas,
            setDrawingCanvas,

            appState,
            authState,
            songState,

            updateAppState,
            updateAuthState,
            updateSongState,
            currentSongData,

            startLoader,
            endLoader,
            initPlaylist,
            setDisplay,
            signInGoogle,
            signInFacebook,
            signIn,
            signOut,
            signUp,
            sendResetPasswordLink,
            createBand,
            fetchSong,
            createSongObject,
            loadSong,
            clearSong,
            checkNewSongName,
            createNewsong,
            captureVideo,
            extractAudioFromVideo,
            deleteTrack,
            uploadTracks,
            createSongState,
            allowEditSwitch,
            saveSong,
            saveNewSong,
            saveNewResource,
            deleteSong,
            deleteResource,
            getFileBlob,
            recordHandler

        }}>
            {children}
        </MainContext.Provider>
     );
}