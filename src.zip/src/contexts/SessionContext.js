
const SessionContext = React.createContext();

const SessionContextProvider = ({ children }) => {

    const {
        allNotes,
        setAllNotes,
        authState,
        songState,
        fetchSong,
        loadSong,
        clearSong,
        isCalling, 
        setIsCalling, 
        mediaStream, 
        setMediaStream, 
        getMediaStream,
        stopMediaStream,
        remoteStreams,
        setRemoteStreams,
        userDisplayStream,
        getUserDisplayStream,
        setUserDisplayStream,
        thisUserProfile,
        setOpenedResource,
        activeband,
        setActiveBand,
    
    } = React.useContext(MainContext);

    const [thisPeer, setThisPeer] = React.useState(null);
    const [thisSessionData, setThisSessionData] = React.useState(null);
    const [thisSessionBand, setThisSessionBand] = React.useState(null);
    const [thisSessionId, setThisSessionId] = React.useState(null);
    const [sessionListener, setSessionListener] = React.useState(null);
    const [allowClickShare, setAllowClickShare] = React.useState(false);

    const [openedPDF, setOpenedPDF] = React.useState(null);

    const [note, setNote] = React.useState("");
    const [sharedCanvas, setSharedCanvas] = React.useState(null);

    const [remoteUserDisplay, setRemoteUserDisplay] = React.useState(null);

    //following code will only run once for the first mounting of this context
    React.useEffect(() => {

        //initPeer
        console.log('connecting to peer server...');
        var peer = new Peer({
            host: 'stagetrack.herokuapp.com',
            secure: true,
            // port: 3000,
            path: '/peerjs'
          });

        peer.on('open', peerId => {
            setThisPeer(peer);
            console.log('connected to peer server: ', peerId);
        });

        peer.on('call', async call => {
            if (mediaStream) var stream = mediaStream;
            else var stream = await getMediaStream();
            call.answer(stream);
            // window.alert("You are getting a call!");
            setIsCalling(true);
            
            call.on('stream', remoteStream => {

                if (call.metadata.type && call.metadata.type == "SCREENSHARE") {
                    const obj = { userId: call.metadata.userId, peerId: call.peer, stream: remoteStream };
                    setRemoteUserDisplay(obj);
                }
                
                else {

                    const obj = { userId: call.metadata.userId, peerId: call.peer, stream: remoteStream };
                    // add this stream to remoteStreams if not already
                    
                    setRemoteStreams(prevRemoteStreams => {
                        if (prevRemoteStreams.filter(s => s.peerId == call.peer).length == 0) {
                            return [...prevRemoteStreams, obj]
                        } else {
                            return prevRemoteStreams;
                        }
                    });

                }
                
            })

        });

        peer.on('connection', conn => {
            
            conn.on('data', data => {
                // listening to data
                if (data.type == 'COMMAND') {
                    switch (data.data) {
                        case "PLAY":
                                $('#btn-play').click();
                            break;
                        case "STOP":
                                $('#btn-stop').click();
                            break;
                        default:
                            break;
                    }
                }
                if (data.type == "SETNOTE") {
                    setNote(data.body);
                }
                if (data.type == "BUTTONCLICK") {
                    try {
                        console.log("buttonclick: ", data.buttonId);
                        // $(data.buttonId).click();
                        document.getElementById(data.buttonId).click();
                    } catch (error) {
                        //
                    }
                }
                if (data.type == 'INFO') {
                    switch (data.data.info) {
                        case "RECORDING START":
                            
                                // add blinkingBorder class to this peerId video box
                                const container1 = document.getElementById(`remoteStreamContainer-${data.data.peerId}`).parentElement;
                                if (container1) container1.classList.add('blinkingBorder');

                            break;

                        case "RECORDING STOP":
                                // add blinkingBorder class to this peerId video box
                                const container2 = document.getElementById(`remoteStreamContainer-${data.data.peerId}`).parentElement;
                                if (container2) container2.classList.remove('blinkingBorder');

                            break;
                    
                        default:
                            break;
                    }
                }
                if (data.type == 'CHAT') {
                    
                    try {
                        // openChat() function
                        document.getElementById("mySidepane2").style.width = "400px";
                        document.getElementById("openchatbtn").style.display = "none";
                    } catch (error) {
                        // 
                    }

                    // add the chat to chatsection
                    const container = document.getElementById('chatMessagesContainer');
                    const sender = document.createElement('div');
                    sender.className = 'chatMessagesReceivedFrom';
                    sender.innerText = data.data.sentByProfile.firstName + ' ' + data.data.sentByProfile.lastName;
                    
                    const chat = document.createElement('div');
                    chat.className = 'chatMessagesReceived';
                    chat.innerText = data.data.message;

                    container.appendChild(sender);
                    container.appendChild(chat);

                }
                if (data.type == 'SHAREDCANVAS') {
                    setSharedCanvas(data.canvas);
                }
                if (data.type == 'OPENEDRESOURCE') {
                    // set openedResource

                    setOpenedResource(data.openedResource);
                }
            });
        })


    }, []);

    React.useEffect(() => {
        if (thisSessionBand) {
            setActiveBand(thisSessionBand);
        }
    }, [thisSessionBand])

    React.useEffect(() => {
        
        if (thisSessionData !== null) {
            // subscribe to the notes for band of this session
            db.collection('notes').onSnapshot(function(querySnapshot) {
                const notes = [];
                querySnapshot.forEach(function(doc) {
                    if (doc.data().bandId == thisSessionData.bandId) {
                        const obj = Object.assign(doc.data(), { id: doc.id });
                        notes.push(obj);
                    }                    
                });
                setAllNotes(notes);
                
            });

            // get the this session band and setThisSessionBand
            db.collection('bands').doc(thisSessionData.bandId).get().then(doc => {
                setThisSessionBand(Object.assign(doc.data(), { id: thisSessionData.bandId }));
            });
        }

    }, [thisSessionData]);

    React.useEffect(() => {

        if (sessionListener) sessionListener.unsubscribe();

        if (thisSessionId !== null) {
            var listener = db.collection('sessions').doc(thisSessionId).onSnapshot({ includeMetadataChanges: true }, snap => {
                if (!snap.metadata.hasPendingWrites) {
                    updateSession(snap);
                }
            });
            setSessionListener({ unsubscribe: listener });

            //switch to streams view
            $("#btn-showStreams").click();
        }

    }, [thisSessionId]);

    const updateSession = async (update) => {

        const newSessionData = update.data();

        setOpenedPDF(newSessionData.openedPDF);

        //handling change in loaded song in the session
        if (newSessionData.songId !== thisSessionData.songId) {
            
            if (newSessionData.songId !== null) {
                if (songState.song == null) {
                    // load the song after fetching by songId
                    const song = await fetchSong(null, newSessionData.songId);
                    loadSong(song, window.playlist, ee);
                }
                else if (songState.song.id !== newSessionData.songId) {
                    // load the song after fetching by songId
                    const song = await fetchSong(null, newSessionData.songId);
                    loadSong(song, window.playlist, ee);
                }
            }

        }


        //handling disconnecting peers

        const currentActivePeers = thisSessionData.activePeers;
        const newCallingPeers = newSessionData.activePeers;

        if (currentActivePeers) {

            const currentCallingPeerIds = currentActivePeers.map(p => p.peerId);
            const newCallingPeerIds = newCallingPeers.map(p => p.peerId);

            const diff = _.difference(currentCallingPeerIds, newCallingPeerIds);
            
            //removing the stream container for disconnected peers
            
            for (let peerId of diff) {
                const streamContainer = document.getElementById(`remoteStreamContainer-${peerId}`);
                //removing this stream from remoteStreams
                setRemoteStreams(prevRemoteStreams => prevRemoteStreams.filter(s => s.peerId !== peerId));
                if (streamContainer) streamContainer.remove();

                // removing the dataconnection of peerID from thisPeer.connections to clear its connection
                for (let key in thisPeer.connections) {
                    if (peerId == key) {
                        const connections = thisPeer.connections[key];
                        for (let conn of connections) {
                            conn.close();
                        }
                    }
                }

            }
            
        }

        setThisSessionData(prevData => {
            if (prevData !== null) {
                return Object.assign(prevData, newSessionData)
            } else {
                return null
            }
        });

    }

    const generatePassword = () => {

        var digitLength = 3,
            charset = "0123456789",
            digits = "";
        for (var i = 0, n = charset.length; i < digitLength; ++i) {
            digits += charset.charAt(Math.floor(Math.random() * n));
        }

        var letterLength = 1,
            charset = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ",
            letters = "";
        for (var i = 0, n = charset.length; i < letterLength; ++i) {
            letters += charset.charAt(Math.floor(Math.random() * n));
        }

        //insert letters in rnadom index beteween the digits
        var retVal = digits.split('');
        const rand = Math.floor(Math.random()*4);
        if (rand <= 2) {
            retVal.splice(rand, 0, letters);
            var passcode = '';
            for (let c of retVal) {
                passcode += c;
            }
            retVal = passcode;
        } else {
            retVal = digits + letters;
        }

        // const retVal = digits + letters;
        return retVal;
    }

    const createSession = (bandId) => {

        if (thisPeer == null) {
            window.alert("Not connected to the server yet...");
            return;
        }

        //creates a new session doc in db. returns the passcode for session

        return new Promise( async (resolve, reject) => {

            if (thisPeer == null) {
                reject(new Error("NO_PEER_ERROR"));
                return;
            }

            if (mediaStream) var stream = mediaStream;
            else var stream = await getMediaStream().catch(e => {
                reject(new Error("NO_STREAM_ERROR"));
                return;
            });
            
            if (stream) {
                console.log("stream", stream);
                //create a random passcode
                var passcode;
                while (true) {
                    passcode = generatePassword();
                    //check passcode with existing sessions if any
                    const res = await db.collection('sessions').where("passcode", "==", passcode).get();
                    const sessions = res.docs;
                    if (sessions.length == 0) break;
                }

                db.collection('sessions').add({
                    passcode: passcode,
                    createdBy: authState.user.uid,
                    activePeers: [{ peerId: thisPeer.id, userId: authState.user.uid }],
                    activePeerIds: [thisPeer.id],
                    songId: songState.song !== null ? songState.song.id : null,
                    bandId: bandId
                }).then(async doc => {
                    const res = await doc.get();
                    const data = res.data();
                    setThisSessionData(prevData => data);
                    setThisSessionId(prevId => res.id);

                    setIsCalling(true);

                    console.log("resolving...");
                    resolve(passcode);

                }).catch(e => {
                    console.log(e.message);
                    reject(e);
                });

            }

        })

    }

    const call = async (mystream, peerId, userId) => {
        
        const call = thisPeer.call(peerId, mystream, { metadata: { userId: authState.user.uid } });

        call.on('stream', remoteStream => {
            const obj = { userId: userId, peerId: peerId, stream: remoteStream };
            // add the stream to remote streams if ot already
            
            setRemoteStreams(prevRemoteStreams => {
                if (prevRemoteStreams.filter(s => s.peerId == peerId).length == 0) {
                    return [...prevRemoteStreams, obj];
                } else {
                    return prevRemoteStreams;
                }
            });
            
        })

    }

    const shareScreen =  async () => {

        var displayStream;
        if (userDisplayStream) displayStream = userDisplayStream;
        else displayStream = await getUserDisplayStream();

        if (displayStream !== null) {
            const obj = { userId: authState.user.uid, peerId: thisPeer.id, stream: displayStream };
            setRemoteUserDisplay(obj);
            // share screen with all the connected peers (get peers from remoteStreams)
            const connectedPeers = remoteStreams.map(s => s.peerId);

            for (let peerId of connectedPeers) {
                const call = thisPeer.call(peerId, displayStream, { metadata: { type: "SCREENSHARE", userId: authState.user.uid } });
            }

        }

    }

    const connectToPeer = (peerId) => {
        const conn = thisPeer.connect(peerId);

        conn.on('open', () => {
            conn.on('data', data => {

                // listening to data
                if (data.type == 'COMMAND') {
                    switch (data.data) {
                        case "PLAY":
                                $('#btn-play').click();
                            break;
                        case "STOP":
                                $('#btn-stop').click();
                            break;
                        default:
                            break;
                    }
                }
                if (data.type == "SETNOTE") {
                    setNote(data.body);
                }
                if (data.type == "BUTTONCLICK") {
                    try {
                        console.log("buttonclick: ", data.buttonId);
                        // $(data.buttonId).click();
                        document.getElementById(data.buttonId).click();
                    } catch (error) {
                        //
                    }
                }
                if (data.type == 'INFO') {
                    switch (data.data.info) {
                        case "RECORDING START":
                            
                                // add blinkingBorder class to this peerId video box
                                const container1 = document.getElementById(`remoteStreamContainer-${data.data.peerId}`).parentElement;
                                if (container1) container1.classList.add('blinkingBorder');

                            break;

                        case "RECORDING STOP":
                                // add blinkingBorder class to this peerId video box
                                const container2 = document.getElementById(`remoteStreamContainer-${data.data.peerId}`).parentElement;
                                if (container2) container2.classList.remove('blinkingBorder');

                            break;
                    
                        default:
                            break;
                    }
                }
                if (data.type == 'CHAT') {

                    try {
                        // openChat() function
                        document.getElementById("mySidepane2").style.width = "400px";
                        document.getElementById("openchatbtn").style.display = "none";
                    } catch (error) {
                        // 
                    }

                    // add the chat to chatsection
                    const container = document.getElementById('chatMessagesContainer');
                    const sender = document.createElement('div');
                    sender.className = 'chatMessagesReceivedFrom';
                    sender.innerText = data.data.sentByProfile.firstName + ' ' + data.data.sentByProfile.lastName;
                    
                    const chat = document.createElement('div');
                    chat.className = 'chatMessagesReceived';
                    chat.innerText = data.data.message;

                    container.appendChild(sender);
                    container.appendChild(chat);

                }
                if (data.type == 'SHAREDCANVAS') {
                    setSharedCanvas(data.canvas);
                }
                if (data.type == 'OPENEDRESOURCE') {
                    // set openedResource

                    setOpenedResource(data.openedResource);
                }
                
            })
        });
    }

    const broadcast = (obj) => {
        for (let key in thisPeer.connections) {
            const connections = thisPeer.connections[key];
            for (let conn of connections) {
                if (conn._buffer) {
                    conn.send(obj);
                }
            }
        }
    }

    const pauseMediaStream = () => {
        if (mediaStream) {
            mediaStream.getTracks().forEach(t => t.enabled = !t.enabled);
        }
    }

    const leaveSession = async () => {

        // disconnecting all the connections of this peer
        for (let key in thisPeer.connections) {
            const connections = thisPeer.connections[key];
            for (let conn of connections) {
                conn.close();
            }
        }
        setRemoteStreams([]);

        //removes this peer entry from activeCallingPeers
        stopMediaStream(mediaStream);
        const thisSessionDoc = await db.collection('sessions').doc(thisSessionId).get();

        //destroying the session if thisPeer is the only active peer
        if (thisSessionDoc.data().activePeers.length == 1 && thisSessionDoc.data().activePeers[0].peerId == thisPeer.id) {
            console.log('destroying the session');
            //destroy the sesssion
            db.collection('sessions').doc(thisSessionId).delete().then(() => {

                console.log('session destroyed');
                setIsCalling(false);

                setThisSessionData(null);
                setThisSessionId(null);

                location.reload();
            });

        }
        else {
            console.log('removing peer from session');
            var currentActivePeers = null;
            var currentActivePeerIds = null;
            if (thisSessionDoc.data().activePeers) {
                currentActivePeers = thisSessionDoc.data().activePeers;
                currentActivePeerIds = thisSessionDoc.data().activePeerIds;
            }
            if (currentActivePeerIds) {
                const index = currentActivePeerIds.indexOf(thisPeer.id);
                currentActivePeerIds.splice(index, 1);
                //update the list on firestore
                db.collection('sessions').doc(thisSessionId).update({ activePeerIds: currentActivePeerIds })
                    .then(doc => {
                        // thisPeer.id entry removed from the array activePeerIds.
                    }). catch(e => console.log(e.message));
            }
            if (currentActivePeers) {
                const userIds = currentActivePeers.map(p => p.userId);
                const index = userIds.indexOf(authState.user.uid);
                currentActivePeers.splice(index, 1);
                //update the list on firestore
                db.collection('sessions').doc(thisSessionId).update({ activePeers: currentActivePeers })
                    .then(doc => {

                        //removing the stream containers
                        const containers = document.getElementsByClassName('remoteStreamNoSelf');
                        for (let ele of containers) {
                            ele.remove();
                        }
                        setIsCalling(false);

                        setThisSessionData(null);
                        setThisSessionId(null);

                        location.reload();

                    }). catch(e => console.log(e.message));
            }

        }

    }

    const joinSession = async (sessionId, sessionPasscode) => {

        if (thisPeer == null) {
            window.alert("Not connected to the server yet...");
            return;
        }

        if (thisPeer == null) {
            throw new Error("NO_PEER_ERROR");
        }
        
        if (mediaStream) var stream = mediaStream;
        else var stream = await getMediaStream().catch(e => {
            throw new Error("NO_STREAM_ERROR");
        });

        if (stream) {

            setIsCalling(true);

            var sessionDoc;

            if (sessionPasscode) {
                sessionPasscode = sessionPasscode.trim();
                const doc = await db.collection('sessions').where("passcode", "==", sessionPasscode).limit(1).get();
                sessionDoc  = doc.docs[0];
                sessionId = sessionDoc.id;
            } else if (sessionId) {
                //get all the active calling peers from fecthed song to get updated list of joined users
                sessionDoc = await db.collection('sessions').doc(sessionId).get();
            }

            // load the song form session if exists
            try {
                clearSong();
            } catch (error) {
                //
            }
            if (sessionDoc.data().songId !== null) {
                // load the song after fetching by songId
                const song = await fetchSong(null, sessionDoc.data().songId);
                loadSong(song, window.playlist, ee);
            }

            const currentActivePeers = sessionDoc.data().activePeers;
            const thisCallingPeer = { peerId: thisPeer.id, userId: authState.user.uid };
            if (currentActivePeers) {
                if (currentActivePeers.length > 0) {
                    //call each active calling peer
                    for (let p of currentActivePeers) {
                        // connect and call
                        connectToPeer(p.peerId);
                        call(stream, p.peerId, p.userId);
                    }
                }
                
                //if the activePeer exists with same user id, remove it and then add this one to the call
                const existingPeerIndex = _.findIndex(currentActivePeers, thisCallingPeer);
                if (existingPeerIndex !== -1) {
                    // peer with this userID already exists. First remove it from the list and update
                    const updatedPeersList = currentActivePeers;
                    updatedPeersList.splice(existingPeerIndex, 1);
                    db.collection('sessions').doc(sessionId).update({ activePeers: updatedPeersList })
                        .then(doc => {
                            
                            // add this peer to the call after removing previous duplicate pper
                            db.collection('sessions').doc(sessionId).update({ activePeers: firebase.firestore.FieldValue.arrayUnion(thisCallingPeer) })
                                .then(() => {

                                    db.collection('sessions').doc(sessionId).get().then(doc => {

                                
                                        setThisSessionData(prevData => doc.data());
                                        setThisSessionId(prevId => doc.id);
            
                                    });

                                }).catch(e => console.log(e.message));

                        }).catch(e => console.log(e.message));
                }
                else {
                    //add this peer to activeCallingPeers of this song
                    db.collection('sessions').doc(sessionId).update({ activePeers: firebase.firestore.FieldValue.arrayUnion(thisCallingPeer) })
                        .then(() => {
                            
                            db.collection('sessions').doc(sessionId).get().then(doc => {

                                console.log(doc.data(), thisSessionData);
                                setThisSessionData(doc.data());
                                setThisSessionId(doc.id);

                            })

                        }).catch(e => console.log(e, e.message));
                    // add this peer id to the activePeerIds list
                    db.collection('sessions').doc(sessionId).update({ activePeerIds: firebase.firestore.FieldValue.arrayUnion(thisPeer.id) })
                        .then(() => {
                            // this peer id entry added to activePeerIds list

                        }).catch(e => console.log(e, e.message));
                }

            }
            else {

                db.collection('sessions').doc(sessionId).set({ activePeers: [{ peerId: thisPeer.id, userId: authState.user.uid }], activePeerIds: [thisPeer.id] }, { merge: true })
                    .then(() => {
                        db.collection('sessions').doc(sessionId).get().then(doc => {

                            console.log(doc.data(), thisSessionData); 
                            setThisSessionData(doc.data());
                            setThisSessionId(doc.id);

                        });

                    }).catch(e => console.log(e.message));
            }

        }
    }

    const shareClickWithPeers = (buttonId) => {
        if (thisSessionId !== null && thisSessionData.createdBy == thisUserProfile.uid && allowClickShare == true) {
            broadcast({ type: "BUTTONCLICK", buttonId: buttonId });
        }
    }

    //************//

    return (
        <SessionContext.Provider value={{
            
            thisPeer,
            thisSessionData,
            thisSessionBand,
            thisSessionId,
            allowClickShare,
            setAllowClickShare,
            openedPDF,
            setOpenedPDF,
            joinSession,
            broadcast,
            pauseMediaStream,
            leaveSession,
            createSession,
            note,
            sharedCanvas,
            setSharedCanvas,
            setNote,
            shareClickWithPeers,
            remoteUserDisplay,
            setRemoteUserDisplay,
            shareScreen,
        }}>
            {children}
        </SessionContext.Provider>
     );
}