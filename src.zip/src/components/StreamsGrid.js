
const StreamsGrid = (props) => {

    const { mediaStream, remoteStreams, isCalling, createNote, allNotes, openedResource, setOpenedResource } = React.useContext(MainContext);
    const { thisSessionData, thisSessionId, note, setNote, broadcast, openedPDF, setOpenedPDF } = React.useContext(SessionContext);

    const [, updateState] = React.useState();
    const forceUpdate = React.useCallback(() => updateState({}), []);

    const [showPdf, setShowPdf] = React.useState(false);

    React.useEffect(() => {
        if (props.showPdf == true) {
            setShowPdf(true);
        }
        else {
            setShowPdf(false);
        }
    }, [props.showPdf])

    // React.useEffect(() => {
    //     broadCastNote();
    // }, [note]);

    const keepNoteHandler = () => {
        // save the note
        var title = window.prompt("Please provide title for the note");
        if (title !== null && title !== "") {
            title = title.trim();
            if (thisSessionData !== null) {
                createNote(thisSessionData.bandId, {title, body: note});
            }
        }
    }

    const openNoteHandler  = () => {
        // make the note selection note pop up
        $("#noteSelectionModal").modal('show');
    }


    React.useEffect(() => {
        setShowPdf(true);
        if (openedResource !== null) {
            const wrapper = document.getElementById("pdfViewerWrapper");
            if (wrapper !== null) {
                wrapper.innerHTML = `
                    <iframe id="pdfViewer" src = "../ViewerJS/#${openedResource}" width='100%' height='100%' allowFullScreen webkitallowfullscreen="true"></iframe>
                `
            }
        }

    }, [openedResource]);

    React.useEffect(() => {

        // resetting both grids to empty
        const grid1 = document.getElementById("grid1");
        const grid2 = document.getElementById("grid2");
        if (grid1) {
            grid1.innerHTML = '';
        }
        if (grid2) {
            grid2.innerHTML = '';
        }

        // appending the stream divs in grids
        for (let [i, stream] of remoteStreams.entries()) {
            const remotePeerId = stream.peerId;
            const div = document.createElement('div');
            div.className = "remoteStream remoteStreamNoSelf";
            div.id = `remoteStreamContainer-${remotePeerId}`;
            div.innerHTML = `
                <video class="streamVideo" autoPlay id="remoteStream-${remotePeerId}"></video>
            `

            if (i % 2 == 0) {
                // put in grid1
                grid2.appendChild(div);
                document.getElementById(`remoteStream-${remotePeerId}`).srcObject = stream.stream;
            }
            else {
                // put in grid2
                grid1.appendChild(div);
                document.getElementById(`remoteStream-${remotePeerId}`).srcObject = stream.stream;
            }
        }

        if (remoteStreams.length > 1) {
            $(".remoteStream video").css({ "object-fit": "none" });
        } else {
            $(".remoteStream video").css({ "object-fit": "contain" });
        }

    }, [remoteStreams])

    React.useEffect(() => {
        if (isCalling) {

            const div = document.createElement('div');
            div.className = "remoteStream";
            div.id = `selfStreamContainer`;
            div.innerHTML = `
                <video class="streamVideo" muted autoplay id="selfStream"></video>
            `
            const grid1 = document.getElementById("grid1")
            grid1.prepend(div);
            document.getElementById("selfStream").srcObject = mediaStream;

        } else {
            // resetting both grids to empty
            const grid1 = document.getElementById("grid1");
            const grid2 = document.getElementById("grid2");
            if (grid1) {
                grid1.innerHTML = '';
            }
            if (grid2) {
                grid2.innerHTML = '';
            }
        }
    }, [isCalling, remoteStreams]);

    return (

        <React.Fragment>

        {/* not selection popup modal */}
        <div className="modal fade" id="noteSelectionModal" tabIndex="-1" role="dialog"
            aria-labelledby="noteSelectionModal" aria-hidden="true">
            <div className="modal-dialog modal-dialog-centered" role="document">
                <div className="modal-content">
                    <div className="modal-header">
                        <h5 className="modal-title" id="noteSelectionModalTitle">Select the note to open</h5>
                        
                    </div>
                    <div className="modal-body">
                        
                        <div className="form-group">
                            <label>Select the note</label>
                            <select className="form-control" id="noteSelection">

                                {
                                    allNotes.map(n => {
                                        return (
                                            <option value={n.body} key={n.id}>{n.title}</option>
                                        )
                                    })
                                }
                            </select>
                        </div>

                    </div>
                    <div className="modal-footer">
                        <button onClick={() => {
                            setShowPdf(false);
                            setNote(document.getElementById("noteSelection").value);
                            $("#noteSelectionModal").modal('hide');
                        }} type="button" className="btn btn-primary">Open</button>
                    </div>
                </div>
            </div>
        </div>

        {
            remoteStreams.length == 0 ?
            <div id="newMainContentArea1">
                <div id="grid1" className="newMainContentCaptureWrapper1 gridContainer">
                    {/* grid here */}
                </div>
                <div className="newMainContentCaptureWrapper1YellowOne">
                    <div className="newMainContentCaptureInner">
                        <div className="newMainContentNotesPanel1">
                            <YellowBox/>
                        </div>
                        
                    </div>
                </div>
            </div>
            : null
        }

        {
            remoteStreams.length > 0 ?
            <div id="newMainContentArea1">
                <div id="grid1" className="newMainContentCaptureWrapper1 gridContainer">
                    {/* grid here */}
                </div>
                <div className="newMainContentCaptureWrapper1YellowOne">
                    <div className="newMainContentCaptureInner">
                        <div className="newMainContentNotesPanel1">
                            <YellowBox/>
                        </div>
                        
                    </div>
                </div>
                <div id="grid2" className="newMainContentCaptureWrapper1 gridContainer">
                    {/* grid here */}
                </div>
            </div>
            : null
        }

        
        </React.Fragment>

    )

}