
const EditSong = () => {

    const {
        allSongs,
        allBands,
        thisUserProfile,
        bandData,
        setBandData,
        setDisplay,
        startLoader,
        endLoader,
        fetchSong,
        signOut,
        authState,
        updateAppState,
        updateSongState,
        songState, 
        loadSong, 
        clearSong,
        initPlaylist, 
        checkNewSongName,
        saveSong,
        saveNewSong,
        allVideos,
        newTracks,
        setNewTracks,
        newVideos,
        setNewVideos,
        setAllVideos,
        allowEditSwitch,
        captureVideo,
        extractAudioFromVideo,
        recordHandler,
        editorPlayhead,
        setEditorPlayhead,
        currentPlaybackTime,
        setCurrentPlaybackTime,
        setCurrentSongData,
        seekPlayback,

        
        isCalling,
        mediaStream,
        stopMediaStream,
        remoteStreams,
        

    } = React.useContext(MainContext);

    const {
        thisPeer,
        thisSessionId,
        thisSessionData,
        createSession,
        joinSession,
        broadcast,
        leaveSession,
    } = React.useContext(SessionContext);

    const [, updateState] = React.useState();
    const forceUpdate = React.useCallback(() => updateState({}), []);

    const [allowEditChecked, setAllowEditChecked] = React.useState(songState.song !== null? songState.song.allowEdit: true);

    const [showWebcam, setShowWebcam] = React.useState(false);
    const [recordingType, setRecordingType] = React.useState('AUDIO');
    const [videoTimeouts, setVideoTimeouts] = React.useState([]);

    const [isRecording, setIsRecording] = React.useState(false);
    const [isReadyToRecord, setIsReadyToRecord] = React.useState(false);
    
    const [newRecordingName, setNewRecordingName] = React.useState(getDateString());
    const [newVideoBlob, setNewVideoBlob] = React.useState(null);
    const [newAudioBlob, setNewAudioBlob] = React.useState(null);
    const [openSongName, setOpenSongName] = React.useState('');
    const [joinSessionPasscode, setJoinSessionPasscode] = React.useState('');

    const [isPlayingForAll, setIsPlayingForAll] = React.useState(false);

    const [pauseState, setPauseState] = React.useState(null);

    const [followVideo, setFollowVideo] = React.useState(null);
    const [leadTime, setLeadTime] = React.useState(5);

    const [isAudioOnlyRecordingChecked, setIsAudioOnlyRecordingChecked] = React.useState(false);
    const [isAudioVideoRecordingChecked, setIsAudioVideoRecordingChecked] = React.useState(false);
    const [showVideoRecordingDisplay, setShowVideoRecordingDisplay] = React.useState(false);

    //states for user streams different layouts
    const [showStage, setShowStage] = React.useState(true);
    const [showStreams, setShowStreams] = React.useState(false);
    const [showStreamBoxes, setShowStreamBoxes] = React.useState(true);
    const [showTopStreamsDisplay, setShowTopStreamsDisplay] = React.useState(false);

    function getFollowVideo() {
        if (songState.song == null) return;
        const followVideo = allVideos.filter(vid => vid.name == songState.song.name)[0];
        return followVideo;
    }
    function getDateString() {
        const date = new Date();
        const year = date.getFullYear();
        const month = `${date.getMonth() + 1}`.padStart(2, '0');
        const day =`${date.getDate()}`.padStart(2, '0');
        return `${year}-${month}-${day}-${date.getHours()}-${date.getMinutes()}-${date.getSeconds()}`
    }

    //UI HANDLERS

    /* Set the width of the sidebar to 250px (show it) */
    function openNav() {
        document.getElementById("mySidepanel").style.width = "250px";
        document.getElementById("openbtn").style.display = "none";
    }

    /* Set the width of the sidebar to 0 (hide it) */
    function closeNav() {
        document.getElementById("mySidepanel").style.width = "0";
        document.getElementById("openbtn").style.display = "block";
    }

    /*Chat*/

    /* Set the width of the sidebar to 250px (show it) */
    function openChat() {
        document.getElementById("mySidepane2").style.width = "350px";
        document.getElementById("openchatbtn").style.display = "none";
        document.getElementById("mySidepane2").style.borderRight = "2px solid black";
    }

    /* Set the width of the sidebar to 0 (hide it) */
    function closeChat() {
        document.getElementById("mySidepane2").style.width = "0";
        document.getElementById("openchatbtn").style.display = "block";
        document.getElementById("mySidepane2").style.borderRight = "none";
    }

    /* Main page Record */
    var mainPanelInitialized = false;
    var totalMinimizedPanels = 0;
    var differenceInPositioningRecord;
    var differenceInPositioningMixer;
    var differenceInPositioningTracks;
    // modified code 9/12/2020
    function showRecord(y) {
        var a;
        if (mainPanelInitialized == false) {
            //
            a = 58;
        } else {
            a = 58 + y;
        }
        mainPanelInitialized = true;
        var b = a.toString() + 'px';
        document.getElementById("controlPanelTop").style.bottom = b;
        document.getElementById("closeRecord").style.display = "block";
        var x = document.getElementById("controlPanelTop");
        fadeIn(x);
    }

    function closeRecord() {
        document.getElementById("controlPanelTop").style.top = "-2700px";
        document.getElementById("controlPanelTop").style.opacity = 0;
        document.getElementById("closeRecord").style.display = "none";
        if (totalMinimizedPanels == 0) {
            mainPanelInitialized = false;
        }
    }
    //end of new & modified code 9/12/2020
    /* Fade in */
    function fadeIn(x) {
        x.style.transition = "opacity 1s linear 0s";
        x.style.opacity = 1;
    }

    /* Change color on main control panel */
    function changeColor(y) {
        var x = document.getElementsByClassName("switch");

        for (i = 0; i < x.length; i++) {
            x[i].style.color = y;
            x[i].style.borderColor = y;
        }
    }

    /* Start BPM */
    function startBpm() {
        document.getElementById("panelTopStartWrapper").style.display = "none";
        document.getElementById("panelTopStartWrapperAlt").style.display = "flex";
    }

    /* Stop BPM */
    function stopBpm() {
        document.getElementById("panelTopStartWrapper").style.display = "flex";
        document.getElementById("panelTopStartWrapperAlt").style.display = "none";
    }
    /* Start Recording change colors & text */
    var startRecordingBoolean = false;

    function startRecording() {
        if (startRecordingBoolean == true) {
            startRecordingBoolean = false;
            document.getElementById("startRecordingWrapper").style.borderColor = "#FBFF49";
            document.getElementById("startRecordingBtn").innerHTML = "Start<br>Recording";
            document.getElementById("startRecordingBtn").style.backgroundColor = "#88f21e";
            document.getElementById("startRecordingBtn").style.color = "black";
            document.getElementById("saveRecording").style.display = "flex";
            /* Display current date & time */
            /*        var currentTime = new Date().toLocaleTimeString([], {hour: '2-digit', minute: '2-digit'});
            */
            var currentTime = new Date().toLocaleTimeString('en-US', {
                hour: 'numeric',
                minute: 'numeric',
                hour12: true
            });
            var currentDate = new Date().toLocaleDateString();
            var dateAndTime = currentDate + ', ' + currentTime;
            document.getElementById("currentTime").innerHTML = dateAndTime;
        } else {
            startRecordingBoolean = true;
            document.getElementById("startRecordingWrapper").style.borderColor = "#F31212";
            document.getElementById("startRecordingBtn").innerHTML = "Stop<br>Recording";
            document.getElementById("startRecordingBtn").style.backgroundColor = "#F31212";
            document.getElementById("startRecordingBtn").style.color = "#FBFF49";
            /*      var x = setInterval(leadTimeCounter, 1000);    
                    function leadTimeCounter() {
                    var y = document.getElementById("leadTimeNum").value;
                    if(y >=1) {  
                        var a = --y;
                        document.getElementById("leadTimeNum").value = a;
                    } else {
                        clearInterval(x);
                    } 
                    }
                */
        }
    }



    /* Tracks */
    function showTracks(y) {
        var a;
        if (mainPanelInitialized == false) {
            a = 58;
        } else {
            a = 58 + y;
        }
        mainPanelInitialized = true;
        b = a.toString() + 'px';


        document.getElementById("tracksContainer").style.bottom = b;
        document.getElementById("tracksContainer").style.display = "flex";
        document.getElementById("closeTracks").style.display = "block";

    }

    function closeTracks() {
        document.getElementById("tracksContainer").style.display = "none";
        document.getElementById("closeTracks").style.display = "none";
        if (totalMinimizedPanels == 0) {
            mainPanelInitialized = false;
        }
    }
    // end of modified 9/12/2020

    /* Close Recording without saving it */
    function closeRecordNoSave() {
        setLeadTime(5);
        setFollowVideo(null);
        setNewAudioBlob(null);
        setNewVideoBlob(null);
        setShowVideoRecordingDisplay(false);
        setShowStage(true);
        document.getElementById("saveRecording").style.display = "none";
    }

    /* for now switching between stage scene and the one you log into */
    //new code 9/8/2020
    function tempChangeScene(x) {
        switch (x) {
            case 1:
                document.getElementById("stageContainer").style.display = "flex";
                document.getElementById("twoGuests").style.display = "none";
                break;
            case 2:
                document.getElementById("stageContainer").style.display = "none";
                document.getElementById("twoGuests").style.display = "flex";
                document.getElementById("space1").style.width = "282px";
                document.getElementById("space2").style.width = "282px";
                document.getElementById("space3").style.width = "282px";
                document.getElementById("space4").style.width = "0";
                document.getElementById("space4").style.display = "none";
                break;
            case 3:
                document.getElementById("stageContainer").style.display = "none";
                document.getElementById("twoGuests").style.display = "flex";
                document.getElementById("space1").style.width = "212px";
                document.getElementById("space2").style.width = "212px";
                document.getElementById("space3").style.width = "212px";
                document.getElementById("space4").style.width = "212px";
                document.getElementById("space4").style.display = "flex";
                break;
        }


    }

    

    /* Mixer show/close */

    // modified code for 9/12/2020


    function showMixer(y) {
        var a;
        if (mainPanelInitialized == false) {
            a = 58;
        } else {
            a = 58 + y;
        }
        mainPanelInitialized = true;
        b = a.toString() + 'px';
        document.getElementById("mixerPanel").style.bottom = b;
        document.getElementById("mixerPanel").style.display = "flex";

    }

    function closeMixer() {
        //  document.getElementById("mixerPanel").style.bottom = "-5600px";
        document.getElementById("mixerPanel").style.display = "none";
        if (totalMinimizedPanels == 0) {
            mainPanelInitialized = false;
        }
    }

    // end of modified code 9/12/2020

    // Minimize or maximize

    function minimizeRecord() {
        document.getElementById("minimizedPanels").style.display = "flex";
        document.getElementById("minimizedRecord").style.display = "flex";
        totalMinimizedPanels++;
        closeRecord();
    }

    function maximizeRecord() {

        document.getElementById("minimizedRecord").style.display = "none";
        totalMinimizedPanels--;
        if (totalMinimizedPanels == 0) {
            document.getElementById("minimizedPanels").style.display = "none";
            differenceInPositioningRecord = 0;
            showRecord(differenceInPositioningRecord);
        } else {
            differenceInPositioningRecord = -30;
            showRecord(differenceInPositioningRecord);
        }
    }

    function minimizeMixer() {
        document.getElementById("minimizedPanels").style.display = "flex";
        document.getElementById("minimizedMixer").style.display = "flex";
        totalMinimizedPanels++;
        closeMixer();
    }

    function maximizeMixer() {

        document.getElementById("minimizedMixer").style.display = "none";
        totalMinimizedPanels--;
        if (totalMinimizedPanels == 0) {
            document.getElementById("minimizedPanels").style.display = "none";
            differenceInPositioningMixer = 0;
            showMixer(differenceInPositioningMixer);
        } else {
            differenceInPositioningMixer = 30;
            showMixer(differenceInPositioningMixer);
        }
    }

    function minimizeTracks() {
        document.getElementById("minimizedPanels").style.display = "flex";
        document.getElementById("minimizedTracks").style.display = "flex";
        totalMinimizedPanels++;
        closeTracks();
    }

    function maximizeTracks() {

        document.getElementById("minimizedTracks").style.display = "none";
        totalMinimizedPanels--;
        if (totalMinimizedPanels == 0) {
            document.getElementById("minimizedPanels").style.display = "none";
            differenceInPositioningTracks = 0;
            showTracks(differenceInPositioningTracks);
        } else {
            differenceInPositioningTracks = 30;
            showTracks(differenceInPositioningTracks);
        }
    }

    // new code
    window.onload = function () {
        var masterSlider = document.getElementById("controlPanelMasterVolumeSlider");
        masterSlider.addEventListener("input", function () {
            document.body.style.setProperty("--sliderImage", "url('cpmv" + this.value + ".png')");
        });
        //new code 9/18/2020
        tempChatBox(3);
        //end of new code 9/18/2020
    }

    function displayFeatures() {
        document.getElementById("featuresPanel").style.display = "flex";
    }

    function displayMixer() {
        document.getElementById("mixerPanel").style.display = "flex";
        document.getElementById("closeMixer").style.display = "flex";
    }

    function displayRecording() {
        document.getElementById("recordingPanel").style.display = "flex";
    }

    function displayTracks() {
        document.getElementById("tracksContainer").style.display = "flex";
        document.getElementById("closeTracks").style.display = "block";
    }

    function displayRecordingInProcess() {
        document.getElementById("recordingPanel").style.display = "none";
        document.getElementById("recordingInProcessPanel").style.display = "flex";
        // countdown
        var y = document.getElementById("leadTimeNum").value;
        document.getElementById("leadTimeNumCountdown").innerHTML = y;
        var x = setInterval(leadTimeCounter, 1000);

        function leadTimeCounter() {
            if (y >= 1) {
                var a = --y;
                document.getElementById("leadTimeNumCountdown").innerHTML = a;
                setLeadTime(a);
            } else {
                clearInterval(x);
            }
        }
    }

    function displaySaveRecording() {
        document.getElementById("recordingInProcessPanel").style.display = "none";
        document.getElementById("saveRecording").style.display = "flex";
    }

    // new code 9/18/2020
    function tempChatBox(x) {
        switch (x) {
            case 1:
                document.getElementById("guestChatBox1").style.display = "flex";
                document.getElementById("guestChatBox2").style.display = "none";
                document.getElementById("guestChatBox3").style.display = "none";
                document.getElementById("guestChatBox4").style.display = "none";
                document.getElementById("guestChatBox5").style.display = "none";
                break;
            case 2:
                document.getElementById("guestChatBox1").style.display = "flex";
                document.getElementById("guestChatBox2").style.display = "flex";
                document.getElementById("guestChatBox3").style.display = "none";
                document.getElementById("guestChatBox4").style.display = "none";
                document.getElementById("guestChatBox5").style.display = "none";
                break;
            case 3:
                document.getElementById("guestChatBox1").style.display = "flex";
                document.getElementById("guestChatBox2").style.display = "flex";
                document.getElementById("guestChatBox3").style.display = "flex";
                document.getElementById("guestChatBox4").style.display = "none";
                document.getElementById("guestChatBox5").style.display = "none";
                break;
            case 4:
                document.getElementById("guestChatBox1").style.display = "flex";
                document.getElementById("guestChatBox2").style.display = "flex";
                document.getElementById("guestChatBox3").style.display = "flex";
                document.getElementById("guestChatBox4").style.display = "flex";
                document.getElementById("guestChatBox5").style.display = "none";
                break;
            case 5:
                document.getElementById("guestChatBox1").style.display = "flex";
                document.getElementById("guestChatBox2").style.display = "flex";
                document.getElementById("guestChatBox3").style.display = "flex";
                document.getElementById("guestChatBox4").style.display = "flex";
                document.getElementById("guestChatBox5").style.display = "flex";
                break;
        }
    }

    function closeLeftMenuOptions() {
        var x = document.getElementsByClassName("leftSideMenuChoiceSelected");
        var i;
        for (i = 0; i < x.length; i++) {
          x[i].style.display = "none";
        }
      }
      
      function openLeftMenuOptions(a) {
        closeNav();
        var x = document.getElementsByClassName("leftSideMenuChoiceSelected");
        x[a].style.display = "flex";
      }

    function openProfile() {
        closeNav();
        document.getElementById("stageContainer").style.display = "none";

        document.getElementById("userProfileContainer").style.display = "flex";
        document.getElementById("closeUserProfile").style.display = "block";
        document.getElementById("bandsILeadBtn").style.color = "red";
        document.getElementById("bandsIBelongToBtn").style.color = "white";
    }

    // END OF UI HANDLERS

    //load the playlist after component mounted
    // React.useEffect(() => {
    //     //init playlist
    //     console.log('this');
    //     if (!window.playlist) initPlaylist();
    //     //load the song if any
    //     if (songState.song !== null) {
    //         loadSong(songState.song, window.playlist, window.ee);
    //     }
    //     // forceUpdate();
    // }, [songState.song]);

    React.useEffect(() => {
        //init playlist
        if (!window.playlist) initPlaylist();
    }, []);

    const openSongHandler = async () => {

        startLoader();
        try {
            const song = await fetchSong(openSongName.trim());
            updateSongState({ song: song });
            forceUpdate();
            loadSong(song, window.playlist, window.ee);
        } catch (error) {
            console.log(error);
            window.alert('No such song exists');
            endLoader();
        }
        

    }

    const openSongWithId = async (id) => {
        startLoader();
        try {
            const song = await fetchSong(null, id);
            updateSongState({ song: song });
            forceUpdate();
            loadSong(song, window.playlist, window.ee);
        } catch (error) {
            window.alert('No such song exists');
            endLoader();
        }
    }

    // React.useEffect(() => {

    //     if (isAudioOnlyRecordingChecked || isAudioVideoRecordingChecked) {
    //         document.getElementById('startRecordingBtn').disabled = false;
    //     } else {
    //         document.getElementById('startRecordingBtn').disabled = true;
    //     }

    // }, [isAudioOnlyRecordingChecked, isAudioVideoRecordingChecked])

    //Private handlers
    const playHandler = () => {
        //play all videojs videos and the playlist
        //play videos with different start times according to their track start time
        if (showStage) {

            const timeouts = [];
            var playheadPos = editorPlayhead;
            if (pauseState) playheadPos = pauseState;
            for (let vid of allVideos) {
                const id = `videojs-${vid.id}`;
                const thisVideo = videojs(id);
                //find track for this vid
                var track = playlist.tracks.filter(t => t.name == vid.name)[0];
                var startTime = playheadPos*1000;
                if (track) startTime = track.startTime*1000 - startTime;
                if (startTime < 0) {
                    thisVideo.currentTime(Math.abs(startTime/1000));
                    startTime = 0;
                }
                const timeout = {};
                timeout.id = setTimeout(() => {
                    thisVideo.play();
                }, startTime);
                timeout.time = startTime;
                timeout.videoId = vid.id;
                timeouts.push(timeout);
            }
            setVideoTimeouts(timeouts);

        }

        ee.emit('play');
        setPauseState(null);
    }
    const pauseHandler = () => {
        const pauseTime = currentPlaybackTime;
        setPauseState(pauseTime)
        // pausing the playlist
        ee.emit('pause');


        if (showStage) {

            // stopping the videos
            for (let timeout of videoTimeouts) {
                clearTimeout(timeout.id);
            }

            const videos = document.getElementsByClassName('video-js');
            for (let video of videos) {
                const id = video.id;
                const thisVideo = videojs(id);
                thisVideo.pause();
                thisVideo.currentTime(0);
            }

        }
    }
    const stopHandler = () => {
        setPauseState(null);
        
        if (showStage) {

            for (let timeout of videoTimeouts) {
                clearTimeout(timeout.id);
            }
    
            const videos = document.getElementsByClassName('video-js');
            for (let video of videos) {
                const id = video.id;
                const thisVideo = videojs(id);
                thisVideo.pause();
                thisVideo.currentTime(0);
            }

        }

        ee.emit('stop');
        // setCurrentPlaybackTime(0);
        
    }
    const jumpToStart = () => {
        setPauseState(null);
        ee.emit('rewind');

        if (showStage) {

            //stop video playback
            for (let timeout of videoTimeouts) {
                clearTimeout(timeout.id);
            }

            const videos = document.getElementsByClassName('video-js');
            for (let video of videos) {
                const id = video.id;
                const thisVideo = videojs(id);
                thisVideo.pause();
                thisVideo.currentTime(0);
            }

        }
        
    }
    const jumpToEnd = () => {
        setPauseState(null);
        var longestDuration = 0;
        //get the longest track with its startime
        for (let t of playlist.tracks) {
            const d = t.duration;
            const st = t.startTime;
            const totalDuration = d+st;
            if (totalDuration > longestDuration) longestDuration = totalDuration;
        }
        // stop and seek to this longestDuration 

        if (showStage) {

            //stopping video playback
            for (let timeout of videoTimeouts) {
                clearTimeout(timeout.id);
            }

            const videos = document.getElementsByClassName('video-js');
            for (let video of videos) {
                const id = video.id;
                const thisVideo = videojs(id);
                thisVideo.pause();
                thisVideo.currentTime(0);
            }

        }

        seekPlayback(longestDuration)
    }
    const skipForward = () => {
        setPauseState(null);
        //skips 5 sec froward in time
        const currentTime = currentPlaybackTime;
        $('#btn-stop').click();
        seekPlayback(currentTime+5);

        if (showStage) {

            //play all videojs videos and the playlist
            //play videos with different start times according to their track start time
            const timeouts = [];
            for (let vid of allVideos) {
                const id = `videojs-${vid.id}`;
                const thisVideo = videojs(id);
                //find track for this vid
                var track = playlist.tracks.filter(t => t.name == vid.name)[0];
                var startTime = (currentTime+5)*1000;
                if (track) startTime = track.startTime*1000 - startTime;
                if (startTime < 0) {
                    thisVideo.currentTime(Math.abs(startTime/1000));
                    startTime = 0;
                }
                const timeout = {};
                timeout.id = setTimeout(() => {
                    thisVideo.play();
                }, startTime);
                timeout.time = startTime;
                timeout.videoId = vid.id;
                timeouts.push(timeout);
            }
            setVideoTimeouts(timeouts);

        }

        ee.emit('play', currentTime+5);
    }
    const skipBack = () => {
        setPauseState(null);
        //skips 5 sec back in time
        const currentTime = currentPlaybackTime;
        $('#btn-stop').click();
        seekPlayback(currentTime-5);

        if (showStage) {

            //play all videojs videos and the playlist
            //play videos with different start times according to their track start time
            const timeouts = [];
            for (let vid of allVideos) {
                const id = `videojs-${vid.id}`;
                const thisVideo = videojs(id);
                //find track for this vid
                var track = playlist.tracks.filter(t => t.name == vid.name)[0];
                var startTime = (currentTime-5)*1000;
                if (track) startTime = track.startTime*1000 - startTime;
                if (startTime < 0) {
                    thisVideo.currentTime(Math.abs(startTime/1000));
                    startTime = 0;
                }
                const timeout = {};
                timeout.id = setTimeout(() => {
                    thisVideo.play();
                }, startTime);
                timeout.time = startTime;
                timeout.videoId = vid.id;
                timeouts.push(timeout);
            }
            setVideoTimeouts(timeouts);

        }

        ee.emit('play', currentTime-5);
    }

    const cursorHandler = () => {
        ee.emit("statechange", "cursor");
    }
    const shiftHandler = () => {
        ee.emit("statechange", "shift");
    }
    const selectHandler = () => {
        ee.emit("statechange", "select");
    }
    const exportHandler = () => {
        ee.emit('startaudiorendering', 'wav');
    }
    const saveHandler = async () => {
        if (songState.song !== null) {
            saveSong(songState.song.id);
        } else {
            // save a new song
            const name = window.prompt('Please type a unique name for a new song');
            
            if (name !== null && name !== '') {

                const isValidName = await checkNewSongName(name);
                if (isValidName) {
                    saveNewSong(name);
                } else {
                    window.alert('Song name is not valid');
                }

            }
        }
    }
    const allowEditHandler = () => {
        const newState = !allowEditChecked;
        setAllowEditChecked(newState);
        
        allowEditSwitch(newState);
    }

    const contributeHandler = () => {
        $('#modal-captureOptions').modal('show');
    }

    const addRemoteStream = (remoteStream) => {
        const remotePeerId = remoteStream.peerId;
        
        const container = document.querySelector('#remoteStreamsContainer');
        const streamVideoId = `remoteStream-${remotePeerId}`;
        //check if this streamVideo already exists
        const streamVideo = document.getElementById(streamVideoId);
        if (streamVideo) {
            //if streamVideo already exists, just put the stream in its srcObject
            streamVideo.srcObject = remoteStream.stream;
        }
        else {
            //if no streamVideo already exists, then create one and insert stream in its srcObject
            const ele = document.createElement('div');
            ele.className = 'remoteStream remoteStreamNoSelf';
            ele.id = `remoteStreamContainer-${remotePeerId}`;
            ele.innerHTML = `
                        <video className="streamVideo" autoPlay id="remoteStream-${remotePeerId}"></video>
            `
            container.appendChild(ele);
            const video = document.getElementById(`remoteStream-${remotePeerId}`);
            video.srcObject = remoteStream.stream;
        }
        
    }

    const createSessionHandler =  () => {
        createSession('').then(passcode => {
            window.alert(`session passcode: ${passcode}`);
        }).catch(e => {
            window.alert('there was some error while creating the session');
        });
    }

    const joinSessionHandler = async () => {
        //find session with passcode
        try {
            joinSession(null, joinSessionPasscode.trim());
        } catch (error) {
            window.alert('There was an error while joining the session');
        }
    }

    const leaveSessionHandler = () => {
        // removing all the stream container
        const containers = document.getElementsByClassName('remoteStreamNoSelf');
        for (let container of containers) {
            container.remove();
        }
        clearSong();
        updateAppState({ mode: 'BAND' });
        leaveSession()
    }

    const playForAllHandler = () => {
        broadcast({
            type: "COMMAND",
            data: "PLAY"
        });
        $('#btn-play').click();
        setIsPlayingForAll(true);

        //getting maximum duration of playback to switch playingForAll to false
        var longestDuration = 0;
        //get the longest track with its startime
        for (let t of playlist.tracks) {
            const d = t.duration;
            const st = t.startTime;
            const totalDuration = d+st;
            if (totalDuration > longestDuration) longestDuration = totalDuration;
        }

        setTimeout(() => {
            setIsPlayingForAll(false);
        }, longestDuration*1000);
    }
    const stopForAllHandler = () => {
        broadcast({
            type: "COMMAND",
            data: "STOP"
        });
        $('#btn-stop').click();
        setIsPlayingForAll(false);
    }

    //Handling recording
    const recordAudioVideoHandler = () => {
        setNewRecordingName(getDateString());
        setRecordingType('AUDIOVIDEO');
        setShowVideoRecordingDisplay(true);
    }
    React.useEffect(() => {
        if (showVideoRecordingDisplay) {
            setNewAudioBlob(null);
            if (mediaStream && !isCalling) stopMediaStream(mediaStream);
            const leadTimeGetter = () => {
                const val = document.getElementById("leadTimeNum").value;
                return val;
            }
            captureVideo(setNewVideoBlob, '#webcam', null, "#stopRecordingBtn", 'videojs-newCapturedVideo', leadTimeGetter);

            // handling playback while recording
            const lead = document.getElementById("leadTimeNum").value;
            const startPlaybackForRecording = () => {

                if (followVideo !== null) {

                    // get the videojs id from follow video id
                    const id = `videojs-${followVideo.id}`;
                    const vid = videojs(id);
                    // get the startTime of audio of this video
                    const audio = playlist.tracks.filter(t => t.name == followVideo.name)[0];
                    setTimeout(() => {
                        vid.play();
                    }, audio.startTime*1000);

                }

                playlist.play();
            }
            setTimeout(startPlaybackForRecording, lead*1000);

        }
    }, [showVideoRecordingDisplay]);

    // React.useEffect(() => {
    //     if (recordingType == 'AUDIOVIDEO') {
    //         setNewAudioBlob(null);
    //         if (mediaStream && !isCalling) stopMediaStream(mediaStream);
    //         setShowVideoRecordingDisplay(true);
    //     } else if (recordingType == 'AUDIO') {
    //         setNewVideoBlob(null);
    //         if (mediaStream && !isCalling) stopMediaStream(mediaStream);
    //         setShowVideoRecordingDisplay(false);
    //     }
    // }, [recordingType]);


    const recordAudioOnlyHandler = () => {
        setNewRecordingName(getDateString());
        // setRecordingType('AUDIO');
        const leadTimeGetter = () => {
            return document.getElementById("leadTimeNum").value;
        }
        
        recordHandler(ee, null, '#stopRecordingBtn', setNewAudioBlob, leadTimeGetter);

        // handling playback while recording
        const lead = document.getElementById("leadTimeNum").value;
        const startPlaybackForRecording = () => {

            // if (followVideo !== null) {

            //     // get the videojs id from follow video id
            //     const id = `videojs-${followVideo.id}`;
            //     const vid = videojs(id);
            //     // get the startTime of audio of this video
            //     const audio = playlist.tracks.filter(t => t.name == followVideo.name)[0];
            //     setTimeout(() => {
            //         vid.play();
            //     }, audio.startTime*1000);

            // }

            playlist.play();
        }
        setTimeout(startPlaybackForRecording, lead*1000);

    }
    const startRecordingHandler = () => {
        //handling countdown display
        startRecording();
        setIsRecording(true);
        const lead = document.getElementById("leadTimeNum").value;
        const startPlaybackForRecording = () => {
            // get the videojs id from follow video id
            const followVideo = getFollowVideo();
            const id = `videojs-${followVideo.id}`;
            const vid = videojs(id);
            // get the startTime of audio of this video
            const audio = playlist.tracks.filter(t => t.name == followVideo.name)[0];
            playlist.play();
            setTimeout(() => {
                vid.play();
            }, audio.startTime*1000);
        }
        setTimeout(startPlaybackForRecording, lead*1000);

        // broadcasting recording info
        broadcast({
            type: 'INFO',
            data: {
                peerId: thisPeer.id,
                info: 'RECORDING START'
            }
        });
    }
    const stopRecordingHandler = () => {
        setLeadTime(5);
        setNewRecordingName(getDateString());
        document.getElementById('saveRecording').style.display = 'flex';
        setIsReadyToRecord(false);
        setIsRecording(false);
        // setDisplay('webcamContainer', false);
        $('#btn-stop').click();

        // broadcasting recording info
        broadcast({
            type: 'INFO',
            data: {
                peerId: thisPeer.id,
                info: 'RECORDING STOP'
            }
        });
    }

    // Adding video and audio handler
    const checkNewRecordingName = (name) => {
        const names = playlist.tracks.map(t => t.name);
        const videoNames = allVideos.map(vid => vid.name);
        if (name == '') return false;
        if (names.indexOf(name) !== -1) {
            return false
        }
        if (videoNames.indexOf(name) !== -1) {
            return false
        }
        return true;
    }
    const addVideoHandler = async () => {
        //adds video along with its audio track to the song
        //get the video blob, extract audio, save the audio into newTracks and load into playlist, 
        //save video into newVideos, and load into the video views
        startLoader();
        if (checkNewRecordingName(newRecordingName)) {

            //create track id from name by removing existing spaces
            const nameSplit = newRecordingName.split(' ');
            var TrackId = '';
            for (let substr of nameSplit) {
                TrackId += substr;
            }

            const audioBlob = await extractAudioFromVideo(newVideoBlob);
            const videoUrl = URL.createObjectURL(newVideoBlob);
            setNewTracks([...newTracks, {blob: audioBlob, name: newRecordingName.trim(), id: TrackId}]);
            setNewVideos([...newVideos, {blob: newVideoBlob, name: newRecordingName.trim(), id: TrackId}]);
            setAllVideos([...allVideos, {src: videoUrl, name: newRecordingName.trim(), id: TrackId}]);

            //load audio
            playlist.load([
                {
                    "src": audioBlob,
                    "name": newRecordingName.trim(),
                }
            ]).then(() => {
                //clear newVideoBlob
                setNewVideoBlob(null);
                endLoader();
                playlist.initExporter();
            });
            
            //video is already added from the upadate in allVideos global array. Videos in editSong comp are updated as listening to
            // allVideos



        }
        else {
            endLoader();
            window.alert('Invalid Video Name!');
        }

    }
    const addAudioHandler = async () => {
        //adds video along with its audio track to the song
        //get the video blob, extract audio, save the audio into newTracks and load into playlist, 
        //save video into newVideos, and load into the video views
        startLoader();
        if (checkNewRecordingName(newRecordingName)) {

            //create track id from name by removing existing spaces
            const nameSplit = newRecordingName.split(' ');
            var TrackId = '';
            for (let substr of nameSplit) {
                TrackId += substr;
            }

            setNewTracks([...newTracks, {blob: newAudioBlob, name: newRecordingName.trim(), id: TrackId}]);

            //load audio
            playlist.load([
                {
                    "src": newAudioBlob,
                    "name": newRecordingName.trim(),
                }
            ]).then(() => {
                //clear newAudioBlob
                setNewAudioBlob(null);
                endLoader();
                playlist.initExporter();
            });
            
            //video is already added from the upadate in allVideos global array. Videos in editSong comp are updated as listening to
            // allVideos



        }
        else {
            endLoader();
            window.alert('Invalid Audio Name!');
        }

    }
    const addNewRecordingHandler = async () => {
        setFollowVideo(null);
        setLeadTime(5);
        setShowVideoRecordingDisplay(false);
        if (newVideoBlob) {
            addVideoHandler();
        }
        if (newAudioBlob) {
            addAudioHandler();
        }
        closeRecordNoSave();
    }

    const showStageHandler = () => {
        setShowStreams(false);
        setShowStage(true);
    }
    
    const showStreamsHandler = () => {
        setShowStage(false);
        setShowStreams(true);
    }

    const showLessStreamsHandler = () => {
        setShowStage(false);
        setShowStreams(true);
        setShowTopStreamsDisplay(true);
    }
    const showMoreStreamsHandler = () => {
        setShowStage(false);
        setShowStreams(true);
        setShowTopStreamsDisplay(false);
    }

    const followVideoSelector = (i) => {
        setFollowVideo(allVideos[i]);
    }


    const mouseOverFollowVideoHandler = (i) => {
        const container = document.getElementById(`character030${i}`);
        container.classList.add('greenBorder');
    }
    const mouseLeaveFollowVideoHandler = (i) => {
        const container = document.getElementById(`character030${i}`);
        container.classList.remove('greenBorder');
    }

    React.useEffect(() => {

        $('#videoContainerCollapsible').collapse('show');
        $('#playlistContainerCollapsible').collapse('show');
        $('#guestStreamsContainerCollapsible').collapse('show');
    }, []);

    React.useEffect(() => {

        //handle switching streams display by number of streams
        if (remoteStreams.length < 5 && remoteStreams.length > 0) {
            
            setShowTopStreamsDisplay(true);
        } else {
            setShowTopStreamsDisplay(false);
        }

    }, [remoteStreams]);

    React.useEffect(() => {

        async function handler() {
            if (isCalling && songState.song !== null) {

                const sessionRef = await db.collection('sessions').doc(thisSessionId);
                //check if the new loaded song id is different than the session songId
                const session = await sessionRef.get();
                const sessionData = session.data();
                if (sessionData.songId !== songState.song.id) {
    
                    //update the session songId
                    sessionRef.update({ songId: songState.song !== null ? songState.song.id : null })
                    .then(doc => {
    
                    }).catch(e => window.alert(e.message));
    
                }
    
            }
        }
        handler();

    }, [songState.song]);

    React.useEffect(() => {
        
        if (isCalling) {
            document.getElementById('btn-startSession')
        }

    }, [isCalling]);

    return (
        <div id="container">
            <header>
                <img src="../assets/logo.png" alt="Stagetrack Studio" id="logo" />
                <div id="session">
                    <input disabled={isCalling?false:true} onClick={leaveSessionHandler} type="image" src="../assets/sessionLeave.png" className="session" alt="Leave Session" />
                    <input type="image" src="../assets/sessionPause.png" className="session" alt="Pause Session" />
                    <input disabled={isCalling?true:false} onClick={createSessionHandler} type="image" src="../assets/sessionStart.png" className="session" alt="Start Session" />
                </div>
                <div id="bandName">{songState.song !== null ? songState.song.bandName : ''}: {songState.song !== null ? songState.song.name : ''}</div>
                {
                    isCalling && thisSessionData !==null ? 
                        <p>{`session passcode: ${thisSessionData.passcode}` }</p>
                    : null
                }
            </header>

            <div id="contentContainer">

                <aside id="nav_side">
                    <div id="mySidepanel" className="sidepanel">
                        <a href="javascript:void(0)" className="closebtn" onClick={closeNav}>&times;</a>
                        
                        <a onClick={openProfile} href="#">Profile</a>
                        <a href="#" onClick={() => openLeftMenuOptions(3)}>Admin</a>
                        <a href="#" onClick={() => openLeftMenuOptions(2)}>Notes</a>
                        <a href="#" onClick={() => openLeftMenuOptions(1)}>Resource Library</a>
                        <a href="#" onClick={() => openLeftMenuOptions(0)}>Song Library</a>

                        <a href="http://showexample.co/bandLogin.html">Band</a>
                        <a href="http://showexample.co/actorLogin.html">Actor</a>
                        <a href="http://showexample.co/register.html">Register</a>
                        {/* <a href="vid website.7z" download>Files</a> */}
                        <a href="http://showexample.co/splashPage.html">Splash</a>
                        <a href="http://showexample.co/vendorShowcase.html">Vendor</a>
                        <a href="http://showexample.co/store.html">Store</a>

                        <a className="nav-link" href="#!" onClick={signOut}>Sign Out</a>
                        <input className="form-control" id="inp-songId" size="40" onInput={(e) => {setOpenSongName(e.target.value)}} placeholder="Song name"/>
                        <button type="button" onClick={openSongHandler}>Open song</button>

                        <div style={{margin: '10px'}} className="btn-group dropright">
                            <button type="button" className="btn btn-secondary dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                All Songs
                            </button>
                            <div className="dropdown-menu">
                                {
                                    allSongs.map(song => {
                                        return (
                                            <a key={`allSongs-${song.id}`} className="nav-link" href="#!" onClick={(e) => openSongWithId(song.id)}>{song.name}</a>
                                        )
                                    })
                                }
                            </div>
                        </div>

                        <button type="button" onClick={() => { clearSong(); forceUpdate() }}>New song</button>
                        <input className="form-control" id="inp-sessionPasscode" size="40" onInput={(e) => {setJoinSessionPasscode(e.target.value)}} placeholder="session passcode"/>
                        <button type="button" onClick={joinSessionHandler}>Join session</button>
                        <hr/>
                        <button type="button" onClick={showStageHandler}>Show Stage</button>
                        <button style={isCalling&&showTopStreamsDisplay?{display: 'flex'}:{display: 'none'}} onClick={showStreamsHandler}>Show Streams</button>
                        
                        <div className="navbar">
                            <div className="dropdown">
                                <button className="dropbtn">...
                                    <i className="fa fa-caret-down"></i>
                                </button>
                                <div className="dropdown-content">
                                    <a href="index.html">Home</a>
                                    <a href="bandLogin.html">Band</a>
                                    <a href="actorLogin.html">Actor</a>
                                    <a href="register.html">Register</a>
                                    <a href="vid website.7z" download>Files</a>
                                    <button onClick={() => tempChangeScene(1)}>Stage</button>
                                    <button onClick={() => tempChangeScene(2)}>2 Guests</button>
                                    <a href="splashPage.html">Splash</a>
                                    <a href="vendorShowcase.html">Vendor</a>


                                </div>
                            </div>
                        </div>
                    </div>

                    <button className="openbtn" id="openbtn" onClick={openNav}>&#9776;</button>

                </aside>

                {/* song library */}
                <div className="leftSideMenuChoiceSelected">
                    <a href="javascript:void(0)" className="closeLeftMenuOption" onClick={closeLeftMenuOptions}>&times;</a>
                    <div className="lSMCSTitleContainer">
                        <div className="lSMCSTitle">Song Library</div>
                        <div className="arrow-down"></div>
                    </div>

                    {
                        allBands.map(band => {
                            return (
                                <React.Fragment key={band.id}>
                                    <div className="lSMCSNameContainer">
                                        <div className="lSMCSBandName">{band.name}</div>
                                    </div>

                                    {
                                        allSongs.filter(s => s.bandId == band.id).map(song => {
                                            return (
                                                <div key={`mySongs-${song.id}`} className="lSMCSSongName">
                                                    <p>{song.name}</p>
                                                    <div className="editSelectBtns">
                                                        <a href="#">Edit</a>
                                                        <a onClick={(e) => openSongWithId(song.id)} href="#" className="redColorText">Select</a>
                                                    </div>
                                                </div>
                                            )
                                        })
                                    }
                                    
                                </React.Fragment>
                            )
                        })
                    }

                </div>

                <div className="leftSideMenuChoiceSelected">
                    <a href="javascript:void(0)" className="closeLeftMenuOption" onClick={closeLeftMenuOptions}>&times;</a>
                    <div className="lSMCSTitleContainer">
                        <div className="lSMCSTitle">Resource Library</div>
                        <div className="arrow-down"></div>
                    </div>

                    <div className="lSMCSNameContainer">
                        <div className="lSMCSLastName">[Last Name], </div>
                        <div className="lSMCSFirstName">[First Name]</div>
                    </div>
                    <div className="lSMCSTime">
                        <p>Chord Sheet</p>
                        <div className="editSelectBtns">
                            <a href="#">Edit</a>
                            <a href="#">Select</a>
                        </div>
                    </div>
                    <div className="lSMCSSongName">
                        <p>You Wreck Me-Lyrics</p>
                        <div className="editSelectBtns">
                            <a href="#">Edit</a>
                            <a href="#" className="redColorText">Select</a>
                        </div>
                    </div>

                    <div className="lSMCSNameContainer">
                        <div className="lSMCSBandName">[Band Name]</div>
                    </div>
                    <div className="lSMCSTime">
                        <p>Exercise Sheet</p>
                        <div className="editSelectBtns">
                            <a href="#">Edit</a>
                            <a href="#">Select</a>
                        </div>
                    </div>
                    <div className="lSMCSSongName">
                        <p>Receipt-Guitar</p>
                        <div className="editSelectBtns">
                            <a href="#">Edit</a>
                            <a href="#" className="redColorText">Select</a>
                        </div>
                    </div>

                </div>

                {/* notes */}
                <div className="leftSideMenuChoiceSelected">
                    <a href="javascript:void(0)" className="closeLeftMenuOption" onClick={closeLeftMenuOptions}>&times;</a>
                    <div className="lSMCSTitleContainer">
                        <div className="lSMCSTitle">Notes</div>
                        <div className="arrow-down"></div>
                    </div>
                    <div className="lSMCSNameContainer">
                        <div className="lSMCSLastName">08/28/20 - [Topic]</div>
                    </div>
                    <div className="lSMCSNotes">
                        <p>Note note note note note</p>
                    </div>
                    <div className="lSMCSNameContainer">
                        <div className="lSMCSLastName">08/29/20 - [Topic]</div>
                    </div>
                    <div className="lSMCSNotes">
                        <p>Note note note note note note</p>
                    </div>

                </div>

                {/* Admin */}
                <div className="leftSideMenuChoiceSelected">
                    <a href="javascript:void(0)" className="closeLeftMenuOption" onClick={closeLeftMenuOptions}>&times;</a>
                    <div className="lSMCSTitleContainer">
                        <div className="lSMCSTitle">Admin</div>
                        <div className="arrow-down"></div>
                    </div>
                    <div className="adminHideOptionsTitle">
                        <p className="redColorText">Hide</p>
                    </div>
                    <div className="adminHideActualOptions">
                        <div>
                            <input type="checkbox" name="" id="" />
                            <label>Band Name</label>
                        </div>
                        <div>
                            <input type="checkbox" name="" id="" />
                            <label>Chat box</label>
                        </div>
                        <div>
                            <input type="checkbox" name="" id="" />
                            <label>Scrolling Banner</label>
                        </div>
                    </div>
                    <div className="adminSetupOptions">
                        <a href="#" className="redColorText">Set-up Band/Musician Profile</a>
                        <a href="#" className="redColorText">Set-up Recurring Practice</a>
                    </div>
                </div>

                <main>
                    
                    <div className="mainTop">

                        {
                            showVideoRecordingDisplay ?
                                <VideoRecordingDisplay newVideoBlob={newVideoBlob} followVideo={followVideo} />
                            :
                            
                                
                                    showStage ?
                                        <Stage allVideos={allVideos} />
                                    : showStreams ? 
                                        showTopStreamsDisplay ? 
                                            <TopStreamsDisplay />
                                        : <StreamsGrid />
                                    : null
                                
                            
                        }

                        {/* profile, adding bands, editing bands etc */}
                        <div id="userProfileContainer">
                            
                            <Profile/>

                        </div>

                    </div>


                    <div className="mainBottom" id="mainBottom">
                        <div id="saveRecording">
                            <button id="closeRecordingNoSave" onClick={closeRecordNoSave}>Close without<br/>
                                Saving</button>
                            <p>Name your new recording</p>
                            <div id="saveInputOutsideWrapper">
                                <div id="saveInputWrapper">
                                    <input type="text" value={newRecordingName} onChange={(e) => setNewRecordingName(e.target.value)} />
                                </div>
                                <div id="currentTime"></div>
                            </div>

                            <button onClick={addNewRecordingHandler} id="saveRecordingBtn">Add to Tracks</button>
                        </div>
                        
                        <div id="saveRecording">
                            <h3>Save Tracks</h3>
                            <button id="closeRecordingNoSave" onClick={closeRecordNoSave}>Close without<br/>
                                Saving</button>
                            <p>Name your new recording</p>
                            <div id="saveInputOutsideWrapper">
                                <div id="saveInputWrapper">
                                    <input type="text" />
                                </div>
                            </div>
                            <button id="saveRecordingBtn">Add to Tracks and<br/> Save to Library</button>
                        </div>
                        
                        <div id="mixerPanel">
                            <div id="mixerPanelHeading">Tracking</div>
                            <div id="mixerAudioSettings">
                                <p id="mixerAudioSettingsLabel">Audio Settings</p>
                                <p id="inputGainLabel">Input Gain</p>
                                <div id="mixerInputGainColor">
                                    <input type="range" min="1" max="100" className="mixerInputGainColorSlider" />
                                </div>
                                <div id="mixerInputGainBlue">
                                    <input type="range" min="1" max="100" className="mixerInputGainBlueSlider" />
                                </div>
                                <input type="image" src="../assets/mixerInternalMic.png" />
                            </div>

                            <div id="mixerMasterMix">
                                <h3>Master Mix</h3>
                                <label className="mixerMasterSwitch">
                                    <input type="checkbox" defaultChecked={true} />
                                    <span className="mixerMasterSlider round"></span>
                                </label>
                                <div id="mixerMasterSwitchToggle">
                                    <p>Disabled</p>
                                    <p>Enabled</p>
                                </div>
                                <h4>Master Mix Assign</h4>
                                <button id="mixerMasterHost">Host</button>
                            </div>
                            <div id="mixerTrackContainer">
                                <div className="mixerTrackInner">
                                    <div className="mixerTrackUpper">
                                        <input type="range" min="1" max="100" className="mixerTrackSlider" />
                                    </div>
                                    <div className="mixerTrackLower">Track 1</div>
                                </div>
                                <div className="mixerTrackInner">
                                    <div className="mixerTrackUpper">
                                        <input type="range" min="1" max="100" className="mixerTrackSlider" />
                                    </div>
                                    <div className="mixerTrackLower">Track 2</div>
                                </div>
                                <div className="mixerTrackInner">
                                    <div className="mixerTrackUpper">
                                        <input type="range" min="1" max="100" className="mixerTrackSlider" />
                                    </div>
                                    <div className="mixerTrackLower">Track 3</div>
                                </div>
                                <div className="mixerTrackInner">
                                    <div className="mixerTrackUpper">
                                        <input type="range" min="1" max="100" className="mixerTrackSlider" />
                                    </div>
                                    <div className="mixerTrackLower">Track 4</div>
                                </div>
                                <div className="mixerTrackInner">
                                    <div className="mixerTrackUpper">
                                        <input type="range" min="1" max="100" className="mixerTrackSlider" />
                                    </div>
                                    <div className="mixerTrackLower">Track 5</div>
                                </div>
                                <div className="mixerTrackInner">
                                    <div className="mixerTrackUpper">
                                        <input type="range" min="1" max="100" className="mixerTrackSlider" />
                                    </div>
                                    <div className="mixerTrackLower">Track 6</div>
                                </div>
                                <div className="mixerTrackInner">
                                    <div className="mixerTrackUpper">
                                        <input type="range" min="1" max="100" className="mixerTrackSlider" />
                                    </div>
                                    <div className="mixerTrackLower">Track 7</div>
                                </div>
                                <div className="mixerTrackInner">
                                    <div className="mixerTrackUpper">
                                        <input type="range" min="1" max="100" className="mixerTrackSlider" />
                                    </div>
                                    <div className="mixerTrackLower">Track 8</div>
                                </div>
                            </div>
                            <div id="mixerMasterSliderContainer">
                                <div id="mixerMasterSliderUpper">
                                    <div id="mixerMasterGray">
                                        <input type="range" min="1" max="100" className="mixerMasterSliderGray" />
                                    </div>
                                    <div id="mixerMasterColor"></div>
                                </div>
                                <div id="mixerMasterSliderLower">Master</div>
                            </div>

                            <a href="javascript:void(0)" id="closeMixer" onClick={closeMixer}>&times;</a>
                        </div>

                        
                        <div id="featuresPanel">
                            <h3>Features</h3>
                            <div id="bpmMeasurements">
                                <div id="bpmLabels">
                                    <p>BPM</p>
                                    <p>Count-in</p>
                                    <p>Time Sig</p>
                                </div>
                                <div>
                                    <div id="bpmNum"></div>
                                    <div id="countInNum"></div>
                                    <div id="timeSigContainer">
                                        <div id="timeSigNum1"></div>
                                        <div id="timeSigNum2"></div>
                                    </div>
                                </div>
                            </div>
                            <button id="startMetronomeContainer">
                                <div id="startMetronomeBtn">Start<br/>Metronome</div>
                            </button>
                        </div>

                        <div id="recordingPanel">
                            <h3>Recording</h3>
                            <div id="followTrackContainer">
                                <p>Follow Track</p>
                                <div id="followTrackButtonsContainer">
                                    {
                                        allVideos.map((vid, i) => {
                                            return (
                                                <button key={i} onClick={() => followVideoSelector(i)} onMouseOver={() => mouseOverFollowVideoHandler(i+1)} onMouseLeave={() => mouseLeaveFollowVideoHandler(i+1)} className="followTrackBtns">{i+1}</button>
                                            )
                                        })
                                    }
                                </div>
                            </div>

                            <div id="recordingPanelText">
                                <h2>Recording in</h2>
                                <p>Lead time before count-in</p>
                            </div>
                            <div id="leadTime">
                                <input type="number" id="leadTimeNum" value={leadTime} onChange={(e) => {setLeadTime(e.target.value)}} min="1"></input>
                            </div>


                            <label>
                                <input type="radio" name="recordingChoice" />
                                <button id="startAudioVideoRecordingBtn" className="recordingChoiceBtns" onClick={() => {displayRecordingInProcess(); recordAudioVideoHandler()}}>
                                    <div className="recRecordVideo">Record<br/>Audio/ Video</div>
                                </button>
                            </label>
                            <label>
                                <input type="radio" name="recordingChoice" />
                                <button id="startAudioOnlyRecordingBtn" className="recordingChoiceBtns" onClick={() => {displayRecordingInProcess(); recordAudioOnlyHandler()}}>
                                    <div id="recRecordAudio">Record<br/>Audio only</div>
                                </button>
                            </label>
                            <label>
                                <input type="radio" name="recordingChoice" />
                                <button className="recordingChoiceBtns" onClick={() => {}}>
                                    <div className="recRecordVideo">Record<br/>Video only</div>
                                </button>
                            </label>
                        </div>

                        <div id="recordingInProcessPanel">
                            <div id="leadTime">
                                <img src="../assets/secondBtn04.png" id="leadTimeBg" />
                                <div id="leadTimeNumCountdown"></div>
                            </div>
                            <input type="image" src="../assets/recordingInProcess1.png" />
                            <input type="image" src="../assets/recordingInProcess2.png" />
                            <input id="stopRecordingBtn" type="image" src="../assets/recordingInProcess3.png" onClick={() => {displaySaveRecording(); $('#btn-stop').click()}} />
                        </div>
                        <div id="controlPanelExtra">
                            
                            <div>
                                <a href="#" className="controlPanelExtraLinks" onClick={displayFeatures}>Features</a>
                                <a href="#" className="controlPanelExtraLinks" onClick={displayMixer}>Mixer</a>
                                <a href="#" className="controlPanelExtraLinks" onClick={displayRecording}>Recording</a>
                                <a href="#" className="controlPanelExtraLinks" onClick={displayTracks}>Tracks</a>
                            </div>
                            <div style={{display: 'flex'}}>
                                <button onClick={showStageHandler} className="showStageStudio" >Show Stage</button>
                                <button style={isCalling&&remoteStreams.length<5&&remoteStreams.length>0?{display: 'flex'}:{display: 'none'}} onClick={() => {showStreamsHandler(); showLessStreamsHandler()}} className="showStageStudio" >Show Studio</button>
                                <button style={isCalling?{display: 'flex'}:{display: 'none'}} className="showStageStudio" onClick={() => {showStreamsHandler(); showMoreStreamsHandler()}} >Studio `&gt;` 5</button>
                            </div>

                            
                        </div>
                        
                        <div id="controlPanel">
                            <input onClick={jumpToStart} type="image" src="../assets/mainBtn01.png" className="mainBtns" />
                            <input onClick={skipBack} type="image" src="../assets/mainBtn02.png" className="mainBtns" />
                            <input id="btn-stop" onClick={stopHandler} type="image" src="../assets/mainBtn03.png" className="mainBtns" />
                            <input id="btn-play" onClick={playHandler} type="image" src="../assets/mainBtn04.png" className="mainBtns" />
                            <input id="btn-pause" onClick={pauseHandler} type="image" src="../assets/mainBtn05.png" className="mainBtns" />
                            <input onClick={skipForward} type="image" src="../assets/mainBtn06.png" className="mainBtns" />
                            <input onClick={jumpToEnd} type="image" src="../assets/mainBtn07.png" className="mainBtns" />

                            <div className="flexItem tool" id="btn-upload" onClick={saveHandler}>
                                            <svg width="1.5em" height="1.5em" viewBox="0 0 16 16" className="bi bi-download" fill="white" xmlns="http://www.w3.org/2000/svg">
                                                <path fillRule="evenodd" d="M4.406 3.342A5.53 5.53 0 0 1 8 2c2.69 0 4.923 2 5.166 4.579C14.758 6.804 16 8.137 16 9.773 16 11.569 14.502 13 12.687 13H3.781C1.708 13 0 11.366 0 9.318c0-1.763 1.266-3.223 2.942-3.593.143-.863.698-1.723 1.464-2.383zm.653.757c-.757.653-1.153 1.44-1.153 2.056v.448l-.445.049C2.064 6.805 1 7.952 1 9.318 1 10.785 2.23 12 3.781 12h8.906C13.98 12 15 10.988 15 9.773c0-1.216-1.02-2.228-2.313-2.228h-.5v-.5C12.188 4.825 10.328 3 8 3a4.53 4.53 0 0 0-2.941 1.1z"/>
                                                <path fillRule="evenodd" d="M7.646 5.146a.5.5 0 0 1 .708 0l2 2a.5.5 0 0 1-.708.708L8.5 6.707V10.5a.5.5 0 0 1-1 0V6.707L6.354 7.854a.5.5 0 1 1-.708-.708l2-2z"/>
                                                </svg>            
                                        </div>

                            <input style={isPlayingForAll?{display:'flex'}:{display:'none'}} onClick={stopForAllHandler} type="image" src="../assets/playForAllBtn.png" id="ctrlPlayForAll" />
                            <input style={isPlayingForAll?{display:'none'}:{display:'flex'}} onClick={playForAllHandler} type="image" src="../assets/playForAllBtn.png" id="ctrlPlayForAll" />
                            
                            <div id="controlPanelMasterVolume">
                                <input type="range" min="1" max="10" value="2" onChange={() => {return}} id="controlPanelMasterVolumeSlider" />
                            </div>



                            <div id="timer" className="switch">
                                <div id="timerLabels" className="switch">
                                    <p className="timerBar switch">Bar</p>
                                    <p className="timerBeat switch">Beat</p>
                                    <p className="timerTime switch">Time</p>
                                </div>
                                <div id="timerNumbers">
                                    <p className="timerBar switch">1</p>
                                    <p className="timerBeat switch">25</p>
                                    <p className="timerTime switch">00:01:04:69</p>
                                </div>
                            </div>

                            <div id="cpmsContainer">
                                <img src="../assets/cpmsSlider.png" id="cpmsSlider" />
                                <p>Master</p>
                            </div>

                        </div>


                        <div id="tracksContainer">
                            <div id="tracksToolbar">
                                <button onClick={shiftHandler} id="shiftingTrackBtn">Shifting track</button>
                                <button onClick={cursorHandler} id="cursorBtn">Cursor</button>
                            </div>
                            <a href="javascript:void(0)" id="closeTracks" onClick={closeTracks}>&times;</a>
                            <button id="minTracks" onClick={minimizeTracks}></button>
                            <div id="tracksInner">
                                
                                <div id="playlist"></div>

                            </div>
                        </div>


                    </div>
                </main>


                <div id="mySidepane2" className="sidepane2">
                    <a href="javascript:void(0)" className="closechatbtn" onClick={closeChat}>&times;</a>

                    <Chatbox/>

                </div>

                <button className="openchatbtn" id="openchatbtn" onClick={openChat}>Chat</button>

            </div>



        </div>
    )

}