
const StreamBoxes = () => {

    const { mediaStream, remoteStreams, isCalling } = React.useContext(MainContext);

    React.useEffect(() => {

        // resetting all the containers to empty
        const containers = document.getElementsByClassName('bottomBox');
        for (let i=0; i<containers.length; i++) {
            if (i > 1) {
                containers[i].innerHTML = ''
            }
        }

        // only add the remoteStreams if isCalling

        for (let [i, stream] of remoteStreams.entries()) {
            //get container
            const containers = document.getElementsByClassName('bottomBox');
            const container = containers[i+2];
            const remotePeerId = stream.peerId;
            container.innerHTML = '';
            container.innerHTML = `
                <div class="remoteStream remoteStreamNoSelf" id="remoteStreamContainer-${remotePeerId}">
                    <video class="streamVideo" autoPlay id="remoteStream-${remotePeerId}"></video>
                </div>
            `
            const video = document.getElementById(`remoteStream-${remotePeerId}`);
            video.srcObject = stream.stream;
        }
       

    }, [remoteStreams]);

    React.useEffect(() => {
        if (isCalling) {
            const container = document.getElementsByClassName('bottomBox')[1];
            container.innerHTML = `
                <div class="remoteStream" id="selfStreamContainer">
                    <video class="streamVideo" muted autoplay id="selfStream"></video>
                </div>
            `
            //put our stream in the selfStream box
            const selfStream = document.getElementById('selfStream');
            selfStream.srcObject = mediaStream;

        } else {
            // resetting all the containers to empty
            const containers = document.getElementsByClassName('bottomBox');
            for (let i=0; i<containers.length; i++) {
                if (i > 0) {
                    containers[i].innerHTML = ''
                }
            }
        }
    }, [isCalling]);

    return (
        <React.Fragment>

        <div id="newMainContentArea1">
            <div className="newMainContentNotesPanel1">
                <div id="manyGLnotes">
                    <textarea id="newContentTextarea" placeholder="..."></textarea>
                </div>
                <div className="twoGLBtns">
                    <button className="textareaNotesBtns">Keep</button>
                    <button className="textareaNotesBtns">Open</button>
                    <button className="textareaNotesBtns">Upload</button>
                </div>
            </div>
            <div className="newMainContentCaptureWrapper1">
                <div className="newMainContentCaptureInner"></div>
            </div>
        </div>
        <div id="newMainContentArea2">
            <div className="newMainContentCaptureWrapper2">
                <div className="newMainContentCaptureInner"></div>
            </div>
            <div className="newMainContentNotes">
                <div id="manyGLnotes">
                    <textarea id="newContentTextarea" placeholder="..."></textarea>
                </div>
                <div className="twoGLBtns">
                    <button className="textareaNotesBtns">Keep</button>
                    <button className="textareaNotesBtns">Open</button>
                    <button className="textareaNotesBtns">Upload</button>
                </div>
            </div>
            <div className="newMainContentCaptureWrapper2">
                <div className="newMainContentCaptureInner"></div>
            </div>
        </div>
        <div id="newMainContentArea3">
            <div className="newMainContentArea2Onside">
                <div className="newMainContentCaptureWrapper2Onside">
                    <div className="newMainContentCaptureInner"></div>
                </div>
                <div className="newMainContentCaptureWrapper2Onside">
                    <div className="newMainContentCaptureInner"></div>
                </div>
            </div>
            <div className="newMainContentNotes">
                <div id="manyGLnotes">
                    <textarea id="newContentTextarea" placeholder="..."></textarea>
                </div>
                <div className="twoGLBtns">
                    <button className="textareaNotesBtns">Keep</button>
                    <button className="textareaNotesBtns">Open</button>
                    <button className="textareaNotesBtns">Upload</button>
                </div>
            </div>
            <div className="newMainContentCaptureWrapper">
                <div className="newMainContentCaptureInner"></div>
            </div>
        </div>
        <div id="newMainContentArea4">
            <div className="newMainContentArea2Onside">
                <div className="newMainContentCaptureWrapper2Onside">
                    <div className="newMainContentCaptureInner"></div>
                </div>
                <div className="newMainContentCaptureWrapper2Onside">
                    <div className="newMainContentCaptureInner"></div>
                </div>
            </div>
            <div className="newMainContentNotes">
                <div id="manyGLnotes">
                    <textarea id="newContentTextarea" placeholder="..."></textarea>
                </div>
                <div className="twoGLBtns">
                    <button className="textareaNotesBtns">Keep</button>
                    <button className="textareaNotesBtns">Open</button>
                    <button className="textareaNotesBtns">Upload</button>
                </div>
            </div>
            <div className="newMainContentArea2Onside">
                <div className="newMainContentCaptureWrapper2Onside">
                    <div className="newMainContentCaptureInner"></div>
                </div>
                <div className="newMainContentCaptureWrapper2Onside">
                    <div className="newMainContentCaptureInner"></div>
                </div>
            </div>
        </div>
        <div id="newMainContentArea5">
            <div className="newMainContentArea2Onside">
                <div className="newMainContentCaptureWrapper2Onside">
                    <div className="newMainContentCaptureInner"></div>
                </div>
                <div className="newMainContentCaptureWrapper2Onside">
                    <div className="newMainContentCaptureInner" style={{color: 'white'}}>Reserved space - no vid
                        capture here</div>
                </div>
            </div>
            <div className="newMainContentNotes">
                <div id="manyGLnotes">
                    <textarea id="newContentTextarea" placeholder="..."></textarea>
                </div>
                <div className="twoGLBtns">
                    <button className="textareaNotesBtns">Keep</button>
                    <button className="textareaNotesBtns">Open</button>
                    <button className="textareaNotesBtns">Upload</button>
                </div>
            </div>
            <div className="newMainContentAreaXOnside">
                <div className="newMainContentCaptureWrapperXOnside">
                    <div className="newMainContentCaptureInner"></div>
                </div>
                <div className="newMainContentCaptureWrapperXOnside">
                    <div className="newMainContentCaptureInner"></div>
                </div>
                <div className="newMainContentCaptureWrapperXOnside">
                    <div className="newMainContentCaptureInner"></div>
                </div>
                <div className="newMainContentCaptureWrapperXOnside">
                    <div className="newMainContentCaptureInner"></div>
                </div>
            </div>
        </div>
        <div id="newMainContentArea6">
            <div className="newMainContentArea2Onside">
                <div className="newMainContentCaptureWrapper2Onside">
                    <div className="newMainContentCaptureInner"></div>
                </div>
                <div className="newMainContentCaptureWrapper2Onside">
                    <div className="newMainContentCaptureInner"></div>
                </div>
            </div>
            <div className="newMainContentNotes">
                <div id="manyGLnotes">
                    <textarea id="newContentTextarea" placeholder="..."></textarea>
                </div>
                <div className="twoGLBtns">
                    <button className="textareaNotesBtns">Keep</button>
                    <button className="textareaNotesBtns">Open</button>
                    <button className="textareaNotesBtns">Upload</button>
                </div>
            </div>
            <div className="newMainContentAreaXOnside">
                <div className="newMainContentCaptureWrapperXOnside">
                    <div className="newMainContentCaptureInner"></div>
                </div>
                <div className="newMainContentCaptureWrapperXOnside">
                    <div className="newMainContentCaptureInner"></div>
                </div>
                <div className="newMainContentCaptureWrapperXOnside">
                    <div className="newMainContentCaptureInner"></div>
                </div>
                <div className="newMainContentCaptureWrapperXOnside">
                    <div className="newMainContentCaptureInner"></div>
                </div>
            </div>
        </div>
        <div id="newMainContentArea7">
            <div className="newMainContentArea2Onside">
                <div className="newMainContentCaptureWrapper2Onside">
                    <div className="newMainContentCaptureInner"></div>
                </div>
                <div className="newMainContentCaptureWrapper2Onside">
                    <div className="newMainContentCaptureInner" style={{color: 'white'}}>Reserved space - no vid
                        capture here</div>
                </div>
            </div>
            <div className="newMainContentNotes">
                <div id="manyGLnotes">
                    <textarea id="newContentTextarea" placeholder="..."></textarea>
                </div>
                <div className="twoGLBtns">
                    <button className="textareaNotesBtns">Keep</button>
                    <button className="textareaNotesBtns">Open</button>
                    <button className="textareaNotesBtns">Upload</button>
                </div>
            </div>
            <div className="newMainContentAreaXOnside">
                <div className="newMainContentCaptureWrapperXOnsideSmall">
                    <div className="newMainContentCaptureInner"></div>
                </div>
                <div className="newMainContentCaptureWrapperXOnsideSmall">
                    <div className="newMainContentCaptureInner"></div>
                </div>
                <div className="newMainContentCaptureWrapperXOnsideSmall">
                    <div className="newMainContentCaptureInner"></div>
                </div>
                <div className="newMainContentCaptureWrapperXOnsideSmall">
                    <div className="newMainContentCaptureInner"></div>
                </div>
                <div className="newMainContentCaptureWrapperXOnsideSmall">
                    <div className="newMainContentCaptureInner"></div>
                </div>
                <div className="newMainContentCaptureWrapperXOnsideSmall">
                    <div className="newMainContentCaptureInner"></div>
                </div>
            </div>
        </div>
        <div id="newMainContentArea8">
            <div className="newMainContentArea2Onside">
                <div className="newMainContentCaptureWrapper2Onside">
                    <div className="newMainContentCaptureInner"></div>
                </div>
                <div className="newMainContentCaptureWrapper2Onside">
                    <div className="newMainContentCaptureInner"></div>
                </div>
            </div>
            <div className="newMainContentNotes">
                <div id="manyGLnotes">
                    <textarea id="newContentTextarea" placeholder="..."></textarea>
                </div>
                <div className="twoGLBtns">
                    <button className="textareaNotesBtns">Keep</button>
                    <button className="textareaNotesBtns">Open</button>
                    <button className="textareaNotesBtns">Upload</button>
                </div>
            </div>
            <div className="newMainContentAreaXOnside">
                <div className="newMainContentCaptureWrapperXOnsideSmall">
                    <div className="newMainContentCaptureInner"></div>
                </div>
                <div className="newMainContentCaptureWrapperXOnsideSmall">
                    <div className="newMainContentCaptureInner"></div>
                </div>
                <div className="newMainContentCaptureWrapperXOnsideSmall">
                    <div className="newMainContentCaptureInner"></div>
                </div>
                <div className="newMainContentCaptureWrapperXOnsideSmall">
                    <div className="newMainContentCaptureInner"></div>
                </div>
                <div className="newMainContentCaptureWrapperXOnsideSmall">
                    <div className="newMainContentCaptureInner"></div>
                </div>
                <div className="newMainContentCaptureWrapperXOnsideSmall">
                    <div className="newMainContentCaptureInner"></div>
                </div>
            </div>
        </div>
        </React.Fragment>
    )

}