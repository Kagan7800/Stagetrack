
const App = () => {

    const {

        appState,
        updateAppState,
        songState,
        authState,
        signOut,
        fetchSong,
        loadSong,
        updateSongState,
        isCalling,
        leaveCall,
        startLoader,
        endLoader

    } = React.useContext(MainContext);

    // private states
    const [openSongname, setOpenSongName] = React.useState('');

    // private handlers
    const openSongHandler = async () => {

        if (isCalling) {
            const r = window.confirm("Are you sure you want to leave the call?");
            if (!r) return;
            else leaveCall();
        }

        startLoader();
        var song;
        try {
            song = await fetchSong(openSongname);
        } catch (error) {
            window.alert('No such song exists');
            endLoader();
            return
        }
        updateSongState({ song: song });
        updateAppState({ mode: "LOADING" });
        updateAppState({ mode: "EDIT" });
    }

    return (
        <div>
            {
                appState.loading?
                 <div className="loader">
                    <Spinner/>
                </div>
                : null
                
            }

            {/* delete track popup modal */}
            <div className="modal fade" id="deleteTrackModal" tabIndex="-1" role="dialog"
                aria-labelledby="deleteTrackModal" aria-hidden="true">
                <div className="modal-dialog modal-dialog-centered" role="document">
                    <div className="modal-content">
                        <div className="modal-header">
                            <h5 className="modal-title" id="deleteTrackModalTitle">Modal title</h5>
                            
                        </div>
                        <div className="modal-body">
                            Are you sure you want to delete this track?
                        </div>
                        <div className="modal-footer">
                            <button type="button" className="btn btn-secondary" data-dismiss="modal">No</button>
                            <button type="button" id="btn-confirmDeleteTrack" className="btn btn-primary">Delete</button>
                        </div>
                    </div>
                </div>
            </div>

            {/* delete track popup modal */}
            <div className="modal fade" id="emailVerificationModal" tabIndex="-1" role="dialog"
                aria-labelledby="emailVerificationModal" aria-hidden="true">
                <div className="modal-dialog modal-dialog-centered" role="document">
                    <div className="modal-content">
                        <div className="modal-header">
                            <h5 className="modal-title" id="emailVerificationModalTitle">Verification</h5>
                            
                        </div>
                        <div className="modal-body">
                            Please verify your email by clicking on the link sent to your email address
                        </div>
                        <div className="modal-footer">
                            <button type="button" className="btn btn-secondary" data-dismiss="modal">Ok</button>
                        </div>
                    </div>
                </div>
            </div>

            {/* Navigation */}
            {
                appState.mode == 'CREATE'?
                <nav className="navbar navbar-expand-lg navbar-dark static-top" style={{backgroundColor: 'black'}}>
                    <div className="container">
                        <a className="navbar-brand" href="#"><img src="../assets/image_logo.png" height="50px"/></a>
                        <button className="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive"
                            aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
                            <span className="navbar-toggler-icon"></span>
                        </button>
                        {
                            authState.signedIn ? 
                                <div className="collapse navbar-collapse" id="navbarResponsive">
                                    <ul className="navbar-nav ml-auto">
                                        <li className="nav-item active">
                                            <div className="flexHor">
                                                <div className="flexItem">
                                                    <input className="form-control" id="inp-songId" size="40" onInput={(e) => {setOpenSongName(e.target.value)}} placeholder="Song name"/>
                                                </div>
                                                <div className="flexItem">
                                                    <a className="nav-link" href="#!" onClick={openSongHandler}>Open</a>
                                                </div>
                                            </div>
                                        </li>
                                        <li className="nav-item flexItem">
                                            <a className="nav-link" href="#!" onClick={() => updateAppState({mode: "CREATE"})}>Create New</a>
                                        </li>
                                        <li className="nav-item flexItem">
                                            <a className="nav-link" href="#!" onClick={signOut}>Sign Out</a>
                                        </li>
                                    </ul>
                                </div>
                            : null
                        }
                    </div>
                </nav>
                : null
            }

            {/* Components */}
            <div className="">
                {appState.mode == "LOGIN" ? <Login2/> : null}
                {appState.mode == "SIGNUP" ? <Signup2/>: null}
                {appState.mode == "CREATE" ? <CreateSong/>: null}
                {appState.mode == "EDIT" ? <EditSong2/>: null}
                {appState.mode == "BAND" ? <Band/>: null}
                {appState.mode == "PROFILE" ? <Profile/>: null}
            </div>
            
        </div>
    )

}