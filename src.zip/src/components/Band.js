
const Band = (props) => {

    const { authState, 
            signOut,
            updateSongState, 
            updateAppState, 
            allBands, 
            setAllBands, 
            activeBand, 
            setActiveBand,
            thisUserProfile,
    } = React.useContext(MainContext);

    const { joinSession, createSession, thisPeer } = React.useContext(SessionContext);

    const [passcode, setPasscode] = React.useState('');

    const individualPracticeHandler = () => {
        
        updateAppState({ mode: "LOADING" });
        updateAppState({ mode: "EDIT" });

    }

    const joinSessionHandler = async () => {
        //join session with passcode
        
        joinSession(null, passcode).then(() => {
            updateAppState({ mode: 'EDIT' });
        }).catch(e => {

            if(e.message == "NO_STREAM_ERROR") {
                window.alert("There was some error accessing your media devices. Please check the camera and mic settings \nand make sure you have given permissions to access the media devices");
                updateAppState({ mode: 'BAND' });
            }
            else {
                console.log(e.message);
                window.alert("There was some error trying to join a session");
                updateAppState({ mode: 'BAND' });
            }
        });
    }

    const startSessionModalHandler = () => {

        $('#bandSelectionModal').modal('show');

        //get list of all accessible bands
        db.collection('bands').onSnapshot(function(querySnapshot) {
            const objs = [];
            querySnapshot.forEach(function(doc) {

                if (doc.data().createdBy == authState.user.uid ||
                    thisUserProfile.joinedBands.indexOf(doc.id) !== -1
                ) {
                    const obj = Object.assign(doc.data(), { id: doc.id });
                    objs.push(obj);
                }

            });
            setAllBands(objs);
        });

    }

    const startSessionHandler = () => {
        const selectedBandName = document.getElementById('bandSelection').value;

        //get band with this name
        const selectedBand = allBands.filter(b => b.name == selectedBandName)[0];
        if (selectedBand) {

            setActiveBand(selectedBand);

            // creating the session
            createSession(selectedBand.id).then(passcode => {
                // window.alert(`session passcode: ${passcode}`);
                updateAppState({ mode: 'EDIT' });
            }).catch(e => {

                if(e.code == "NO_STREAM_ERROR") {
                    window.alert("There was some error accessing your media devices. Please check the camera and mic settings \nand make sure you have given permissions to access the media devices");
                    updateAppState({ mode: 'BAND' });
                }
                else {
                    window.alert("There was some error trying to create a session");
                    updateAppState({ mode: 'BAND' });
                }

            });

        }

    }

    return (

        <div id="ABcontainer">

            {/* {
                thisPeer == null ?
                <div style={{position: 'fixed', top:'10px', left: '10px'}} className="alert alert-primary" role="alert">
                    Connecting to the server...
                </div>
                : <div style={{position: 'fixed', top:'10px', left: '10px'}} className="alert alert-success" role="alert">
                    Connected!
                </div>
            } */}

            {/* delete track popup modal */}
            <div className="modal fade" id="bandSelectionModal" tabIndex="-1" role="dialog"
                aria-labelledby="bandSelectionModal" aria-hidden="true">
                <div className="modal-dialog modal-dialog-centered" role="document">
                    <div className="modal-content">
                        <div className="modal-header">
                            <h5 className="modal-title" id="bandSelectionModalTitle">Select a band to work on</h5>
                            
                        </div>
                        <div className="modal-body">
                            
                        <div className="form-group">
                            <label>Select Band</label>
                            <select required className="form-control" id="bandSelection">
                                {
                                    allBands.map((band, i) => {
                                        return (
                                            <option key={band.id}>{band.name}</option>
                                        )
                                    })
                                }
                            </select>

                        </div>
        
                        </div>
                        <div className="modal-footer">
                            <button type="button" className="btn btn-secondary" data-dismiss="modal">Cancel</button>
                            {
                                thisPeer !== null ?
                                    <button onClick={startSessionHandler} type="button" className="btn btn-secondary" data-dismiss="modal">Start Session</button>
                                : <div className="spinner-border text-secondary" role="status">
                                        <span className="sr-only">Connecting to the server...</span>
                                    </div>
                            }
                        </div>
                    </div>
                </div>
            </div>

            <div id="bandPageLeftSide">
                <div id="insideBContainer">
                    <div id="welcomeTo">Welcome to</div>
                    <img src="./assets/logoTransformed.png" id="logoTransformed" />
                    <div id="bandPageBandName">{`${thisUserProfile.firstName} ${thisUserProfile.lastName}`}</div>
                    {/* <div id="bandPageStudioNum">Studio [#]</div> */}
                    
                    <div className="passcodeWrapper">
                        <input type="text" id="passcode" placeholder="Enter Session Passcode" value={passcode} onChange={(e) => setPasscode(e.target.value)}></input>
                        
                        {
                            thisPeer !== null ?
                                <img style={{marginRight: '-20px'}} onClick={joinSessionHandler} src="./assets/submitBtn.png" id="bandPageSubmitBtn" />
                            : <div className="spinner-border text-secondary" role="status">
                                    <span className="sr-only">Connecting to the server...</span>
                                </div>
                        }
                    </div>
                    
                    {/* <a onClick={individualPracticeHandler} href="#">Individual Practice</a> */}
                    <a onClick={startSessionModalHandler} href="#">Start Session</a>
                    <a href="https://stagetrack.online/store/">Stagetrack Store</a>
                    <a href="https://stagetrack.online/vendor/">Vendor Showcase</a>
                    <a onClick={signOut} href="#">Log out</a>
                    <a href="terms.html" id="termsLink">Terms & Conditions</a>
                </div>
            </div>
            <div id="bandPageRightSide">
                <div id="bandPageInsideContainerRight">
                    
                    <img src="./assets/bandBg.png" />
                    
                </div>
            </div>
        </div>

    );

}