
const CreateSong = () => {

    const{ captureVideo, createNewsong } = React.useContext(MainContext);

    const [newSongVideoBlob, setNewSongVideoBlob] = React.useState(null);
    const [showPlayback, setShowPlayback] = React.useState(false);
    const [showWebcam, setShowWebcam] = React.useState(true);
    const [isRecording, setIsRecording] = React.useState(false);
    const [recordMenu, setRecordMenu] = React.useState(false);

    const [songName, setSongName] = React.useState('');

    const captureVideoHandler = () => {
        setRecordMenu(true);
        setShowPlayback(false);
        setShowWebcam(true);
        setTimeout(() => {
            captureVideo(setNewSongVideoBlob, '#webcam', '#btn-captureVideoStart', '#btn-captureVideoStop', 'recordedVideoPlayer', () => {return 0});
        }, 100);
    }
    const captureVideoStopHandler = () => {
        setIsRecording(false);
        setShowPlayback(true);
        setShowWebcam(false);
        setTimeout(() => {
            setRecordMenu(false);
        }, 500);
    }
    const createSongHandler = () => {
        // checking name for invalid characters
        var isValid = true;
        // do not allow special characters ':', ',', ':', ';', '.'
        const invalidChars = [':', ',', ':', ';', '.'];
        for(let c of invalidChars) {
            const split = songName.split(c);
            if (split.length > 1) {
                isValid = false;
                break;
            }
        }
        if (songName !== '' && isValid == true) {
            createNewsong(songName, newSongVideoBlob);
        } else {
            window.alert('Song name is invalid');
        }
    }


    return (
        
        <div className="container">
            <form>
                <div className="flexVer">
                    <div className="form-group flexItem">
                        <label>New Song Name</label>
                        <input type="text" className="form-control" id="inp-songName" aria-describedby="songName" onChange={(e) => setSongName(e.target.value)} value={songName}></input>
                        <small id="songName" className="form-text text-muted">Song name should be unique</small>
                    </div>
                    
                    {
                        showPlayback && newSongVideoBlob ?
                            <div style={{width: '320px', height: '240px'}} id="recordedVideoPlayerContainer" className="flexItem">
                                <VideoPlayer controls={true} id='videojs-newSongVideo' width={640} height={480} src={URL.createObjectURL(newSongVideoBlob)}/>
                            </div>
                        : null
                    }
                    
                    {
                        showWebcam ? 
                            <div className="webcam flexItem" id="newSongWebcamContainer">
                                <div className="safeView"></div>
                                <video muted autoPlay id="webcam"></video>
                            </div>
                        : null
                    }
    
                    <button id="btn-captureVideo" type="button" className="btn btn-primary flexItem" onClick={captureVideoHandler} >Capture Video</button>
                    
                    {
                        newSongVideoBlob ? 
                            <button id="btn-createSong" type="button" className="btn btn-primary flexItem" onClick={createSongHandler}>Create Song</button>
                        : null
                    }

                    {
                        recordMenu ? 
                            <div id="captureVideoTools" className="flexHor">
                                <button type="button" className="btn btn-success" id="btn-captureVideoStart" onClick={() => {setIsRecording(true)}} disabled={isRecording?true:false}>Start</button>
                                <button type="button" className="btn btn-danger" id="btn-captureVideoStop" onClick={captureVideoStopHandler} disabled={isRecording?false:true}>Stop</button>
                            </div>
                        : null
                    }

                </div>
            </form>

        </div>
        
    )

}