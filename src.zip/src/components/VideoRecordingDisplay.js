
const useComponentWillMount = (func) => {
    const willMount = React.useRef(true)

    if (willMount.current) func()

    willMount.current = false
}

const VideoRecordingDisplay = (props) => {

    const {
        startLoader,
        endLoader,

        setNewTracks,
        newTracks,
        newVideos,
        setNewVideos,
        setAllVideos,
        allVideos,
        extractAudioFromVideo,

        createNote,
        allNotes,

        captureVideo,
        recordHandler,
        mediaStream,
        setMediaStream,
        stopMediaStream,
        getMediaStream,
    
    } = React.useContext(MainContext);

    const { isCalling, thisSessionData, thisSessionId, note, setNote, broadcast, openedPDF, setOpenedPDF } = React.useContext(SessionContext);

    const [followVideo, setFollowVideo] = React.useState(null);
    const [recordMode, setRecordMode] = React.useState('NONE');
    const [recordSettingStage, setRecordSettingStage] = React.useState(0);
    const [leadTime, setLeadTime] = React.useState(10);
    const [isRecording, setIsRecording] = React.useState(false);
    const [webcamStream, setWebcamStream] = React.useState(null);
    const [isCountDownOn, setIsCountDownOn] = React.useState(false);
    const [currentTime, setCurrentTime] = React.useState(leadTime);

    const [newRecordingName, setNewRecordingName] = React.useState(getDateString());
    const [newVideoBlob, setNewVideoBlob] = React.useState(null);
    const [newAudioBlob, setNewAudioBlob] = React.useState(null);

    // notes section functions
    const [showPdf, setShowPdf] = React.useState(false);
    const [pdfurl, setPdfurl] = React.useState(null);

    const broadCastNote = () => {

        broadcast({
            type: "SETNOTE",
            body: note,
        });

    }

    React.useEffect(() => {
        broadCastNote();
    }, [note]);

    const keepNoteHandler = () => {
        // save the note
        var title = window.prompt("Please provide title for the note");
        if (title !== null && title !== "") {
            title = title.trim();
            if (thisSessionData !== null) {
                createNote(thisSessionData.bandId, {title, body: note});
            }
        }
    }

    const openNoteHandler  = () => {
        // make the note selection note pop up
        $("#noteSelectionModal").modal('show');
    }

    const uploadPdf = (e) => {
        e.preventDefault();
        const file = document.getElementById("pdfFileUpload").files[0];
        // uploads the current pdf into the path of current loaded pdf, replaces the existing if any
        const pdfFileRef = storageRef.child(`sessions/${thisSessionId}/pdf/${file.name}`);
        pdfFileRef.put(file, { contentType: file.type }).then(snap => {
            console.log("pdf uploaded", file.name);
            
            // uploading this entry download url in db
            pdfFileRef.getDownloadURL().then(url => {
                db.collection('sessions').doc(thisSessionId).update({
                    openedPDF: url
                }).then(() => {}).catch(e => console.log(e));
            })
            
        }).catch(e => console.log(e));
        $("#uploadModal").modal('hide');

    }


    React.useEffect(() => {
        const wrapper = document.getElementById("pdfViewerWrapper");
        if (wrapper !== null) {
            wrapper.innerHTML = `
                <iframe id="pdfViewer" src = "../ViewerJS/#${openedPDF}" width='100%' height='100%' allowFullScreen webkitallowfullscreen="true"></iframe>
            `
        }

    }, [openedPDF]);


    function getDateString() {
        const date = new Date();
        const year = date.getFullYear();
        const month = `${date.getMonth() + 1}`.padStart(2, '0');
        const day =`${date.getDate()}`.padStart(2, '0');
        return `${year}-${month}-${day}-${date.getHours()}-${date.getMinutes()}-${date.getSeconds()}`
    }

    React.useEffect(() => {
        setCurrentTime(leadTime);
    }, [leadTime]);


    var interval = null;
    const startCountDown = () => {
        setIsCountDownOn(true);
        setCurrentTime(leadTime);

        interval = setInterval(function(){
            
            if (currentTime > 0) {
                setCurrentTime(prev => prev-1);
            }

       }, 1000);

    }

    React.useEffect(() => {
        if (currentTime <= 0) {
            clearInterval(interval);
            setIsCountDownOn(false);
            setIsRecording(true);
        }
    }, [currentTime]);

    const goBack = () => {
        if (recordSettingStage == 0) {
            return;
        }
        setRecordSettingStage(prev => prev-1);
    }

    const goForward = () => {
        setRecordSettingStage(prev => prev+1);
    }

    const stopRecordingHandler = () => {
        setRecordSettingStage(4);
        setIsRecording(false);
    }

    const showWebcam = async () => {
        if (mediaStream == null) {
            const stream = await getMediaStream();
            setMediaStream(stream);
        }
    }

    const getFollowVideo = () => {
        const videoName = document.getElementById("followTrackSelection").value;
        // check if video exists with this name
        const vid = allVideos.filter(v => v.name == videoName)[0];
        
        if (vid) {
            setFollowVideo(vid);
        } else {
            setFollowVideo(null);
        }
    }

    const checkNewRecordingName = (name) => {
        const names = playlist.tracks.map(t => t.name);
        const videoNames = allVideos.map(vid => vid.name);
        if (name == '') return false;
        if (names.indexOf(name) !== -1) {
            return false
        }
        if (videoNames.indexOf(name) !== -1) {
            return false
        }
        return true;
    }

    const addVideoHandler = async () => {
        //adds video along with its audio track to the song
        //get the video blob, extract audio, save the audio into newTracks and load into playlist, 
        //save video into newVideos, and load into the video views
        startLoader();
        if (checkNewRecordingName(newRecordingName)) {

            //create track id from name by removing existing spaces
            const nameSplit = newRecordingName.split(' ');
            var TrackId = '';
            for (let substr of nameSplit) {
                TrackId += substr;
            }

            const audioBlob = await extractAudioFromVideo(newVideoBlob);
            const videoUrl = URL.createObjectURL(newVideoBlob);
            setNewTracks([...newTracks, {blob: audioBlob, name: newRecordingName.trim(), id: TrackId}]);
            setNewVideos([...newVideos, {blob: newVideoBlob, name: newRecordingName.trim(), id: TrackId}]);
            setAllVideos([...allVideos, {src: videoUrl, name: newRecordingName.trim(), id: TrackId}]);

            //load audio
            playlist.load([
                {
                    "src": audioBlob,
                    "name": newRecordingName.trim(),
                }
            ]).then(() => {
                //clear newVideoBlob
                setNewVideoBlob(null);
                endLoader();
                playlist.initExporter();
            });
            
            //video is already added from the upadate in allVideos global array. Videos in editSong comp are updated as listening to
            // allVideos



        }
        else {
            endLoader();
            window.alert('Invalid Video Name!');
        }

    }

    const addAudioHandler = async () => {
        //adds video along with its audio track to the song
        //get the video blob, extract audio, save the audio into newTracks and load into playlist, 
        //save video into newVideos, and load into the video views
        startLoader();
        if (checkNewRecordingName(newRecordingName)) {

            //create track id from name by removing existing spaces
            const nameSplit = newRecordingName.split(' ');
            var TrackId = '';
            for (let substr of nameSplit) {
                TrackId += substr;
            }

            setNewTracks([...newTracks, {blob: newAudioBlob, name: newRecordingName.trim(), id: TrackId}]);

            //load audio
            playlist.load([
                {
                    "src": newAudioBlob,
                    "name": newRecordingName.trim(),
                }
            ]).then(() => {
                //clear newAudioBlob
                setNewAudioBlob(null);
                endLoader();
                playlist.initExporter();
            });
            
            //video is already added from the upadate in allVideos global array. Videos in editSong comp are updated as listening to
            // allVideos



        }
        else {
            endLoader();
            window.alert('Invalid Audio Name!');
        }

    }
    const addNewRecordingHandler = async () => {
        setFollowVideo(null);
        setLeadTime(10);
        
        if (newVideoBlob) {
            addVideoHandler();
        }
        if (newAudioBlob) {
            addAudioHandler();
        }
        
        // go back to stage view
        props.close();

    }

    const startPlayback = () => {
        // handling playback while recording
        const lead = leadTime;
        const startPlaybackForRecording = () => {

            if (followVideo !== null) {

                // get the videojs id from follow video id
                const id = `videojs-${followVideo.id}`;
                const vid = videojs(id);
                // get the startTime of audio of this video
                const audio = playlist.tracks.filter(t => t.name == followVideo.name)[0];
                setTimeout(() => {
                    vid.play();
                }, audio.startTime*1000);

            }

            playlist.play();
        }
        setTimeout(startPlaybackForRecording, lead*1000);
    }

    const stopPlayback = () => {
        // handling playback while recording
        if (followVideo !== null) {

            // get the videojs id from follow video id
            const id = `videojs-${followVideo.id}`;
            try {
                const vid = videojs(id);
                vid.stop();
            } catch (error) {
                //
            }

        }

        playlist.stop();
        
    }

    React.useEffect(() => {

        if (mediaStream !== null) {
            const container = document.getElementById('webcam');
            if (container) {
                container.srcObject = mediaStream;
            }
        }

    }, [mediaStream]);

    React.useEffect(() => {

        if (recordSettingStage == 3 && recordMode == 'AUDIOVIDEO') {

            setNewAudioBlob(null);
            setNewVideoBlob(null);
            // if (mediaStream && !isCalling) stopMediaStream(mediaStream);
            document.getElementById('webcam').srcObject = mediaStream;
            
            captureVideo(setNewVideoBlob, '#webcam', "#startRecordingBtn", "#stopRecordingBtn", 'videojs-newCapturedVideo', leadTime);

        }

        if (recordSettingStage == 3 && recordMode == 'AUDIOONLY') {

            setNewAudioBlob(null);
            setNewVideoBlob(null);
            
            recordHandler(ee, "#startRecordingBtn", '#stopRecordingBtn', setNewAudioBlob, leadTime);

        }

        if (recordSettingStage == 2) {
            const webcamContainer = document.getElementById("webcam");
            if (webcamContainer) {
                if (mediaStream !== null) {
                    webcamContainer.srcObject = mediaStream;
                }
            }
            showWebcam();
        }

    }, [recordSettingStage]);

    React.useEffect(() => {

        if (newAudioBlob !== null || newVideoBlob !== null) {
            setRecordSettingStage(4);
        }

    }, [newVideoBlob, newAudioBlob]);

    React.useEffect(() => {
        // before unmounting the component
        return function cleanup() {
            // if (mediaStream !== null && !isCalling) {
            //     stopMediaStream(mediaStream);
            // }

            //disposing the video js player is exists
            const videos = document.getElementsByClassName('video-js');
            for (let vid of videos) {
                const id = vid.id;
                const thisVideo = videojs(id);
                thisVideo.dispose();
            }

        }
    }, []);

    return (
        <div id="newRecordingProcessContainer">
            <a href="javascript:void(0)" id="closeNewRecording" onClick={() => {props.close()}}>&times;</a>

            {/* not selection popup modal */}
            <div className="modal fade" id="noteSelectionModal" tabIndex="-1" role="dialog"
                aria-labelledby="noteSelectionModal" aria-hidden="true">
                <div className="modal-dialog modal-dialog-centered" role="document">
                    <div className="modal-content">
                        <div className="modal-header">
                            <h5 className="modal-title" id="noteSelectionModalTitle">Select the note to open</h5>
                            
                        </div>
                        <div className="modal-body">
                            
                            <div className="form-group">
                                <label>Select the note</label>
                                <select className="form-control" id="noteSelection">

                                    {
                                        allNotes.map(n => {
                                            return (
                                                <option value={n.body} key={n.id}>{n.title}</option>
                                            )
                                        })
                                    }
                                </select>
                            </div>

                        </div>
                        <div className="modal-footer">
                            <button onClick={() => {
                                setShowPdf(false);
                                setNote(document.getElementById("noteSelection").value);
                                $("#noteSelectionModal").modal('hide');
                            }} type="button" className="btn btn-primary">Open</button>
                        </div>
                    </div>
                </div>
            </div>

            {/* upload pdf popup modal */}
            <div className="modal fade" id="uploadModal" tabIndex="-1" role="dialog"
                aria-labelledby="uploadModal" aria-hidden="true">
                <div className="modal-dialog modal-dialog-centered" role="document">
                    <div className="modal-content">
                        <div className="modal-header">
                            <h5 className="modal-title" id="uploadModalTitle">Upload a pdf file to open</h5>
                            
                        </div>
                        <div className="modal-body">
                        <form onSubmit={(e) => uploadPdf(e)}>
                            <div className="form-group">
                                <label>Upload pdf file</label>
                                <input type="file" className="form-control-file" id="pdfFileUpload"></input>
                                <button type="submit" class="btn btn-primary mb-2">Upload</button>
                            </div>
                        </form>  

                        </div>
                        
                    </div>
                </div>
            </div>

            {/* recording (New) Panel 1 */}
            {
                recordSettingStage == 0?
                    <div id="newRecordingPanelOneContainer">
                        <div id="newRecordingPanelOneTop">
                            <input type="image" src="../assets/backBtn.png" onClick={() => {props.close()}} />
                        </div>
                        <div id="newRecordingPanelOneMiddle">Select how to Record</div>
                        <div id="newRecordingPanelOneBottom">
                            <div className="newRecordingChoiceBtns">
                                <button id="newRecordingChoiceBoth"
                                    onClick={() => {setRecordMode('AUDIOVIDEO'); goForward()}}>Record<br/>Audio & Video</button>
                            </div>
                            <div className="newRecordingChoiceBtns">
                                <button id="newRecordingChoiceAudio"
                                    onClick={() => {setRecordMode('AUDIOONLY'); goForward()}}>Record<br/>Audio Only</button>
                            </div>
                            <div className="newRecordingChoiceBtns">
                                <button disabled id="newRecordingChoiceVideo"
                                    onClick={() => {setRecordMode('VIDEOONLY'); goForward()}}>Record<br/>Video Only</button>
                            </div>
                        </div>
                    </div>
                : null
            }

            {/* recording (New) Panel 2 */}
            
            {
                recordSettingStage == 1 ? 
                    <div id="newRecordingPanelTwoContainer">
                        <div id="newRecordingPanelTwoTop">
                            <input type="image" src="../assets/backBtn.png" onClick={goBack} />
                        </div>
                        <div id="newRecordingPanelTwoMiddle">Select Other Recording Features</div>
                        <div className="tempTrackButtons">
                            <button onClick={() => {}}>0</button>
                            <button onClick={() => {}}>1</button>
                        </div>
                        <div id="newRecordingPanelTwoBottom">
                            <div className="newRecordingPanelTwoOuterContainer">
                                <div id="newRecordingPanelTwoInnerContainerLeft">
                                    <h5>Recording will<br/>start</h5>
                                    <p>After start button is activated</p>
                                    <div id="newRecordingLeadTime">
                                        <input type="number" id="newRecordingLeadTimeNum"
                                            min="1" value={leadTime} onChange={(e) => setLeadTime(e.target.value)}></input>
                                    </div>
                                    <h5>Seconds</h5>
                                    <p style={{marginTop: '10px'}}>Change Start Lead Time?</p>
                                    
                                </div>
                            </div>
                            <div className="newRecordingPanelTwoOuterContainer" id="newRecordingPanelTwoWithoutTracks">
                                <div id="newRecordingPanelTwoInnerContainerMiddle">
                                    <div className="form-group">
                                        <label style={{color: 'black'}} >Select follow track</label>
                                        <select className="form-control" id="followTrackSelection">
                                            <option selected={true} value="CREATEFOLLOWTRACK">Create follow track</option>
                                            {
                                                allVideos.map(v => {
                                                    return (
                                                        <option value={v.name} key={v.name}>{v.name}</option>
                                                    )
                                                })
                                            }
                                        </select>
                                    </div>
                                    
                                </div>
                            </div>
                            {/* <div className="newRecordingPanelTwoOuterContainer" id="newRecordingPanelTwoWithTracks">
                                <div id="newRecordingPanelTwoInnerContainerMiddle">
                                    <h5>Your<br/>Follow Track<br/>is ready.</h5>
                                    <button className="newRecordingIncludeOtherTracks">Click to include<br/> other
                                        track(s)</button>
                                    <button className="newRecordingFollowAllTracks">Follow All Tracks</button>
                                    <h6 className="newRecordingNameOfTrack">[Name of track to follow]</h6>
                                </div>
                            </div> */}


                            <div className="newRecordingPanelTwoOuterContainer">
                                <div id="newRecordingPanelTwoInnerContainerRight">
                                    <h5>Metronome</h5>
                                    <p>Leave blank to exclude from recording</p>
                                    <div id="newRecordingBPMLabel">BPM</div>
                                    <input type="text"></input>
                                    <h4>Time Signature</h4>
                                    <div id="newRecordingTimeSignatureContainer">
                                        <input type="text" className="newRecordingTimeSignatureNum"></input>
                                        <div id="newRecordingSlash">/</div>
                                        <input type="text" className="newRecordingTimeSignatureNum"></input>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div id="newRecordingPanelTwoContinueContainer">
                            <button id="newRecordingPanelTwoSelectionsCompleteBtn1"
                                onClick={() => {
                                    getFollowVideo();
                                    goForward();
                                    if (recordMode == 'AUDIOONLY') {
                                        goForward();
                                    }
                                }}></button>
                        </div>
                    </div>
                : null
            }

            

            {/* recording (New) Panel 3 */}
            {
                recordSettingStage == 2 && (recordMode == 'AUDIOVIDEO' || recordMode == 'VIDEOONLY') ?
                    <div id="newRecordingPanelThreeContainer">
                        <div id="newRecordingPanelThreeTop">
                            <input type="image" src="../assets/backBtn.png" onClick={goBack} />
                        </div>
                        <div id="newRecordingPanelThreeMiddle">Camera Set-up</div>
                        <div id="newRecordingPanelThreeBottom">
                            <div id="newRecordingPanelThreeBottomLeft">
                                <div id="newRecordingPanelThreeBottomLeft1">
                                    <p>Line up frame view</p>
                                    <p>inside green screen</p>
                                    <p>Make sure lighting</p>
                                    <p>is adequate, not too</p>
                                    <p>bright or dark</p>
                                </div>
                            </div>
                            <div id="newRecordingPanelThreeBottomMiddleContainer">
                                <div id="threeBottomMiddleOuter">
                                    <div id="threeBottomMiddleInner">
                                        {/* Webcam display goes here */}
                                        <video className="streamVideo" muted autoPlay id="webcam"></video>
                                    </div>
                                </div>
                            </div>
                            <div id="newRecordingPanelThreeBottomLeft">
                                <div id="newRecordingPanelThreeBottomLeft2">
                                    <p>Find where you</p>
                                    <p>want to stand and</p>
                                    <p>use masking tape</p>
                                    <p>on floor as a guide</p>
                                    <p>Once satisfied, click</p>
                                    <p><span id="brightGreenText">Camera Ready <img
                                                src="../assets/smallGreenArrow.png" /></span></p>
                                    <p>for next screen</p>
                                </div>
                            </div>
                        </div>
                        <div id="newRecordingPanelThreeContinueContainer">
                            <button id="newRecordingPanelThreeSelectionsCompleteBtn2"
                                onClick={goForward}></button>
                        </div>
                    </div>
                : null
            }
            
            {/* recording (New) Panel 4 */}
            
            {
                recordSettingStage == 3 ?
                    <div id="newRecordingPanelFourContainer2">
                        <div className="newRecordingPanelFourSide">
                            <div className="newRecordingContentCaptureWrapper2">
                                <div className="newRecordingContentCaptureInner">
                                    {/* follow track goes here */}
                                    {
                                        followVideo !== null ? 
                                            <VideoPlayer key={`playerKey-${followVideo.id}`} id={`videojs-${followVideo.id}`} src={followVideo.src} />
                                        : null
                                    }
                                </div>
                            </div>
                            <div id="newRecordingPanelFourBLeft">
                                <h5>1</h5>
                                <h5 className="newFourActive">2</h5>
                                <h5>3</h5>
                                <h5>4</h5>
                            </div>
                        </div>

                        <div style={{width: '40%'}} className="newMainContentNotes">
                            <div id="manyGLnotes">
                                {
                                    showPdf == true ?
                                    <div style={{width: '100%', height: '100%'}} id="pdfViewerWrapper">
                                        <iframe id="pdfViewer" src = {`../ViewerJS/#${openedPDF}`} width='100%' height='100%' allowFullScreen webkitallowfullscreen="true"></iframe>
                                    </div> 
                                    : <textarea value={note} onChange={(e) => {setNote(e.target.value)}} id="newContentTextarea" placeholder="..."></textarea>
                                }
                            </div>
                            <div className="twoGLBtns">
                                <button onClick={keepNoteHandler} className="textareaNotesBtns">Keep</button>
                                <button onClick={openNoteHandler} className="textareaNotesBtns">Open</button>
                                <button onClick={() => {$("#uploadModal").modal('show'); setShowPdf(true);}} className="textareaNotesBtns">Upload</button>
                            </div>
                        </div>

                        <div className="newRecordingPanelFourSide">
                            <div className="newRecordingContentCaptureWrapper2">
                                <div className="newRecordingContentCaptureInner">
                                    {/* webcam goes here */}
                                    <video className="streamVideo" muted autoPlay id="webcam"></video>
                                </div>
                            </div>
                            

                            {/* activate follwing while recording in progress to stop the recording */}

                            
                            <div style={!isRecording ? {display: 'flex', width: '100%'} : {display: 'none'} } className="newRecordingPanelFourBRight" id="startRecordingBtn" onClick={() => {startCountDown(); startPlayback()}}>
                                <h4>Click to Start Recording</h4>
                                <p>in <span id="newRecordingActualLeadTime2">{currentTime}</span> Seconds</p>
                            </div>

                            <div style={ isRecording && !isCountDownOn? {display: 'flex', width: '100%'} : {display: 'none'} } className="borderBlink newRecordingPanelSixBRight" id="stopRecordingBtn" onClick={() => {stopRecordingHandler(); stopPlayback()}}>
                                <h4>Stop Recording</h4>
                            </div>
                            

                        </div>
                    </div>
                : null
            }

            
            {
                recordSettingStage == 4 ? 
                    <React.Fragment>
                        <div style={{display: 'flex'}} id="newRecordingPanel7Container">
                            <div className="saveOrNotContainer">
                                <button className="newRecordingPanel7Btns" onClick={() => {props.close()}}>Close without
                                    Saving</button>
                                <div id="newRecordingPanel7InputContainer">
                                    <input type="text" className="newRecordingPanel7Input" value={newRecordingName} onChange={(e) => setNewRecordingName(e.target.value)} />
                                    <h6>Name of New Recording</h6>
                                </div>
                                <button onClick={addNewRecordingHandler} className="newRecordingPanel7Btns">Add to Tracks</button>
                            </div>
                        </div>
                        {/* <div id="newRecordingPanel8Container">
                            <div className="saveOrNotContainer">
                                <button className="newRecordingPanel7Btns" onClick={closeNewRecording}>Click Again to
                                    Confirm<br/>Close without Saving<br/><span className="blinkingText">This track will not be
                                        retrievable</span></button>
                                <button id="newRecordingPanel8Cancel" onClick={newRecordingPanel7}>Cancel this
                                    action</button>
                            </div>
                        </div> */}
                    </React.Fragment>
                : null
            }

        </div>
    )

}