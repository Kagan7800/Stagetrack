
const useComponentWillMount = (func) => {
    const willMount = React.useRef(true)

    if (willMount.current) func()

    willMount.current = false
}

const Stage = (props) => {

    const { allVideos } = React.useContext(MainContext);

    // useComponentWillMount(() => {
    //     // doing stuff before mounting
    //     //disposing the video js player is exists
    //     const videos = document.getElementsByClassName('video-js');
    //     for (let vid of videos) {
    //         console.log("disposing video")
    //         const id = vid.id;
    //         const thisVideo = videojs(id);
    //         thisVideo.dispose();
    //     }
    // });

    // BEFORE UNMOUNTING THIS COMP
    React.useEffect(() => {
        // before unmounting the component
        return function cleanup() {

            //disposing the video js player is exists
            const videos = document.getElementsByClassName('video-js');
            for (let vid of videos) {
                const id = vid.id;
                const thisVideo = videojs(id);
                thisVideo.dispose();
            }
        }
    }, []);

    React.useEffect(() => {
        // making containers draggable
        for (let [i, vid] of allVideos.entries()) {

            $( `#character030${i+1}` ).draggable({containment: "#stageContainer"}).resizable({
                containment: "#stageContainer",
                aspectRatio: true,
                classes: {                    
                    "ui-resizable-se": "ui-icon ui-icon-grip-diagonal-se"
                }
                });

        }

    }, [allVideos]);


    return (
        <div id="stageContainer">
            <div id="overlay"></div>
            {
                allVideos.map((video, i) => {
                    return (
                        <div key={video.id} id={`character030${i+1}`} className="item one stageVideoContainer">
                            <VideoPlayer key={`playerKey-${video.id}`} id={`videojs-${video.id}`} src={video.src} width={224} height={168} />
                        </div>
                    )
                })
            }
        </div>
    )
}