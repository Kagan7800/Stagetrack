
const TopStreamsDisplay = () => {

    const { mediaStream, remoteStreams, isCalling } = React.useContext(MainContext);

    React.useEffect(() => {

        // resetting all the containers to empty
        const containers = document.getElementsByClassName('topBox');
        // for (let i=0; i<containers.length; i++) {
        //     if (i > 1) {
        //         containers[i].innerHTML = ''
        //     }
        // }

        for (let i=0; i<containers.length; i++) {
            if (containers[i].id !== 'guestChatBox1') {
                containers[i].remove();
            }
        }

        // only add the remoteStreams if total remoteStreams is less than 3

        if (remoteStreams.length < 5) {
            for (let [i, stream] of remoteStreams.entries()) {
                //get container
                // const containers = document.getElementsByClassName('topBox');
                // const container = containers[i+1];
                const remotePeerId = stream.peerId;
                // container.innerHTML = '';
                // container.innerHTML = `
                //     <div class="remoteStream remoteStreamNoSelf" id="remoteStreamContainer-${remotePeerId}">
                //         <video class="streamVideo" autoPlay id="remoteStream-${remotePeerId}"></video>
                //     </div>
                // `
                // const video = document.getElementById(`remoteStream-${remotePeerId}`);
                // video.srcObject = stream.stream;

                const ele = document.createElement('div');
                ele.className = "guestChatBoxes topBox";
                ele.style.width = 'auto';
                ele.style.padding = '35px';
                ele.id = `guestChatBox${i+2}`;
                ele.innerHTML = `
                            <div class="remoteStream remoteStreamNoSelf" id="remoteStreamContainer-${remotePeerId}">
                                <video class="streamVideo" autoPlay id="remoteStream-${remotePeerId}"></video>
                            </div>
                `
                document.getElementById('twoGuestsUpper').appendChild(ele);
                const video = document.getElementById(`remoteStream-${remotePeerId}`);
                video.srcObject = stream.stream;
            }
        }
       

    }, [remoteStreams]);

    React.useEffect(() => {
        if (isCalling) {
            const container = document.getElementById('guestChatBox1');
            container.innerHTML = `
                <div class="remoteStream" id="selfStreamContainer">
                    <video class="streamVideo" muted autoplay id="selfStream"></video>
                </div>
            `
            //put our stream in the selfStream box
            const selfStream = document.getElementById('selfStream');
            selfStream.srcObject = mediaStream;

        } else {
            // resetting all the containers to empty
            const containers = document.getElementsByClassName('topBox');
            // for (let i=0; i<containers.length; i++) {
            //     if (i > 0) {
            //         containers[i].innerHTML = ''
            //     }
            // }

            for (let i=0; i<containers.length; i++) {
                if (containers[i].id !== 'guestChatBox1') {
                    containers[i].remove();
                }
            }
        }
    }, [isCalling]);

    return (
        // <div className="container">
        //     <div className="flexHor">
        //         <div className="topBox flexItem" id="topBox01">
                    
        //         </div>
        //         <div className="topBox flexItem"></div>
        //         <div className="topBox flexItem"></div>
        //     </div>
        //     <div className="flexHor">
        //         <div className="flexItem">
        //             {/* Whiteboard goes here */}
        //             <Whiteboard />
        //         </div>
        //     </div>
        // </div>

        <div id="twoGuests">
            <div style={{height: '60%'}} id="twoGuestsUpper">
                <div style={{width: 'auto', padding: '35px'}} className="guestChatBoxes topBox" id="guestChatBox1"></div>
                
            </div>
            <div id="twoGuestsLower">
                <form action="#">
                    <textarea id="textareaNotes" placeholder="Type your notes here..."></textarea>
                    <button className="textareaNotesBtns">Keep</button>
                    <button className="textareaNotesBtns">Open</button>
                    <button className="textareaNotesBtns">Upload</button>
                </form>
            </div>
        </div>

    )

}