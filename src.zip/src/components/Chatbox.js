
const Chatbox = () => {

    const {
        authState,
        thisUserProfile
    } = React.useContext(MainContext);

    const {
        broadcast
    } = React.useContext(SessionContext);

    const [message, setMessage] = React.useState('');

    const sendMessageHandler = (e) => {
        e.preventDefault();
        if (message !== '') {

            broadcast({
                type: "CHAT",
                data: {
                    sentByProfile: thisUserProfile,
                    message: message
                }
            });

            // const container = document.getElementById('chatsection');
            // const ele = document.createElement('div');
            // ele.className = "float-right";
            // ele.innerHTML = `<b>Me</b>: ${message}`
            // container.appendChild(ele);

            const container = document.getElementById('chatMessagesContainer');
            const sender = document.createElement('div');
            sender.className = 'chatMessagesSentFrom';
            sender.innerText = 'Me';
            
            const chat = document.createElement('div');
            chat.className = 'chatMessagesSent';
            chat.innerText = message;

            container.appendChild(sender);
            container.appendChild(chat);

            setMessage('');

        }
    }

    return (

        <React.Fragment>
            <div id="chatMessagesContainer">
                
            </div>
            <div id="chatMessagesSubmitContainer">
                <form onSubmit={(e) => sendMessageHandler(e)}>
                    <input style={{height: '50px'}} onChange={(e) => setMessage(e.target.value)} value={message} type="text" className="chatMessageInputText" />
                    <input type="submit" className="chatMessageInputSend" value="Send" />
                </form>
            </div>
        </React.Fragment>

    )

}