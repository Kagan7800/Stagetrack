
const EditSong2 = () => {

    const {
        allSongs,
        activeBand,
        allBands,
        allNotes,
        ybMode,
        setYbMode,
        allResources,
        openedResource,
        setOpenedResource,
        createNote,
        thisUserProfile,
        bandData,
        setBandData,
        setDisplay,
        startLoader,
        endLoader,
        fetchSong,
        createBand,
        signOut,
        authState,
        updateAppState,
        updateSongState,
        songState, 
        loadSong, 
        clearSong,
        initPlaylist, 
        checkNewSongName,
        saveSong,
        saveNewSong,
        saveNewResource,
        deleteSong,
        deleteResource,
        allVideos,
        newTracks,
        setNewTracks,
        newVideos,
        setNewVideos,
        setAllVideos,
        allowEditSwitch,
        captureVideo,
        extractAudioFromVideo,
        recordHandler,
        editorPlayhead,
        setEditorPlayhead,
        currentPlaybackTime,
        setCurrentPlaybackTime,
        setCurrentSongData,
        seekPlayback,

        
        isCalling,
        mediaStream,
        stopMediaStream,
        remoteStreams,
        

    } = React.useContext(MainContext);

    const {
        thisPeer,
        thisSessionId,
        thisSessionData,
        thisSessionBand,
        createSession,
        joinSession,
        broadcast,
        pauseMediaStream,
        leaveSession,
        shareClickWithPeers,
        note,
        setNote,
        allowClickShare,
        setAllowClickShare,
    } = React.useContext(SessionContext);

    const [, updateState] = React.useState();
    const forceUpdate = React.useCallback(() => updateState({}), []);

    const [allowEditChecked, setAllowEditChecked] = React.useState(songState.song !== null? songState.song.allowEdit: true);

    const [showWebcam, setShowWebcam] = React.useState(false);
    const [recordingType, setRecordingType] = React.useState('AUDIO');
    const [videoTimeouts, setVideoTimeouts] = React.useState([]);

    const [isRecording, setIsRecording] = React.useState(false);
    const [isReadyToRecord, setIsReadyToRecord] = React.useState(false);
    
    const [newRecordingName, setNewRecordingName] = React.useState(getDateString());
    
    const [openSongName, setOpenSongName] = React.useState('');
    const [joinSessionPasscode, setJoinSessionPasscode] = React.useState('');

    const [isPlayingForAll, setIsPlayingForAll] = React.useState(false);

    const [pauseState, setPauseState] = React.useState(null);

    const [followVideo, setFollowVideo] = React.useState(null);
    const [leadTime, setLeadTime] = React.useState(5);

    const [isAudioOnlyRecordingChecked, setIsAudioOnlyRecordingChecked] = React.useState(false);
    const [isAudioVideoRecordingChecked, setIsAudioVideoRecordingChecked] = React.useState(false);
    const [showVideoRecordingDisplay, setShowVideoRecordingDisplay] = React.useState(false);

    //states for user streams different layouts
    const [showStage, setShowStage] = React.useState(true);
    const [showPdf, setShowPdf] = React.useState(false);
    const [showStreams, setShowStreams] = React.useState(false);
    const [showStreamBoxes, setShowStreamBoxes] = React.useState(true);
    const [showTopStreamsDisplay, setShowTopStreamsDisplay] = React.useState(false);

    const [selectedBandId, setSelectedBandId] = React.useState(null);
    const [selectedBandMembers, setSelectedBandMembers] = React.useState([]);
    const [memberToAddUsername, setMemberToAddUsername] = React.useState('');
    const [selectedMemberId, setSelectedMemberId] = React.useState(null);

    const [noteIdToDelete, setNoteIdToDelete] = React.useState(null);
    const [resourceIdToDelete, setResourceIdToDelete] = React.useState(null);
    const [songIdToDelete, setSongIdToDelete] = React.useState(null);

    function getFollowVideo() {
        if (songState.song == null) return;
        const followVideo = allVideos.filter(vid => vid.name == songState.song.name)[0];
        return followVideo;
    }
    function getDateString() {
        const date = new Date();
        const year = date.getFullYear();
        const month = `${date.getMonth() + 1}`.padStart(2, '0');
        const day =`${date.getDate()}`.padStart(2, '0');
        return `${year}-${month}-${day}-${date.getHours()}-${date.getMinutes()}-${date.getSeconds()}`
    }

    //UI HANDLERS

    function openNav() {
        document.getElementById("mySidepanel").style.width = "250px";
        document.getElementById("openbtn").style.display = "none";
    }
    
    function closeNav() {
        document.getElementById("mySidepanel").style.width = "0";
        document.getElementById("openbtn").style.display = "block";
    }
    
    /* new code 10/14/2020 */
    function openChat() {
        document.getElementById("mySidepane2").style.width = "400px";
        document.getElementById("openchatbtn").style.display = "none";
    }
    
    function closeChat() {
        document.getElementById("mySidepane2").style.width = "0";
        document.getElementById("openchatbtn").style.display = "block";
    }
    /* end */
    
    /* Main page Record */
    var mainPanelInitialized = false;
    var totalMinimizedPanels = 0;
    var differenceInPositioningRecord;
    var differenceInPositioningMixer;
    var differenceInPositioningTracks;
    // modified code 9/12/2020
    function showRecord(y) {
        var a;
        if (mainPanelInitialized == false) {
            //
            a = 58;
        } else {
            a = 58 + y;
        }
        mainPanelInitialized = true;
        var b = a.toString() + 'px';
        document.getElementById("controlPanelTop").style.bottom = b;
        document.getElementById("closeRecord").style.display = "block";
        var x = document.getElementById("controlPanelTop");
        fadeIn(x);
    }
    
    function closeRecord() {
        document.getElementById("controlPanelTop").style.top = "-2700px";
        document.getElementById("controlPanelTop").style.opacity = 0;
        document.getElementById("closeRecord").style.display = "none";
        if (totalMinimizedPanels == 0) {
            mainPanelInitialized = false;
        }
    }
    //end of new & modified code 9/12/2020
    /* Fade in */
    function fadeIn(x) {
        x.style.transition = "opacity 1s linear 0s";
        x.style.opacity = 1;
    }
    
    /* Change color on main control panel */
    function changeColor(y) {
        var x = document.getElementsByClassName("switch");
    
        for (i = 0; i < x.length; i++) {
            x[i].style.color = y;
            x[i].style.borderColor = y;
        }
    }
    
    /* Start BPM */
    function startBpm() {
        document.getElementById("panelTopStartWrapper").style.display = "none";
        document.getElementById("panelTopStartWrapperAlt").style.display = "flex";
    }
    
    /* Stop BPM */
    function stopBpm() {
        document.getElementById("panelTopStartWrapper").style.display = "flex";
        document.getElementById("panelTopStartWrapperAlt").style.display = "none";
    }
    /* Start Recording change colors & text */
    var startRecordingBoolean = false;
    
    function startRecording() {
        if (startRecordingBoolean == true) {
            startRecordingBoolean = false;
            document.getElementById("startRecordingWrapper").style.borderColor = "#FBFF49";
            document.getElementById("startRecordingBtn").innerHTML = "Start<br>Recording";
            document.getElementById("startRecordingBtn").style.backgroundColor = "#88f21e";
            document.getElementById("startRecordingBtn").style.color = "black";
            document.getElementById("saveRecording").style.display = "flex";
            /* Display current date & time */
            /*        var currentTime = new Date().toLocaleTimeString([], {hour: '2-digit', minute: '2-digit'});
             */
            var currentTime = new Date().toLocaleTimeString('en-US', {
                hour: 'numeric',
                minute: 'numeric',
                hour12: true
            });
            var currentDate = new Date().toLocaleDateString();
            var dateAndTime = currentDate + ', ' + currentTime;
            document.getElementById("currentTime").innerHTML = dateAndTime;
        } else {
            startRecordingBoolean = true;
            document.getElementById("startRecordingWrapper").style.borderColor = "#F31212";
            document.getElementById("startRecordingBtn").innerHTML = "Stop<br>Recording";
            document.getElementById("startRecordingBtn").style.backgroundColor = "#F31212";
            document.getElementById("startRecordingBtn").style.color = "#FBFF49";
            /*      var x = setInterval(leadTimeCounter, 1000);    
                    function leadTimeCounter() {
                      var y = document.getElementById("leadTimeNum").value;
                      if(y >=1) {  
                        var a = --y;
                        document.getElementById("leadTimeNum").value = a;
                      } else {
                        clearInterval(x);
                      } 
                    }
                  */
        }
    }
    
    
    
    /* Tracks */
    // modified 9/12/2020
    function showTracks(y) {

        var a;
        if (mainPanelInitialized == false) {
            a = 58;
        } else {
            a = 58 + y;
        }
        mainPanelInitialized = true;
        var b = a.toString() + 'px';
    
    
        document.getElementById("tracksContainer").style.bottom = b;
        document.getElementById("tracksContainer").style.display = "flex";
        document.getElementById("closeTracks").style.display = "block";
    
    }
    
    function closeTracks() {
        document.getElementById("tracksContainer").style.display = "none";
        document.getElementById("closeTracks").style.display = "none";
        if (totalMinimizedPanels == 0) {
            mainPanelInitialized = false;
        }
    }
    // end of modified 9/12/2020
    
    /* Close Recording without saving it */
    function closeRecordNoSave() {
        document.getElementById("saveRecording").style.display = "none";
    }
    
    
    //modified code 10/07/2020
    function tempChangeScene(x) {
        switch (x) {
            case 1:
                document.getElementById("stageContainer").style.display = "flex";
                document.getElementById("twoGuests").style.display = "none";
                document.getElementById("manyGuests").style.display = "none";
                document.getElementById("userProfileContainer").style.display = "none";
                document.getElementById("closeUserProfile").style.display = "none";
                break;
            case 2:
                tempChatBox(3);
                document.getElementById("stageContainer").style.display = "none";
                document.getElementById("twoGuests").style.display = "flex";
                document.getElementById("manyGuests").style.display = "none";
                document.getElementById("userProfileContainer").style.display = "none";
                document.getElementById("closeUserProfile").style.display = "none";
                break;
            case 3:
                tempChatBox(4);
                document.getElementById("stageContainer").style.display = "none";
                document.getElementById("twoGuests").style.display = "none";
                document.getElementById("manyGuests").style.display = "flex";
                document.getElementById("userProfileContainer").style.display = "none";
                document.getElementById("closeUserProfile").style.display = "none";
                break;
        }
    
    
    }
    
    function displayMetronome() {
        document.getElementById("metronomePanel").style.display = "flex";  
    }
    
    
    function showMixer(y) {
        var a;
        if (mainPanelInitialized == false) {
            a = 58;
        } else {
            a = 58 + y;
        }
        mainPanelInitialized = true;
        var b = a.toString() + 'px';
        document.getElementById("mixerPanel").style.bottom = b;
        document.getElementById("mixerPanel").style.display = "flex";
    
    }
    
    function closeMixer() {
        //  document.getElementById("mixerPanel").style.bottom = "-5600px";
        document.getElementById("mixerPanel").style.display = "none";
        if (totalMinimizedPanels == 0) {
            mainPanelInitialized = false;
        }
    }
    
    // end of modified code 9/12/2020
    
    // Minimize or maximize
    
    function minimizeRecord() {
        document.getElementById("minimizedPanels").style.display = "flex";
        document.getElementById("minimizedRecord").style.display = "flex";
        totalMinimizedPanels++;
        closeRecord();
    }
    
    function maximizeRecord() {
    
        document.getElementById("minimizedRecord").style.display = "none";
        totalMinimizedPanels--;
        if (totalMinimizedPanels == 0) {
            document.getElementById("minimizedPanels").style.display = "none";
            differenceInPositioningRecord = 0;
            showRecord(differenceInPositioningRecord);
        } else {
            differenceInPositioningRecord = -30;
            showRecord(differenceInPositioningRecord);
        }
    }
    
    function minimizeMixer() {
        document.getElementById("minimizedPanels").style.display = "flex";
        document.getElementById("minimizedMixer").style.display = "flex";
        totalMinimizedPanels++;
        closeMixer();
    }
    
    function maximizeMixer() {
    
        document.getElementById("minimizedMixer").style.display = "none";
        totalMinimizedPanels--;
        if (totalMinimizedPanels == 0) {
            document.getElementById("minimizedPanels").style.display = "none";
            differenceInPositioningMixer = 0;
            showMixer(differenceInPositioningMixer);
        } else {
            differenceInPositioningMixer = 30;
            showMixer(differenceInPositioningMixer);
        }
    }
    
    function minimizeTracks() {
        document.getElementById("minimizedPanels").style.display = "flex";
        document.getElementById("minimizedTracks").style.display = "flex";
        totalMinimizedPanels++;
        closeTracks();
    }
    
    function maximizeTracks() {
    
        document.getElementById("minimizedTracks").style.display = "none";
        totalMinimizedPanels--;
        if (totalMinimizedPanels == 0) {
            document.getElementById("minimizedPanels").style.display = "none";
            differenceInPositioningTracks = 0;
            showTracks(differenceInPositioningTracks);
        } else {
            differenceInPositioningTracks = 30;
            showTracks(differenceInPositioningTracks);
        }
    }
    
    function sliderController() {
        var masterSlider = document.getElementById("newRightSideVolumeSlider");
        masterSlider.addEventListener("input", function () {
    
            document.body.style.setProperty("--sliderImage", "url('newRightSideMasterVolumeNum" + this.value + ".png')");
    
        });
    }
    
    function displayFeatures() {
        document.getElementById("featuresPanel").style.display = "flex";
    }
    
    function displayMixer() {
        document.getElementById("mixerPanel").style.display = "flex";
        document.getElementById("closeMixer").style.display = "flex";
    }
    
    function displayRecording() {
        document.getElementById("recordingPanel").style.display = "flex";
    }
    
    function displayTracks() {
        document.getElementById("tracksContainer").style.display = "flex";
        document.getElementById("closeTracks").style.display = "block";
    }
    
    function displayRecordingInProcess() {
        document.getElementById("recordingPanel").style.display = "none";
        document.getElementById("recordingInProcessPanel").style.display = "flex";
        // countdown
        var y = document.getElementById("leadTimeNum").value;
        document.getElementById("leadTimeNumCountdown").innerHTML = y;
        var x = setInterval(leadTimeCounter, 1000);
    
        function leadTimeCounter() {
            if (y >= 1) {
                a = --y;
                document.getElementById("leadTimeNumCountdown").innerHTML = a;
            } else {
                clearInterval(x);
            }
        }
    }
    
    function displaySaveRecording() {
        document.getElementById("recordingInProcessPanel").style.display = "none";
        document.getElementById("saveRecording").style.display = "flex";
    }
    
    // new code 9/18/2020
    function tempChatBox(x) {
        switch (x) {
            case 1:
                document.getElementById("guestChatBox1").style.display = "flex";
                document.getElementById("guestChatBox2").style.display = "none";
                document.getElementById("guestChatBox3").style.display = "none";
                document.getElementById("guestChatBox4").style.display = "none";
                document.getElementById("guestChatBox5").style.display = "none";
                break;
            case 2:
                document.getElementById("guestChatBox1").style.display = "flex";
                document.getElementById("guestChatBox2").style.display = "flex";
                document.getElementById("guestChatBox3").style.display = "none";
                document.getElementById("guestChatBox4").style.display = "none";
                document.getElementById("guestChatBox5").style.display = "none";
                break;
            case 3:
                document.getElementById("guestChatBox1").style.display = "flex";
                document.getElementById("guestChatBox2").style.display = "flex";
                document.getElementById("guestChatBox3").style.display = "flex";
                document.getElementById("guestChatBox4").style.display = "none";
                document.getElementById("guestChatBox5").style.display = "none";
                break;
            case 4:
                document.getElementById("guestChatBox1").style.display = "flex";
                document.getElementById("guestChatBox2").style.display = "flex";
                document.getElementById("guestChatBox3").style.display = "flex";
                document.getElementById("guestChatBox4").style.display = "flex";
                document.getElementById("guestChatBox5").style.display = "none";
                break;
            case 5:
                document.getElementById("guestChatBox1").style.display = "flex";
                document.getElementById("guestChatBox2").style.display = "flex";
                document.getElementById("guestChatBox3").style.display = "flex";
                document.getElementById("guestChatBox4").style.display = "flex";
                document.getElementById("guestChatBox5").style.display = "flex";
                break;
        }
    }
    
    //new code
    function closeLeftMenuOptions() {
        var x = document.getElementsByClassName("leftSideMenuChoiceSelected");
        var i;
        for (i = 0; i < x.length; i++) {
            x[i].style.display = "none";
        }
    }
    
    function openLeftMenuOptions(a) {
        closeNav();
        var x = document.getElementsByClassName("leftSideMenuChoiceSelected");
        x[a].style.display = "flex";
    }
    
    //new code 10/02/2020
    
    function profileAddBand() {
        closeLeftMenuOptions();
        document.getElementById("profileAddBandContainer").style.display = "flex";
    }
    
    // new code 10/07/2020
    
    //#profileBandsILeadContent, #profileBandsIBelongToContent
    
    function openProfile() {
        closeNav();
        document.getElementById("stageContainer").style.display = "none";
        document.getElementById("twoGuests").style.display = "none";
        document.getElementById("manyGuests").style.display = "none";
        document.getElementById("userProfileContainer").style.display = "flex";
        document.getElementById("closeUserProfile").style.display = "block";
        document.getElementById("bandsILeadBtn").style.color = "red";
        document.getElementById("bandsIBelongToBtn").style.color = "white";
    }
    
    function closeUserProfile() {
        document.getElementById("userProfileContainer").style.display = "none";
        document.getElementById("closeUserProfile").style.display = "none";
        document.getElementById("bandsILeadBtn").style.color = "red";
        document.getElementById("stageContainer").style.display = "flex";
    }
    
    function leadOrBelongTo(x) {
        if (x == 1) {
            document.getElementById("profileBandsILeadContent").style.display = "flex";
            document.getElementById("bandsILeadBtn").style.color = "red";
            document.getElementById("profileBandsIBelongToContent").style.display = "none";
            document.getElementById("bandsIBelongToBtn").style.color = "white";
        } else if (x == 2) {
            document.getElementById("profileBandsILeadContent").style.display = "none";
            document.getElementById("bandsILeadBtn").style.color = "white";
            document.getElementById("profileBandsIBelongToContent").style.display = "flex";
            document.getElementById("bandsIBelongToBtn").style.color = "red";
        } else {
            alert("Oops. Something went wrong!");
        }
    }
    
    function closeRecordingPanel() {
        document.getElementById("recordingPanel").style.display = "none";
    }
    //
    //
    //
    // most stuff below has been added or modified...
    //
    //
    //
    //
    // below code after design overhaul
    var audioOnly = false;
    var numberOfCurrentCaptures = 1;
    var currentCapturePanel = 1;
    
    function newRecordingProcess() {
        document.getElementById("stageContainer").style.display = "none";
        var y = "newMainContentArea" + numberOfCurrentCaptures;
        document.getElementById(y).style.display = "none";
        document.getElementById("newMainToolbarExtra").style.display = "none";
        document.getElementById("newMainToolbar").style.display = "none";
        document.getElementById("newRecordingProcessContainer").style.display = "flex";
        document.getElementById("newRecordingPanelOneContainer").style.display = "flex";
        document.getElementById("closeNewRecording").style.display = "block";
        document.getElementById("newRecordingPanelTwoContainer").style.display = "none";
        document.getElementById("newRecordingPanelThreeContainer").style.display = "none";
        hideNewRecordingPanelFour();
        hideNewRecordingPanelFive();
        hideNewRecordingPanelSix();
        document.getElementById("newRecordingPanel7Container").style.display = "none";
        document.getElementById("newRecordingPanel8Container").style.display = "none";
        audioOnly = false;
    }
    
    
    
    function beanCounter() {
        // countdown
        var y = document.getElementById("newRecordingLeadTimeNum").value;
        var z = "panelFiveLeadTime" + numberOfCurrentCaptures;
        document.getElementById(z).innerHTML = y;
        var x = setInterval(leadTimeCounter, 1000);
    
        function leadTimeCounter() {
            if (y >= 1) {
                a = --y;
                document.getElementById(z).innerHTML = a;
            } else {
                clearInterval(x);
                newRecordingPanelSix();
            }
        }
    }
    
    function newRecordingPanelSix() {
        var y = "newRecordingPanelSixContainer" + numberOfCurrentCaptures;
        document.getElementById(y).style.display = "flex";
        hideNewRecordingPanelFive();
    }
    
    function tempTrackButtons(x) {
        if (x == 0) {
            document.getElementById("newRecordingPanelTwoWithoutTracks").style.display = "flex";
            document.getElementById("newRecordingPanelTwoWithTracks").style.display = "none";
        } else {
            document.getElementById("newRecordingPanelTwoWithoutTracks").style.display = "none";
            document.getElementById("newRecordingPanelTwoWithTracks").style.display = "flex";
        }
    }
    
    function fadeInCameraContent() {
        setTimeout(function () {
            var x = document.getElementById("newRecordingPanelThreeBottomLeft1");
            x.style.transition = "opacity 2s linear 0s";
            x.style.opacity = 1;
            var y = document.getElementById("newRecordingPanelThreeBottomLeft2");
            y.style.transition = "opacity 2s linear 2s";
            y.style.opacity = 1;
        }, 1000);
    }
    
    var stageStatus = "off";
    
    function newChangeView() {
        if (stageStatus == "off") {
            document.getElementById("stageContainer").style.display = "flex";
            var y = "newMainContentArea" + numberOfCurrentCaptures;
            document.getElementById(y).style.display = "none";
            stageStatus = "on";
        } else {
            document.getElementById("stageContainer").style.display = "none";
            var y = "newMainContentArea" + numberOfCurrentCaptures;
            document.getElementById(y).style.display = "flex";
            stageStatus = "off";
        }
    }
    
    function numberOfCurrentCapturesSwitch(x) {
        setShowStage(false);
        setShowStreams(true);
        numberOfCurrentCaptures = x;
        var y = "newMainContentArea" + numberOfCurrentCaptures;
        document.getElementById("stageContainer").style.display = "none";
        document.getElementById(y).style.display = "flex";
        for (var i = 8; i > numberOfCurrentCaptures; i--) {
            var a = "newMainContentArea" + i;
            document.getElementById(a).style.display = "none";
        }
        for (var i = 1; i < numberOfCurrentCaptures; i++) {
            var a = "newMainContentArea" + i;
            document.getElementById(a).style.display = "none";
        }
    }
    
    function updateRecordingFourCaptures() {
        var y = "newRecordingPanelFourContainer" + numberOfCurrentCaptures;
        document.getElementById(y).style.display = "flex";
        var z = document.getElementById("newRecordingLeadTimeNum").value;
        var x = "newRecordingActualLeadTime" + numberOfCurrentCaptures;
        document.getElementById(x).innerHTML = z;
        for (var i = 8; i > numberOfCurrentCaptures; i--) {
            var a = "newRecordingPanelFourContainer" + i;
            document.getElementById(a).style.display = "none";
        }
        for (var i = 1; i < numberOfCurrentCaptures; i++) {
            var a = "newRecordingPanelFourContainer" + i;
            document.getElementById(a).style.display = "none";
        }
    }
    
    function hideNewRecordingPanelFour() {
        for (var i = 8; i > 0; i--) {
            var a = "newRecordingPanelFourContainer" + i;
            document.getElementById(a).style.display = "none";
        }
    }
    
    function updateRecordingFiveCaptures() {
        var y = "newRecordingPanelFiveContainer" + numberOfCurrentCaptures;
        document.getElementById(y).style.display = "flex";
        for (var i = 8; i > numberOfCurrentCaptures; i--) {
            var a = "newRecordingPanelFiveContainer" + i;
            document.getElementById(a).style.display = "none";
        }
        for (var i = 1; i < numberOfCurrentCaptures; i++) {
            var a = "newRecordingPanelFiveContainer" + i;
            document.getElementById(a).style.display = "none";
        }
    }
    
    function hideNewRecordingPanelFive() {
        for (var i = 8; i > 0; i--) {
            var a = "newRecordingPanelFiveContainer" + i;
            document.getElementById(a).style.display = "none";
        }
    }
    
    function hideNewRecordingPanelSix() {
        for (var i = 8; i > 0; i--) {
            var a = "newRecordingPanelSixContainer" + i;
            document.getElementById(a).style.display = "none";
        }
    }
    
    function newRecordingPanel7() {
        hideNewRecordingPanelSix();
        document.getElementById("newRecordingPanel7Container").style.display = "flex";
        document.getElementById("newRecordingPanel8Container").style.display = "none";
    }
    
    function newRecordingPanel8() {
        document.getElementById("newRecordingPanel7Container").style.display = "none";
        document.getElementById("newRecordingPanel8Container").style.display = "flex";
    }

    

    // mixer
    function displayMixerNew() {
        document.getElementById("mixerCombo").style.display = "flex";
        var x = document.getElementsByTagName("header")[0];
        x.style.display = "none";
        document.getElementById("openbtn").style.display = "none";
    }

    function expandToolbar() {
        document.getElementById("newMainToolbarExtra").style.display = 'flex';
        document.getElementById("newMainToolbar").style.display = 'flex';
        document.getElementById("newMainToolbar").style.display = 'flex';
        document.getElementById("newCompactToolbar").style.display = 'none';
    }

    function closeExpandedToolbar() {
        document.getElementById("newMainToolbarExtra").style.display = 'none';
        document.getElementById("newMainToolbar").style.display = 'none';
        document.getElementById("newCompactToolbar").style.display = 'flex';
    }

    // END OF UI HANDLERS

    //load the playlist after component mounted
    // React.useEffect(() => {
    //     //init playlist
    //     console.log('this');
    //     if (!window.playlist) initPlaylist();
    //     //load the song if any
    //     if (songState.song !== null) {
    //         loadSong(songState.song, window.playlist, window.ee);
    //     }
    //     // forceUpdate();
    // }, [songState.song]);

    React.useEffect(() => {
        //init playlist
        initPlaylist();
        if (songState.song !== null) {
            loadSong(songState.song, window.playlist, window.ee);
        }
    }, []);

    const openSongHandler = async () => {

        startLoader();
        try {
            const song = await fetchSong(openSongName.trim());
            
            updateSongState({ song: song });
            forceUpdate();
            loadSong(song, window.playlist, window.ee);
        } catch (error) {
            console.log(error);
            window.alert('No such song exists');
            endLoader();
        }
        

    }

    const openSongWithId = async (id) => {
        startLoader();
        try {
            const song = await fetchSong(null, id);
            updateSongState({ song: song });
            forceUpdate();
            loadSong(song, window.playlist, window.ee);
        } catch (error) {
            window.alert('No such song exists');
            endLoader();
        }
    }

    const openResourceWithId = (id) => {
        const resource = allResources.filter(r => r.id == id)[0];
        if (resource) {
            // show streams for showing the notes sections and open this resource
            setOpenedResource(resource);
            setShowPdf(true);
            $("#btn-showStreams").click();

            // send the opened resource to the peers
            broadcast({
                type: 'OPENEDRESOURCE',
                openedResource: resource,
            });
            
        }

        document.getElementById('btn-resourceLibraryClose').click();
    }

    //Private handlers
    const playHandler = () => {
        //play all videojs videos and the playlist
        //play videos with different start times according to their track start time
        if (showStage) {

            const timeouts = [];
            var playheadPos = editorPlayhead;
            if (pauseState) playheadPos = pauseState;
            for (let vid of allVideos) {
                const id = `videojs-${vid.id}`;
                const thisVideo = videojs(id);
                //find track for this vid
                var track = playlist.tracks.filter(t => t.name == vid.name)[0];
                var startTime = playheadPos*1000;
                if (track) startTime = track.startTime*1000 - startTime;
                if (startTime < 0) {
                    thisVideo.currentTime(Math.abs(startTime/1000));
                    startTime = 0;
                }
                const timeout = {};
                timeout.id = setTimeout(() => {
                    thisVideo.play();
                }, startTime);
                timeout.time = startTime;
                timeout.videoId = vid.id;
                timeouts.push(timeout);
            }
            setVideoTimeouts(timeouts);

        }

        ee.emit('play');
        setPauseState(null);
    }
    const pauseHandler = () => {
        const pauseTime = currentPlaybackTime;
        setPauseState(pauseTime)
        // pausing the playlist
        ee.emit('pause');


        if (showStage) {

            // stopping the videos
            for (let timeout of videoTimeouts) {
                clearTimeout(timeout.id);
            }

            const videos = document.getElementsByClassName('video-js');
            for (let video of videos) {
                const id = video.id;
                const thisVideo = videojs(id);
                thisVideo.pause();
                thisVideo.currentTime(0);
            }

        }
    }
    const stopHandler = () => {
        setPauseState(null);
        
        if (showStage) {

            for (let timeout of videoTimeouts) {
                clearTimeout(timeout.id);
            }
    
            const videos = document.getElementsByClassName('video-js');
            for (let video of videos) {
                const id = video.id;
                const thisVideo = videojs(id);
                thisVideo.pause();
                thisVideo.currentTime(0);
            }

        }

        ee.emit('stop');
        // setCurrentPlaybackTime(0);
        
    }
    const jumpToStart = () => {
        setPauseState(null);
        ee.emit('rewind');

        if (showStage) {

            //stop video playback
            for (let timeout of videoTimeouts) {
                clearTimeout(timeout.id);
            }

            const videos = document.getElementsByClassName('video-js');
            for (let video of videos) {
                const id = video.id;
                const thisVideo = videojs(id);
                thisVideo.pause();
                thisVideo.currentTime(0);
            }

        }
        
    }
    const jumpToEnd = () => {
        setPauseState(null);
        var longestDuration = 0;
        //get the longest track with its startime
        for (let t of playlist.tracks) {
            const d = t.duration;
            const st = t.startTime;
            const totalDuration = d+st;
            if (totalDuration > longestDuration) longestDuration = totalDuration;
        }
        // stop and seek to this longestDuration 

        if (showStage) {

            //stopping video playback
            for (let timeout of videoTimeouts) {
                clearTimeout(timeout.id);
            }

            const videos = document.getElementsByClassName('video-js');
            for (let video of videos) {
                const id = video.id;
                const thisVideo = videojs(id);
                thisVideo.pause();
                thisVideo.currentTime(0);
            }

        }

        seekPlayback(longestDuration)
    }
    const skipForward = () => {
        setPauseState(null);
        //skips 5 sec froward in time
        const currentTime = currentPlaybackTime;
        $('#btn-stop').click();
        seekPlayback(currentTime+5);

        if (showStage) {

            //play all videojs videos and the playlist
            //play videos with different start times according to their track start time
            const timeouts = [];
            for (let vid of allVideos) {
                const id = `videojs-${vid.id}`;
                const thisVideo = videojs(id);
                //find track for this vid
                var track = playlist.tracks.filter(t => t.name == vid.name)[0];
                var startTime = (currentTime+5)*1000;
                if (track) startTime = track.startTime*1000 - startTime;
                if (startTime < 0) {
                    thisVideo.currentTime(Math.abs(startTime/1000));
                    startTime = 0;
                }
                const timeout = {};
                timeout.id = setTimeout(() => {
                    thisVideo.play();
                }, startTime);
                timeout.time = startTime;
                timeout.videoId = vid.id;
                timeouts.push(timeout);
            }
            setVideoTimeouts(timeouts);

        }

        ee.emit('play', currentTime+5);
    }
    const skipBack = () => {
        setPauseState(null);
        //skips 5 sec back in time
        const currentTime = currentPlaybackTime;
        $('#btn-stop').click();
        seekPlayback(currentTime-5);

        if (showStage) {

            //play all videojs videos and the playlist
            //play videos with different start times according to their track start time
            const timeouts = [];
            for (let vid of allVideos) {
                const id = `videojs-${vid.id}`;
                const thisVideo = videojs(id);
                //find track for this vid
                var track = playlist.tracks.filter(t => t.name == vid.name)[0];
                var startTime = (currentTime-5)*1000;
                if (track) startTime = track.startTime*1000 - startTime;
                if (startTime < 0) {
                    thisVideo.currentTime(Math.abs(startTime/1000));
                    startTime = 0;
                }
                const timeout = {};
                timeout.id = setTimeout(() => {
                    thisVideo.play();
                }, startTime);
                timeout.time = startTime;
                timeout.videoId = vid.id;
                timeouts.push(timeout);
            }
            setVideoTimeouts(timeouts);

        }

        ee.emit('play', currentTime-5);
    }

    const cursorHandler = () => {
        ee.emit("statechange", "cursor");
    }
    const shiftHandler = () => {
        ee.emit("statechange", "shift");
    }
    const selectHandler = () => {
        ee.emit("statechange", "select");
    }
    const exportHandler = () => {
        ee.emit('startaudiorendering', 'wav');
    }
    const saveHandler = async () => {
        if (songState.song !== null) {
            saveSong(songState.song.id);
        } else {
            // save a new song
            const name = window.prompt('Please type a unique name for a new song');
            
            if (name !== null && name !== '') {

                const isValidName = await checkNewSongName(name);
                if (isValidName) {
                    saveNewSong(name);
                } else {
                    window.alert('Song name is not valid');
                }

            }
        }
    }
    const allowEditHandler = () => {
        const newState = !allowEditChecked;
        setAllowEditChecked(newState);
        allowEditSwitch(newState);
    }

    const contributeHandler = () => {
        $('#modal-captureOptions').modal('show');
    }

    const addRemoteStream = (remoteStream) => {
        const remotePeerId = remoteStream.peerId;
        const container = document.querySelector('#remoteStreamsContainer');
        const streamVideoId = `remoteStream-${remotePeerId}`;
        //check if this streamVideo already exists
        const streamVideo = document.getElementById(streamVideoId);
        if (streamVideo) {
            //if streamVideo already exists, just put the stream in its srcObject
            streamVideo.srcObject = remoteStream.stream;
        }
        else {
            //if no streamVideo already exists, then create one and insert stream in its srcObject
            const ele = document.createElement('div');
            ele.className = 'remoteStream remoteStreamNoSelf';
            ele.id = `remoteStreamContainer-${remotePeerId}`;
            ele.innerHTML = `
                        <video className="streamVideo" autoPlay id="remoteStream-${remotePeerId}"></video>
            `
            container.appendChild(ele);
            const video = document.getElementById(`remoteStream-${remotePeerId}`);
            video.srcObject = remoteStream.stream;
        }
        
    }

    const createSessionHandler =  () => {
        createSession('').then(passcode => {
            window.alert(`session passcode: ${passcode}`);
        }).catch(e => {
            window.alert('there was some error while creating the session');
        });
    }

    const joinSessionHandler = async () => {
        //find session with passcode
        try {
            joinSession(null, joinSessionPasscode.trim());
        } catch (error) {
            window.alert('There was an error while joining the session');
        }
    }

    const leaveSessionHandler = () => {
        // removing all the stream container
        const containers = document.getElementsByClassName('remoteStreamNoSelf');
        for (let container of containers) {
            container.remove();
        }
        clearSong();
        updateAppState({ mode: 'BAND' });
        leaveSession()
    }

    const playForAllHandler = () => {
        broadcast({
            type: "COMMAND",
            data: "PLAY"
        });
        $('#btn-play').click();
        setIsPlayingForAll(true);

        //getting maximum duration of playback to switch playingForAll to false
        var longestDuration = 0;
        //get the longest track with its startime
        for (let t of playlist.tracks) {
            const d = t.duration;
            const st = t.startTime;
            const totalDuration = d+st;
            if (totalDuration > longestDuration) longestDuration = totalDuration;
        }

        setTimeout(() => {
            setIsPlayingForAll(false);
        }, longestDuration*1000);
    }
    const stopForAllHandler = () => {
        broadcast({
            type: "COMMAND",
            data: "STOP"
        });
        $('#btn-stop').click();
        setIsPlayingForAll(false);
    }

    //Handling recording
    const recordAudioVideoHandler = () => {
        setNewRecordingName(getDateString());
        setRecordingType('AUDIOVIDEO');
        setShowVideoRecordingDisplay(true);
    }
    

    const recordAudioOnlyHandler = () => {
        setNewRecordingName(getDateString());
        // setRecordingType('AUDIO');
        const leadTimeGetter = () => {
            return document.getElementById("leadTimeNum").value;
        }
        
        recordHandler(ee, null, '#stopRecordingBtn', setNewAudioBlob, leadTimeGetter);

        // handling playback while recording
        const lead = document.getElementById("leadTimeNum").value;
        const startPlaybackForRecording = () => {

            // if (followVideo !== null) {

            //     // get the videojs id from follow video id
            //     const id = `videojs-${followVideo.id}`;
            //     const vid = videojs(id);
            //     // get the startTime of audio of this video
            //     const audio = playlist.tracks.filter(t => t.name == followVideo.name)[0];
            //     setTimeout(() => {
            //         vid.play();
            //     }, audio.startTime*1000);

            // }

            playlist.play();
        }
        setTimeout(startPlaybackForRecording, lead*1000);

    }
    const startRecordingHandler = () => {
        //handling countdown display
        startRecording();
        setIsRecording(true);
        const lead = document.getElementById("leadTimeNum").value;
        const startPlaybackForRecording = () => {
            // get the videojs id from follow video id
            const followVideo = getFollowVideo();
            const id = `videojs-${followVideo.id}`;
            const vid = videojs(id);
            // get the startTime of audio of this video
            const audio = playlist.tracks.filter(t => t.name == followVideo.name)[0];
            playlist.play();
            setTimeout(() => {
                vid.play();
            }, audio.startTime*1000);
        }
        setTimeout(startPlaybackForRecording, lead*1000);

        // broadcasting recording info
        broadcast({
            type: 'INFO',
            data: {
                peerId: thisPeer.id,
                info: 'RECORDING START'
            }
        });
    }
    const stopRecordingHandler = () => {
        setLeadTime(5);
        setNewRecordingName(getDateString());
        document.getElementById('saveRecording').style.display = 'flex';
        setIsReadyToRecord(false);
        setIsRecording(false);
        // setDisplay('webcamContainer', false);
        $('#btn-stop').click();

        // broadcasting recording info
        broadcast({
            type: 'INFO',
            data: {
                peerId: thisPeer.id,
                info: 'RECORDING STOP'
            }
        });
    }

    // Adding video and audio handler
    

    const showStageHandler = () => {
        setShowStreams(false);
        setShowStage(true);
    }
    
    const showStreamsHandler = () => {
        setShowStage(false);
        setShowStreams(true);
    }

    const showLessStreamsHandler = () => {
        setShowStage(false);
        setShowStreams(true);
        setShowTopStreamsDisplay(true);
    }
    const showMoreStreamsHandler = () => {
        setShowStage(false);
        setShowStreams(true);
        setShowTopStreamsDisplay(false);
    }

    const followVideoSelector = (i) => {
        setFollowVideo(allVideos[i]);
    }

    

    const mouseOverFollowVideoHandler = (i) => {
        const container = document.getElementById(`character030${i}`);
        container.classList.add('greenBorder');
    }
    const mouseLeaveFollowVideoHandler = (i) => {
        const container = document.getElementById(`character030${i}`);
        container.classList.remove('greenBorder');
    }

    React.useEffect(() => {

        $('#videoContainerCollapsible').collapse('show');
        $('#playlistContainerCollapsible').collapse('show');
        $('#guestStreamsContainerCollapsible').collapse('show');
    }, []);

    React.useEffect(() => {

        //handle switching streams display by number of streams
        if (remoteStreams.length < 5 && remoteStreams.length > 0) {
            
            setShowTopStreamsDisplay(true);
        } else {
            setShowTopStreamsDisplay(false);
        }

    }, [remoteStreams]);

    React.useEffect(() => {

        async function handler() {
            if (isCalling && songState.song !== null) {

                const sessionRef = await db.collection('sessions').doc(thisSessionId);
                //check if the new loaded song id is different than the session songId
                const session = await sessionRef.get();
                const sessionData = session.data();
                if (sessionData.songId !== songState.song.id) {
    
                    //update the session songId
                    sessionRef.update({ songId: songState.song !== null ? songState.song.id : null })
                    .then(doc => {
    
                    }).catch(e => window.alert(e.message));
    
                }
    
            }
        }
        handler();

    }, [songState.song]);

    React.useEffect(() => {
        
        if (isCalling) {
            document.getElementById('btn-startSession')
        }

    }, [isCalling]);

    // PROFILE RELATED FUNCTIONS //

    const saveNewBandHandler = () => {
        const name = document.getElementById("newBandName").value;
        const city = document.getElementById("newBandCity").value;
        const state = document.getElementById("newBandState").value;
        const zip = document.getElementById("newBandZip").value;
        const website = document.getElementById("newBandWebsite").value;
        const estb = document.getElementById("newBandEstb").value;

        const createdBy = thisUserProfile.uid;

        createBand({ name, city, state, zip, website, estb }, createdBy);

    }

    const getBandMembers = (bandId) => {

        return new Promise((resolve, reject) => {

            db.collection('userProfiles').where("joinedBands", "array-contains", bandId).get().then(docs => {
                const members = [];
                docs.forEach(doc => {
                    const member = doc.data();
                    members.push(member);
                });
                resolve(members);
            }).catch(e => reject(e));

        })

    }

    const addMemberHandler = () => {
        // adds the member to the selected band using the username
        if (memberToAddUsername !== '' && selectedBandId !== null) {

            // add the selectedBandId to the memberToAdd profile joinedBands array
            db.collection('userProfiles').where("username", "==", memberToAddUsername).limit(1).get().then(docs => {

                if (docs.docs.length > 0) {

                    db.collection('userProfiles').doc(docs.docs[0].id).update({ joinedBands: firebase.firestore.FieldValue.arrayUnion(selectedBandId)})
                    .then(() => {

                        // successfully added the member. Refresh the member list
                        getBandMembers(selectedBandId).then(members => setSelectedBandMembers(members));
                        window.alert('Band member was added successfully!');

                    }).catch(e => {
                        console.log(e);
                        window.alert('There was an error while adding the member :(');
                    });

                }
                else {
                    // no such member exists
                    window.alert('No such user exists');
                }

            }).catch(e => {
                // no such member exists
                window.alert('No such user exists');
            })

        }
    }
    const deleteMemberHandler = () => {
        // removes the sleected member from selected band
        if (selectedMemberId !== null && selectedBandId !== null) {

            // remove the selectedBandId from the joinedBands array of the selectedMember user Profile
            db.collection('userProfiles').where("uid", "==", selectedMemberId).limit(1).get().then(docs => {
                
                db.collection('userProfiles').doc(docs.docs[0].id).update({ joinedBands: firebase.firestore.FieldValue.arrayRemove(selectedBandId) })
                    .then(() => {
                        // successfully removed the member. Refresh the member list
                        getBandMembers(selectedBandId).then(members => setSelectedBandMembers(members));
                        window.alert('Band member was removed successfully!');
                    }).catch(e => {
                        console.log(e);
                        window.alert('There was an error while removing the member :(');
                    });

            }).catch(e => {
                console.log(e);
                window.alert('There was an error');
            });

        }
    }

    // updates band members list for selected band
    React.useEffect(() => {
        if (selectedBandId !== null) {
            getBandMembers(selectedBandId).then(members => {
                setSelectedBandMembers(members);
            }).catch(e => console.log(e));
        }
    }, [selectedBandId]);

    const deleteNote = (noteId) => {
        startLoader();
        if (noteId !== null) {
            db.collection('notes').doc(noteId).delete().then(() => {
                endLoader();
            }).catch(e => {
                endLoader();
                window.alert('There was an error deleting the note :(');
            });
        } else {
            endLoader();
        }
    }

    const uploadPdf = (e) => {
        e.preventDefault();
        const file = document.getElementById('pdfFileUpload').files[0];
        if (file) {
            saveNewResource(file);
            $("#addResourceModal").modal('hide');
        }
    }
    // switch to streams display after joining the session
    React.useEffect(() => {
        if (thisSessionId !== null) {
            $("#btn-showStreams").click();
            broadcast({
                type: "BUTTONCLICK",
                buttonId: "btn-showStreams"
            });
        }
    }, [thisSessionId]);

    // switching views for peers if this is session owner
    React.useEffect(() => {
        if (thisSessionId !== null && thisSessionData.createdBy == thisUserProfile.uid && allowClickShare == true) {
            if (showStage) {
                console.log("sending btn click showSTage");
                broadcast({ type: "BUTTONCLICK", buttonId: "btn-showStage" });
            }
            else {
                console.log("sending btn click showStreams");
                broadcast({ type: "BUTTONCLICK", buttonId: "btn-showStreams" });
            }
        }
    }, [showStage]);

    return (
        <div id="container">

            <div id="blur"></div>

            {/* session code popup modal */}
            <div className="modal fade" id="sessionCodeModal" tabIndex="-1" role="dialog"
                aria-labelledby="sessionCodeModal" aria-hidden="true">
                <div className="modal-dialog modal-dialog-centered" role="document">
                    <div className="modal-content">
                        <div className="modal-header">
                            <h5 className="modal-title" id="sessionCodeModalTitle">Session passcode</h5>
                            
                        </div>
                        <div className="modal-body">
                            
                            <h3 style={{textAlign: 'center'}}>Session passcode: {thisSessionData !== null ? thisSessionData.passcode : ''}</h3>

                        </div>
                        <div className="modal-footer">
                            <button onClick={() => {
                                
                                $("#sessionCodeModal").modal('hide');
                            }} type="button" className="btn btn-primary">Ok</button>
                        </div>
                    </div>
                </div>
            </div>

            {/* note delete popup modal */}
            <div className="modal fade" id="noteDeleteModal" tabIndex="-1" role="dialog"
                aria-labelledby="noteDeleteModal" aria-hidden="true">
                <div className="modal-dialog modal-dialog-centered" role="document">
                    <div className="modal-content">
                        <div className="modal-header">
                            <h5 className="modal-title" id="noteDeleteModalTitle"></h5>
                            
                        </div>
                        <div className="modal-body">
                            
                            <h3 style={{textAlign: 'center'}}>Are you sure you want to delete this note?</h3>

                        </div>
                        <div className="modal-footer">
                            <button type="button" className="btn btn-secondary" data-dismiss="modal">No</button>
                            <button onClick={() => deleteNote(noteIdToDelete)} data-dismiss="modal" type="button" className="btn btn-primary">Delete</button>
                        </div>
                    </div>
                </div>
            </div>

            {/* resource delete popup modal */}
            <div className="modal fade" id="resourceDeleteModal" tabIndex="-1" role="dialog"
                aria-labelledby="resourceDeleteModal" aria-hidden="true">
                <div className="modal-dialog modal-dialog-centered" role="document">
                    <div className="modal-content">
                        <div className="modal-header">
                            <h5 className="modal-title" id="resourceDeleteModalTitle"></h5>
                            
                        </div>
                        <div className="modal-body">
                            
                            <h3 style={{textAlign: 'center'}}>Are you sure you want to delete this resource?</h3>

                        </div>
                        <div className="modal-footer">
                            <button type="button" className="btn btn-secondary" data-dismiss="modal">No</button>
                            <button onClick={() => deleteResource(resourceIdToDelete)} data-dismiss="modal" type="button" className="btn btn-primary">Delete</button>
                        </div>
                    </div>
                </div>
            </div>
            {/* song delete popup modal */}
            <div className="modal fade" id="songDeleteModal" tabIndex="-1" role="dialog"
                aria-labelledby="songDeleteModal" aria-hidden="true">
                <div className="modal-dialog modal-dialog-centered" role="document">
                    <div className="modal-content">
                        <div className="modal-header">
                            <h5 className="modal-title" id="songDeleteModalTitle"></h5>
                            
                        </div>
                        <div className="modal-body">
                            
                            <h3 style={{textAlign: 'center'}}>Are you sure you want to delete this song?</h3>

                        </div>
                        <div className="modal-footer">
                            <button type="button" className="btn btn-secondary" data-dismiss="modal">No</button>
                            <button onClick={() => deleteSong(songIdToDelete)} data-dismiss="modal" type="button" className="btn btn-primary">Delete</button>
                        </div>
                    </div>
                </div>
            </div>
            
            {/* <div id="numberOfCapturesContainerForBtns">
                <button id="btn-showStreams" onClick={()=>{setShowStage(false); setShowStreams(true)}}>Show Streams</button>
                <button id="btn-showStage" onClick={()=>{setShowStage(true); setShowStreams(false)}}>Show Stage</button>
                
            </div> */}
            
            <header>
                <img src="./assets/logo.png" alt="Stagetrack Studio" id="logo" />
                <div id="session">
                    <input disabled={isCalling?false:true} onClick={leaveSessionHandler} type="image" src="./assets/sessionLeave.png" className="session" alt="Leave Session" />
                    <input onClick={pauseMediaStream} type="image" src="./assets/sessionPause.png" className="session" alt="Pause Session" />
                    <input onClick={() => $("#sessionCodeModal").modal('show')} type="image" src="./assets/sessionStart.png" className="session" alt="Start Session" />
                </div>
                <div id="headerBandContainer">
                    <div id="bandName">{thisSessionBand !== null ? thisSessionBand.name : ''}</div>
                    <div id="headerBandSongName">{songState.song !== null ? songState.song.name : ''}</div>
                </div>
                {/* session passcode
                {
                    isCalling && thisSessionData !==null ? 
                        <p style={{position: 'absolute', top: 'calc(100vh - 30px)', left: '10px', zIndex: '10'}}>{`session passcode: ${thisSessionData.passcode}` }</p>
                    : null
                } */}
            </header>
            <div id="contentContainer">

                <aside id="nav_side">
                    <div id="mySidepanel" className="sidepanel">
                        <a href="javascript:void(0)" className="closebtn" onClick={closeNav}>&times;</a>
                        <a href="#" onClick={() => openLeftMenuOptions(3)}>Admin</a>
                        <a id="btn-notes" href="#" onClick={() => openLeftMenuOptions(2)}>Notes</a>
                        <a id="btn-resourceLibrary" href="#" onClick={() => openLeftMenuOptions(1)}>Resource Library</a>
                        <a id="btn-songLibrary" href="#" onClick={() => openLeftMenuOptions(0)}>Song Library</a>
                        <a href="#" onClick={() => openLeftMenuOptions(4)}>Band Profile</a>
                        <a href="bandLogin.html">Band</a>
                        <a href="actorLogin.html">Actor</a>
                        {/* <a href="register.html">Register</a> */}
                        {/* <a href="vid website.7z" download>Files</a> */}
                        <a href="splashPage.html">Splash</a>
                        <a href="https://stagetrack.online/vendor/">Vendor</a>
                        <a href="https://stagetrack.online/store/">Store</a>

                        {/* <input className="form-control" id="inp-songId" size="40" onInput={(e) => {setOpenSongName(e.target.value)}} placeholder="Song name"/>
                        <button type="button" onClick={openSongHandler}>Open song</button> */}

                    </div>

                    <button className="openbtn" id="openbtn" onClick={openNav}>&#9776;</button>

                </aside>

                {/* song library */}
                <div className="leftSideMenuChoiceSelected">
                    <a href="javascript:void(0)" className="closeLeftMenuOption" onClick={closeLeftMenuOptions}>&times;</a>
                    <div className="lSMCSTitleContainer">
                        <div className="lSMCSTitle">Song Library</div>
                        <div className="arrow-down"></div>
                    </div>

                    {
                        allBands.map(band => {
                            return (
                                <React.Fragment key={band.id}>
                                    <div className="lSMCSNameContainer">
                                        <div className="lSMCSBandName">{band.name}</div>
                                    </div>

                                    {
                                        allSongs.filter(s => s.bandId == band.id).map(song => {
                                            return (
                                                <div key={`mySongs-${song.id}`} className="lSMCSSongName">
                                                    <p>{song.name}</p>
                                                    <a id={song.id} href="javascript:void(0)" style={{color: 'red'}} onClick={(e) => {$("#songDeleteModal").modal('show'); setSongIdToDelete(song.id)}}>&times;</a>
                                                    <div className="editSelectBtns">
                                                        <input onClick={(e) => openSongWithId(song.id)} type="image" src="../assets/leftSideMenuArrow.png"></input>
                                                    </div>
                                                </div>
                                            )
                                        })
                                    }
                                    
                                </React.Fragment>
                            )
                        })
                    }

                </div>

                {/* upload pdf popup modal */}
                <div className="modal fade" id="addResourceModal" tabIndex="-1" role="dialog"
                    aria-labelledby="addResourceModal" aria-hidden="true">
                    <div className="modal-dialog modal-dialog-centered" role="document">
                        <div className="modal-content">
                            <div className="modal-header">
                                <h5 className="modal-title" id="addResourceModalTitle">Upload a pdf file to open</h5>
                                
                            </div>
                            <div className="modal-body">
                                <form onSubmit={(e) => uploadPdf(e)}>
                                    <div className="form-group">
                                        <label>Upload pdf file</label>
                                        <input type="file" className="form-control-file" id="pdfFileUpload"></input>
                                        <button type="submit" className="btn btn-primary mb-2">Upload</button>
                                    </div>
                                </form>  

                            </div>
                            
                        </div>
                    </div>
                </div>

                {/* Resource Library */}
                <div className="leftSideMenuChoiceSelected">
                    <a id="btn-resourceLibraryClose" href="javascript:void(0)" className="closeLeftMenuOption" onClick={closeLeftMenuOptions}>&times;</a>
                    <button onClick={() => $("#addResourceModal").modal('show')} type="button" id="leftSideAddNoteBtn">Add Resource</button>
                    <div className="lSMCSTitleContainer">
                        <div className="lSMCSTitle">Resource Library</div>
                        <div className="arrow-down"></div>
                    </div>

                    {
                        allBands.map(band => {
                            return (
                                <React.Fragment key={band.id}>
                                    <div className="lSMCSNameContainer">
                                        <div className="lSMCSBandName">{band.name}</div>
                                    </div>

                                    {
                                        allResources.filter(r => r.bandId == band.id).map(resource => {
                                            return (
                                                <div key={`myResources-${resource.id}`} className="lSMCSSongName">
                                                    <p>{resource.name}</p>
                                                    <a id={resource.id} href="javascript:void(0)" style={{color: 'red'}} onClick={(e) => {$("#resourceDeleteModal").modal('show'); setResourceIdToDelete(resource.id)}}>&times;</a>
                                                    <div className="editSelectBtns">
                                                        <input onClick={(e) => openResourceWithId(resource.id)} type="image" src="../assets/leftSideMenuArrow.png"></input>
                                                    </div>
                                                </div>
                                            )
                                        })
                                    }
                                    
                                </React.Fragment>
                            )
                        })
                    }

                    {
                        thisSessionBand!== null && allBands.map(b => b.id).includes(thisSessionBand.id) == false?
                            <React.Fragment>
                                <div className="lSMCSNameContainer">
                                    <div className="lSMCSBandName">{thisSessionBand.name}</div>
                                </div>
                                {
                                        allResources.filter(r => r.bandId == thisSessionBand.id).map(resource => {
                                            return (
                                                <div key={`myResources-${resource.id}`} className="lSMCSSongName">
                                                    <p>{resource.name}</p>
                                                    <a id={resource.id} href="javascript:void(0)" style={{color: 'red'}} onClick={(e) => {$("#resourceDeleteModal").modal('show'); setResourceIdToDelete(resource.id)}}>&times;</a>
                                                    <div className="editSelectBtns">
                                                        <input onClick={(e) => openResourceWithId(resource.id)} type="image" src="../assets/leftSideMenuArrow.png"></input>
                                                    </div>
                                                </div>
                                            )
                                        })
                                    }
                            </React.Fragment>
                        : null
                    }


                </div>

                {/* Notes */}
                <div className="leftSideMenuChoiceSelected">
                    <a id="btn-notesClose" href="javascript:void(0)" className="closeLeftMenuOption" onClick={closeLeftMenuOptions}>&times;</a>
                    <button type="button" data-toggle="collapse" data-target="#leftSideAddNoteContent" aria-expanded="false"
                        aria-controls="collapseExample" id="leftSideAddNoteBtn">Add Note</button>
                    <div className="lSMCSTitleContainer">
                        <div className="lSMCSTitle">Notes</div>
                        <div className="arrow-down"></div>
                    </div>
                    <div className="collapse" id="leftSideAddNoteContent">
                        <div>
                            <textarea required name="" id="newNoteTitle" cols="30" rows="1"
                                placeholder="Title"></textarea>
                            <textarea required name="" id="newNoteDetails" cols="30" rows="4"
                                placeholder="Note..."></textarea>
                            <button onClick={() => {
                                const title = document.getElementById("newNoteTitle").value;
                                const body = document.getElementById("newNoteDetails").value;
                                createNote(thisSessionData.bandId, {title, body});
                            }} type="button" id="leftSideAddNoteSubmitBtn">Submit</button>
                        </div>
                    </div>

                    {
                        allNotes.map(n => {
                            return (
                                <React.Fragment key={n.id}>
                                <div className="lSMCSNameContainer">
                                    <div className="lSMCSLastName">{n.title}</div>
                                    <a id={n.id} href="javascript:void(0)" style={{color: 'red'}} onClick={(e) => {$("#noteDeleteModal").modal('show'); setNoteIdToDelete(n.id)}}>&times;</a>
                                </div>
                                <div className="lSMCSNotes">
                                    <p className="yb-btn" onClick={() => { setYbMode("NOTES"); setNote(n.body); document.getElementById('btn-notesClose').click(); }}>{n.body}</p>
                                </div>
                                </React.Fragment>
                            )
                        })
                    }
                    

                </div>

                {/* Admin */}
                <div className="leftSideMenuChoiceSelected">
                    <a href="javascript:void(0)" className="closeLeftMenuOption" onClick={closeLeftMenuOptions}>&times;</a>
                    <div className="lSMCSTitleContainer">
                        <div className="lSMCSTitle">Admin</div>
                        <div className="arrow-down"></div>
                    </div>
                    {
                        thisSessionId !== null && thisSessionData.createdBy == thisUserProfile.uid ?
                            <div className="custom-control custom-checkbox mr-sm-2">
                                <input onChange={(e) => setAllowClickShare(e.target.checked)} type="checkbox" className="custom-control-input" id="customControlAutosizing" />
                                <label className="custom-control-label" for="customControlAutosizing">Allow click share</label>
                            </div>
                        : null
                    }
                </div>

                {/* Profile */}
                <div className="leftSideMenuChoiceSelected">
                    <a href="javascript:void(0)" className="closeLeftMenuOption" onClick={closeLeftMenuOptions}>&times;</a>
                    <div id="profileTitleContainer">
                        <h6>Username</h6>
                        <div id="actualProfileOwner">{thisUserProfile.username}</div>
                        
                    </div>
                    <div id="bandsILeadContainer">
                        Bands I Lead
                        <button type="button" data-toggle="collapse" data-target="#bandsILead" aria-expanded="false"
                            aria-controls="bandsILead" className="bandsILeadBtn">
                            +
                        </button>


                    </div>
                    <div className="collapse" id="bandsILead">
                        <div id="profileAddBandContainer">
                            <div id="profileAddBandTitle">Add Band</div>
                            <form id="profileAddBandForm">
                                <input id="newBandName" type="text" placeholder="Name" />
                                <input id="newBandCity" type="text" placeholder="City" />
                                <input id="newBandState" type="text" placeholder="State" />
                                <input id="newBandZip" type="text" placeholder="ZIP" />
                                <input id="newBandWebsite" type="text" placeholder="Band Website" />
                                <input id="newBandEstb" type="text" placeholder="Date Established" />
                            </form>
                            <div id="profileAddBandToDirectory">
                                <input type="checkbox" name="" />
                                <p>Add band to directory</p>
                            </div>
                            <button onClick={saveNewBandHandler} id="addBandSaveBtn">Save</button>
                        </div>

                    </div>

                    <div id="bandsILeadList">

                        {
                            allBands.map((band, i) => {
                                if (band.createdBy == authState.user.uid) {
                                    return (
                                        <React.Fragment key={band.id}>
                                        <button onClick={() => setSelectedBandId(band.id)} type="button" data-toggle="collapse" data-target={`#bandsILead${i}`} aria-expanded="false"
                                            aria-controls={`#bandsILead${i}`} className="bandsILeadBtn">
                                            {`+ ${band.name}`}
                                        </button>

                                        <div className="collapse" id={`bandsILead${i}`}>
                                            <div>
                                                <table className="bandsILeadTable">
                                                    <tbody>
                                                        <tr>
                                                            <td></td>
                                                            <td><button>Invite All</button></td>
                                                            <td><button>Edit</button></td>
                                                        </tr>
                                                        {
                                                            selectedBandMembers.map(m => {
                                                                return (
                                                                    <tr key={m.uid}>
                                                                        <td style={{color: 'white'}}>{m.firstName + ' ' + m.lastName}</td>
                                                                        <td><button>Invite</button></td>
                                                                        <td></td>
                                                                    </tr>
                                                                )
                                                            })
                                                        }
                                                    </tbody>
                                                </table>
                                            </div>
                                            <div id="profileAddBandContainer">
                                                <div id="profileAddBandTitle">Edit Band</div>
                                                <form id="profileAddBandForm">
                                                    <input value={band.name ? band.name : ""} type="text" name="" id="bandName" placeholder="Name" />
                                                    <input value={band.city ? band.city : ""} type="text" name="" id="bandCity" placeholder="City" />
                                                    <input value={band.state ? band.state : ""} type="text" name="" id="bandState" placeholder="State" />
                                                    <input value={band.zip ? band.zip : ""} type="text" name="" id="bandZip" placeholder="ZIP" />
                                                    <input value={band.website ? band.website : ""} type="text" name="" id="bandWebsite" placeholder="Band Website" />
                                                    <input value={band.estb ? band.estb : ""} type="text" name="" id="bandEstb" placeholder="Date Established" />
                                                </form>
                                                <div id="profileAddBandToDirectory">
                                                    <input type="checkbox" name="" id="" />
                                                    <p>Add band to directory</p>
                                                </div>
                                                <button id="addBandSaveBtn">Save</button>
                                            </div>

                                            <div id="bandsILeadMembersList">
                                                <h5>Band Members</h5>
                                                <select name="" id="selectedBandMember" size="4">
                                                    {
                                                        selectedBandMembers.map(m => {
                                                            return (
                                                                <option onClick={() => setSelectedMemberId(m.uid)} key={m.uid} value="">{m.firstName + ' ' + m.lastName}</option>
                                                            )
                                                        })
                                                    }
                                                </select>
                                                <div id="addDeleteBandMember">
                                                    <input value={memberToAddUsername} onChange={(e) => setMemberToAddUsername(e.target.value.trim())} type="text" placeholder="username..." />
                                                    <button onClick={addMemberHandler} id="addBandMemberSave">Add</button>
                                                    <button onClick={deleteMemberHandler} id="bandsILeadListDelete">Delete</button>
                                                </div>
                                            </div>
                                        </div>
                                        </React.Fragment>

                                    )
                                }
                            })
                        }
                        

                    </div>
                    
                    <div id="bandsIBelongToTitle">Bands I Belong To</div>

                    <div id="bandsIBelongToList">

                        {
                            allBands.map((band, i) => {
                                if (thisUserProfile.joinedBands.indexOf(band.id) !== -1) {
                                    return (
                                        <React.Fragment key={band.id}>
                                        <button onClick={() => setSelectedBandId(band.id)} type="button" data-toggle="collapse" data-target={`#bandsIBelongTo${i}`} aria-expanded="false"
                                            aria-controls={`#bandsIBelongTo${i}`} className="bandsILeadBtn">
                                            {`+ ${band.name}`}
                                        </button>

                                        <div className="collapse" id={`bandsIBelongTo${i}`}>
                                            <div>
                                                <table className="bandsILeadTable">
                                                    <tbody>
                                                        <tr>
                                                            <td></td>
                                                            <td><button>Invite All</button></td>
                                                            <td><button>Leave</button></td>
                                                        </tr>
                                                        {
                                                            selectedBandMembers.map(member => {
                                                                return (
                                                                    <tr key={member.uid}>
                                                                        <td style={{color: 'white'}}>{member.firstName + ' ' + member.lastName}</td>
                                                                        <td><button>Invite</button></td>
                                                                        <td></td>
                                                                    </tr>
                                                                )
                                                            })
                                                        }
                                                    </tbody>
                                                    
                                                </table>
                                            </div>
                                        </div>
                                        </React.Fragment>
                                    )
                                }
                            })
                        }

                    </div>
                    <div id="bandsSendInviteTitle">Send Invite</div>
                    <div id="bandsSendInviteContent">
                        <input type="text" placeholder="Send email or text" />
                        <button type="submit">Send</button>
                    </div>
                </div>


                <main>
                    <div className="mainTop">
                        
                        {/* StreamsBoxes goes here */}

                        {
                            showVideoRecordingDisplay ?
                                <VideoRecordingDisplay followVideo={followVideo} close={() => {setShowVideoRecordingDisplay(false); setShowStage(true);}} />
                            :
                            
                                
                                    showStage ?
                                        <Stage allVideos={allVideos} />
                                        // <Draw/>
                                    : showStreams ? 
                                        <StreamsGrid showPdf={showPdf}/>
                                    : null
                                
                            
                        }
                        
                        <div id="metronomeStartContainer">
                            <Metronome/>
                        </div>
                        
                        <div id="newMainToolbarExtra">

                            <button className="newExtraMainBtn">GigTrack</button>
                            <button id="btn-showMetronome" className="newExtraMainBtn" onClick={() => {displayMetronome(); shareClickWithPeers("btn-showMetronome")}}>Metronome</button>
                            <button id="btn-showMixer" className="newExtraMainBtn" onClick={() => {displayMixerNew(); shareClickWithPeers("btn-showMixer")}}>Mixer</button>

                            <button className="newExtraMainBtn" onClick={() => setShowVideoRecordingDisplay(true)}>Record</button>
                            <button id="btn-showTracks" className="newExtraMainBtn" onClick={() => {showTracks(); shareClickWithPeers("btn-showTracks")}}>Tracks</button>
                            {/* <button className="newExtraMainBtn" >View</button> */}

                            <button style={showStage?{display:'block'}:{display:'none'}} className="newExtraMainBtn" id="btn-showStreams" onClick={()=>{setShowStage(false); setShowStreams(true)}}>Show Streams</button>
                            <button style={showStage?{display:'none'}:{display:'block'}} className="newExtraMainBtn" id="btn-showStage" onClick={()=>{setShowStage(true); setShowStreams(false)}}>Show Stage</button>

                            <button className="newExtraMainBtn" id="openchatbtn" onClick={openChat}>Chat</button>  
                            <a href="javascript:void(0)" id="closeExpandedToolbar" onClick={closeExpandedToolbar}>×</a>                          

                        </div>

                        <div id="newMainToolbar">
                            <input onClick={jumpToStart} type="image" src="./assets/newMainBtn1.png" />
                            <input onClick={skipBack} type="image" src="./assets/newMainBtn2.png" />
                            <input id="btn-stop" onClick={stopHandler} type="image" src="./assets/newMainBtn3.png" />
                            <input id="btn-play" onClick={playHandler} type="image" src="./assets/newMainBtn4.png" />
                            <input onClick={playForAllHandler} type="image" src="./assets/newMainBtn5.png" />
                            <input id="btn-pause" onClick={pauseHandler} type="image" src="./assets/newMainBtn6.png" />
                            <input onClick={skipForward} type="image" src="./assets/newMainBtn7.png" />
                            <input onClick={jumpToEnd} type="image" src="./assets/newMainBtn8.png" />

                            <div className="flexItem tool" id="btn-upload" onClick={saveHandler}>
                                            <svg width="1.5em" height="1.5em" viewBox="0 0 16 16" className="bi bi-download" fill="white" xmlns="http://www.w3.org/2000/svg">
                                                <path fillRule="evenodd" d="M4.406 3.342A5.53 5.53 0 0 1 8 2c2.69 0 4.923 2 5.166 4.579C14.758 6.804 16 8.137 16 9.773 16 11.569 14.502 13 12.687 13H3.781C1.708 13 0 11.366 0 9.318c0-1.763 1.266-3.223 2.942-3.593.143-.863.698-1.723 1.464-2.383zm.653.757c-.757.653-1.153 1.44-1.153 2.056v.448l-.445.049C2.064 6.805 1 7.952 1 9.318 1 10.785 2.23 12 3.781 12h8.906C13.98 12 15 10.988 15 9.773c0-1.216-1.02-2.228-2.313-2.228h-.5v-.5C12.188 4.825 10.328 3 8 3a4.53 4.53 0 0 0-2.941 1.1z"/>
                                                <path fillRule="evenodd" d="M7.646 5.146a.5.5 0 0 1 .708 0l2 2a.5.5 0 0 1-.708.708L8.5 6.707V10.5a.5.5 0 0 1-1 0V6.707L6.354 7.854a.5.5 0 1 1-.708-.708l2-2z"/>
                                                </svg>            
                            </div>

                        </div>
                        <button id="newCompactToolbar" onClick={expandToolbar} style={{display: 'flex'}}>Toolbar</button>
                    </div>
                    
                    <div id="tracksContainer">
                        <div id="tracksToolbar">
                            <button onClick={shiftHandler} id="shiftingTrackBtn">Shifting track</button>
                            <button onClick={cursorHandler} id="cursorBtn">Cursor</button>
                        </div>
                        <a href="javascript:void(0)" id="closeTracks" onClick={() => {closeTracks(); shareClickWithPeers("closeTracks")}}>&times;</a>
                        <button id="minTracks" onClick={() => {minimizeTracks(); shareClickWithPeers("minTracks")}}></button>
                        <div id="tracksInner">
                            
                            <div id="playlist">hello</div>

                        </div>
                    </div>
                    
                    {/* mixer */}
                    <Mixer/>

                    {/* Metronome */}







                </main>

                <div id="mySidepane2" className="sidepane2">
                    <a style={{marginTop: '10px'}} href="javascript:void(0)" className="closechatbtn" onClick={closeChat}>&times;</a>
                    <Chatbox/>

                </div>

                {/* <div id="newRightSideContentContainer">
                    <div id="newRightSideTimer">
                        <p className="newRightSideTimerLabels">Bar</p>
                        <p className="newRightSideTimerNumbers">1</p>
                        <p className="newRightSideTimerLabels">Beat</p>
                        <p className="newRightSideTimerNumbers">25</p>
                        <p className="newRightSideTimerLabels">Time</p>
                        <p className="newRightSideTimerNumbers">00:01:04:69</p>
                    </div>
                    <div id="newRightSideMasterVolumeLabel">Master<br/>Volume</div>
                    <div id="newRightSideMasterVolumeContainer">
                        <div id="newRightSideMasterVolume">
                            <input type="range" min="1" max="10" id="newRightSideVolumeSlider" />
                        </div>
                    </div>
                    <button className="openchatbtn" id="openchatbtn" onClick={openChat}>C<br/>h<br/>a<br/>t</button>
                </div> */}

                
            </div>

        </div>
    )

}