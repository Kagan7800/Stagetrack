
const VideoRecordMenu = (props) => {

    const {

        startLoader,
        endLoader,
        newTracks,
        setNewTracks,
        newVideos,
        allVideos,
        setAllVideos,
        setNewVideos,
        extractAudioFromVideo,

    } = React.useContext(MainContext);

    const [newVideoName, setNewVideoName] = React.useState(getDateString());

    var newVideoUrl = URL.createObjectURL(props.newVideoBlob);

    function getDateString() {
        const date = new Date();
        const year = date.getFullYear();
        const month = `${date.getMonth() + 1}`.padStart(2, '0');
        const day =`${date.getDate()}`.padStart(2, '0');
        return `${year}-${month}-${day}-${date.getHours()}:${date.getMinutes()}:${date.getSeconds()}`
    }

    const checkNewVideoName = (name) => {
        const names = playlist.tracks.map(t => t.name);
        const videoNames = allVideos.map(vid => vid.name);
        if (name == '') return false;
        if (names.indexOf(name) !== -1) {
            return false
        }
        if (videoNames.indexOf(name) !== -1) {
            return false
        }
        return true;
    }

    const addVideoHandler = async () => {
        //adds video along with its audio track to the song
        //get the video blob, extract audio, save the audio into newTracks and load into playlist, 
        //save video into newVideos, and load into the video views
        startLoader();
        if (checkNewVideoName(newVideoName)) {

            //create track id from name by removing existing spaces
            const nameSplit = newVideoName.split(' ');
            var TrackId = '';
            for (let substr of nameSplit) {
                TrackId += substr;
            }

            const audioBlob = await extractAudioFromVideo(props.newVideoBlob);
            const videoUrl = URL.createObjectURL(props.newVideoBlob);
            setNewTracks([...newTracks, {blob: audioBlob, name: newVideoName.trim(), id: TrackId}]);
            setNewVideos([...newVideos, {blob: props.newVideoBlob, name: newVideoName.trim(), id: TrackId}]);
            setAllVideos([...allVideos, {src: videoUrl, name: newVideoName.trim(), id: TrackId}]);

            //load audio
            playlist.load([
                {
                    "src": audioBlob,
                    "name": newVideoName.trim(),
                }
            ]).then(() => {
                endLoader();
                playlist.initExporter();
            });
            
            //video is already added from the upadate in allVideos global array. Videos in editSong comp are updated as listening to
            // allVideos
            props.close();



        }
        else {
            endLoader();
            window.alert('Invalid Video Name!');
        }

    }


    return (
        <div>
            <button type="button" className="close float-right" data-dismiss="modal" aria-label="Close" style={{position: 'absolute', float: 'right'}} onClick={() => props.close()}>
                <span aria-hidden="true">&times;</span>
            </button>
            <VideoPlayer id='videojs-newCapturedVideo' width={640} height={480} src={newVideoUrl}/>

            <div>
                <input type="text" size="40" className="form-control" id="inp-newVideoName" placeholder="Unique video name" value={newVideoName} onChange={(e) => setNewVideoName(e.target.value)}></input>
                <button id="btn-addVideo" type="button" className="btn btn-primary flexItem" onClick={addVideoHandler}>Add Video</button>
            </div>

        </div>
    )

}