
const Signup = () => {

    const { signUp } = React.useContext(MainContext);

    const [email, setEmail] = React.useState('');
    const [password1, setPassword1] = React.useState('');
    const [password2, setPassword2] = React.useState('');

    const signUpHandler = () => {
        if (password1 == password2) {
            signUp(email, password1);
        } else {
            window.alert("passwords dont match");
        }
    }

    return (
        <div id="comp-signUp">
            <div className="container flexItem">
                <form>
                    <div className="form-group">
                        <label style={{color: 'black'}}>Email address</label>
                        <input type="email" className="form-control" id="inp-signupEmail" aria-describedby="emailHelp" onChange={(e) => setEmail(e.target.value)} value={email}></input>
                        <small id="emailHelp" className="form-text text-muted">We'll never share your email with anyone
                            else.</small>
                    </div>
                    <div className="form-group">
                        <label style={{color: 'black'}}>Password</label>
                        <input type="password" className="form-control" id="inp-signupPassword1" onChange={(e) => setPassword1(e.target.value)} value={password1}></input>
                    </div>
                    <div className="form-group">
                        <label style={{color: 'black'}}>Confirm Password</label>
                        <input type="password" className="form-control" id="inp-signupPassword2" onChange={(e) => setPassword2(e.target.value)} value={password2}></input>
                    </div>
                    <button type="button" id="btn-signUp" className="btn btn-primary" onClick={signUpHandler}>Sign Up</button>
                </form>
            </div>
        </div>
    )

}