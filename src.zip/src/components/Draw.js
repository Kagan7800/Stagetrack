
const Draw = (props) => {

    const { drawingCanvas, setDrawingCanvas } = React.useContext(MainContext);
    const { sharedCanvas, setSharedCanvas, broadcast } = React.useContext(SessionContext);

    const [canvasWidth, setCanvasWidth] = React.useState(500);
    const [canvasHeight, setCanvasHeight] = React.useState(500);
    const [ctx, setCtx] = React.useState(null);
    const [thisCanvas, setThisCanvas] = React.useState(null);

    function fitToContainer(canvas) {
        // Make it visually fill the positioned parent
        canvas.style.width = '100%';
        canvas.style.height = '100%';
        // ...then set the internal size to match
        canvas.width = canvas.offsetWidth;
        canvas.height = canvas.offsetHeight;
    }

    const resetCanvas = (ctx) => {
        ctx.rect(0, 0, canvasWidth, canvasHeight);
        ctx.fillStyle = 'white';
        ctx.fill();

        // sending canvas
        const cnvs = document.getElementById("canvasDraw")
        const base64Canvas = cnvs.toDataURL("image/jpeg");
        broadcast({
            type: "SHAREDCANVAS",
            canvas: base64Canvas
        });

    }

    React.useEffect(() => {
        var canvasMain = document.getElementById('canvasDraw');
        canvasMain.width = canvasWidth;
        canvasMain.height = canvasHeight;
        // fitToContainer(canvasMain);
        const thisCtx = canvasMain.getContext('2d');

        // setting background color

        thisCtx.rect(0, 0, canvasMain.width, canvasMain.height);
        thisCtx.fillStyle = 'white';
        thisCtx.fill();

        setCtx(thisCtx);

        // draw the shared canvas if there is any
        if (sharedCanvas !== null) {
            var image = new Image();
            image.onload = function() {
                thisCtx.drawImage(image, 0, 0);
            };
            image.src = sharedCanvas;
        }
        else if (drawingCanvas !== null) {
            var image = new Image();
            image.onload = function() {
                thisCtx.drawImage(image, 0, 0);
            };
            image.src = drawingCanvas;
        }

    }, []);

    React.useEffect(() => {

        if (ctx) {
            document.addEventListener('mousemove', draw);
            document.addEventListener('mousedown', setPosition);
            document.addEventListener('mouseenter', setPosition);
        }

    }, [ctx]);

    // handles drawing the recieved drawingcanvas from other peers on update
    React.useEffect(() => {
        if (ctx && sharedCanvas !== null) {

            var image = new Image();
            image.onload = function() {
                ctx.drawImage(image, 0, 0);

                // set drawingCanvas
                const cnvs = document.getElementById("canvasDraw");
                const base64Canvas = cnvs.toDataURL("image/jpeg");
                setDrawingCanvas(base64Canvas);

            };
            image.src = sharedCanvas;

        }
    }, [sharedCanvas]);

    var pos = { x: 0, y: 0 };

    function setPosition(e) {
        pos.x = e.clientX;
        pos.y = e.clientY;
    }

    function draw(e) {
        // mouse left button must be pressed
        if (e.buttons !== 1) return;

        ctx.beginPath(); 

        ctx.lineWidth = 2;
        ctx.lineCap = 'butt';
        ctx.strokeStyle = 'black';

        var offsets = $('#canvasDraw').offset();
        var top = offsets.top;
        var left = offsets.left;

        ctx.moveTo(pos.x-left, pos.y-top);
        setPosition(e);
        ctx.lineTo(pos.x-left, pos.y-top);

        ctx.stroke();

        // set thisCanvas every time draw is called
        const cnvs = document.getElementById("canvasDraw")

        // sending canvas
        const base64Canvas = cnvs.toDataURL("image/jpeg");
        setDrawingCanvas(base64Canvas);
        broadcast({
            type: "SHAREDCANVAS",
            canvas: base64Canvas
        });
        
    }

    return (
        <div className="flexHor" style={{width: '100%', height: '100%'}}>
            
            <canvas id="canvasDraw"></canvas>
            <div className="flexVer" id="whiteboard-toolbar" style={{margin: '10px'}}>
                <button onClick={() => resetCanvas(ctx)} type="button" className="btn btn-outline-dark btn-sm">Clear</button>
            </div>
            
        </div>
    )

}