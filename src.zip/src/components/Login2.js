
const Login2 = () => {

    const { signIn, appState, updateAppState, signInGoogle, sendResetPasswordLink } = React.useContext(MainContext);

    const [email, setEmail] = React.useState('');
    const [emailForgotPassword, setEmailForgotPassword] = React.useState('');
    const [password, setPassword] = React.useState('');

    const forgotPasswordHandler = () => {
        $('#modal-forgotPassword').modal('show');
    }
    const sendResetPasswordLinkHandler = () => {
        sendResetPasswordLink(emailForgotPassword);
        $('#modal-forgotPassword').modal('hide');
    }

    return (

        <div id="registrationContainer">

            {/* forgot password modal */}
            <div className="modal fade" id="modal-forgotPassword" tabIndex="-1" role="dialog">
                <div className="modal-dialog modal-dialog-centered" role="document">
                    <div className="modal-content">
                        <div className="modal-header">
                            <h5 className="modal-title">Forgot password?</h5>
                            <button type="button" className="close" data-dismiss="modal">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div className="modal-body">
                            <div className="container">
                                <input type="email" className="form-control" id="inp-emailForgotPassword" placeholder="Email" aria-describedby="emailHelp" onInput={(e) => {setEmailForgotPassword(e.target.value)}}></input>
                                <div className="float-right flexItem">
                                    <button type="button" id="btn-signIn" className="btn btn-primary btn-sm" onClick={sendResetPasswordLinkHandler}>Send reset password link</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div className="registrationBoxes" id="loginBox">
                <h3>Login</h3>
                <div className="registrationForm">
                    <input onInput={(e) => {setEmail(e.target.value)}} type="email" name="email" id="email" placeholder="Email" />
                    <input onInput={(e) => {setPassword(e.target.value)}} type="password" name="password" id="password" placeholder="Password" />
                    <button onClick={() => {signIn(email, password)}}>Submit</button>
                </div>
                <a onClick={() => {updateAppState({mode: 'SIGNUP'})}} href="#">Register New User</a>
                <a onClick={signInGoogle} href="#">Sign in with Google</a>
                <a onClick={forgotPasswordHandler} href="#">Forgot Password</a>
            </div>
        </div>

    );

}