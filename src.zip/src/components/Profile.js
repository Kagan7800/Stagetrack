const Profile = () => {

    const { updateAppState, authState, allBands, thisUserProfile } = React.useContext(MainContext);

    const [selectedBandId, setSelectedBandId] = React.useState(null);
    const [selectedMemberId, setSelectedMemberId] = React.useState(null);
    const [memberToAddUsername, setMemberToAddUsername] = React.useState('');
    const [selectedBandMembers, setSelectedBandMembers] = React.useState([]);

    // Private handlers
    const getBandMembers = (bandId) => {

        console.log('getting band members');

        return new Promise((resolve, reject) => {

            db.collection('userProfiles').where("joinedBands", "array-contains", bandId).get().then(docs => {
                const members = [];
                docs.forEach(doc => {
                    const member = doc.data();
                    members.push(member);
                });
                resolve(members);
            }).catch(e => reject(e));

        })

    }

    const addMemberHandler = () => {
        // adds the member to the selected band using the username
        if (memberToAddUsername !== '' && selectedBandId !== null) {

            // add the selectedBandId to the memberToAdd profile joinedBands array
            db.collection('userProfiles').where("username", "==", memberToAddUsername).limit(1).get().then(docs => {

                if (docs.docs.length > 0) {

                    db.collection('userProfiles').doc(docs.docs[0].id).update({ joinedBands: firebase.firestore.FieldValue.arrayUnion(selectedBandId)})
                    .then(() => {

                        // successfully added the member. Refresh the member list
                        getBandMembers(selectedBandId).then(members => setSelectedBandMembers(members));
                        window.alert('Band member was added successfully!');

                    }).catch(e => {
                        console.log(e);
                        window.alert('There was an error while adding the member :(');
                    });

                }
                else {
                    // no such member exists
                    window.alert('No such user exists');
                }

            }).catch(e => {
                // no such member exists
                window.alert('No such user exists');
            })

        }
    }
    const deleteMemberHandler = () => {
        // removes the sleected member from selected band
        if (selectedMemberId !== null && selectedBandId !== null) {

            // remove the selectedBandId from the joinedBands array of the selectedMember user Profile
            db.collection('userProfiles').where("uid", "==", selectedMemberId).limit(1).get().then(docs => {
                
                db.collection('userProfiles').doc(docs.docs[0].id).update({ joinedBands: firebase.firestore.FieldValue.arrayRemove(selectedBandId) })
                    .then(() => {
                        // successfully removed the member. Refresh the member list
                        getBandMembers(selectedBandId).then(members => setSelectedBandMembers(members));
                        window.alert('Band member was removed successfully!');
                    }).catch(e => {
                        console.log(e);
                        window.alert('There was an error while removing the member :(');
                    });

            }).catch(e => {
                console.log(e);
                window.alert('There was an error');
            });

        }
    }

    // updates band members list for selected band
    React.useEffect(() => {
        if (selectedBandId !== null) {
            getBandMembers(selectedBandId).then(members => {
                setSelectedBandMembers(members);
            }).catch(e => console.log(e));
        }
    }, [selectedBandId]);

    React.useEffect(() => {
        console.log('selectedBandMembers: ', selectedBandMembers);
    }, [selectedBandMembers]);


    // UI Handlers

    function closeUserProfile() {
        setSelectedBandMembers([]);
        document.getElementById("userProfileContainer").style.display = "none";
        document.getElementById("closeUserProfile").style.display = "none";
        document.getElementById("bandsILeadBtn").style.color = "red";
        document.getElementById("stageContainer").style.display = "flex";
    }

    function leadOrBelongTo(x) {
        if (x == 1) {
            setSelectedBandMembers([]);
            const bandId = document.getElementById('bandsILeadBandSelection').value;
            console.log('bandId: ', bandId);

            if (bandId !== '') {
                setSelectedBandId(bandId);
            }

            document.getElementById("profileBandsILeadContent").style.display = "flex";
            document.getElementById("bandsILeadBtn").style.color = "red";
            document.getElementById("profileBandsIBelongToContent").style.display = "none";
            document.getElementById("bandsIBelongToBtn").style.color = "white";

        } else if (x == 2) {
            setSelectedBandMembers([]);
            const bandId = document.getElementById('bandsIBelingToBandSelection').value;
            console.log('bandId: ', bandId);

            if (bandId !== '') {
                setSelectedBandId(bandId);
            }

            document.getElementById("profileBandsILeadContent").style.display = "none";
            document.getElementById("bandsILeadBtn").style.color = "white";
            document.getElementById("profileBandsIBelongToContent").style.display = "flex";
            document.getElementById("bandsIBelongToBtn").style.color = "red";
        } else {
            alert("Oops. Something went wrong!");
        }
    }

    return (
        <React.Fragment>
            <a href="javascript:void(0)" id="closeUserProfile" onClick={closeUserProfile}>&times;</a>
            <div id="userProfileTitleContainer">
                <h6>Username: {thisUserProfile.username}</h6>
                <button id="bandsILeadBtn" onClick={() => leadOrBelongTo(1)}>Bands I lead</button>
                <button id="bandsIBelongToBtn" onClick={() => leadOrBelongTo(2)}>Bands I belong to</button>
            </div>
            <div id="profileBandsILeadContent">
                <div className="bandsAndMembersList">
                    <div id="bandsILeadList">
                        <select id="bandsILeadBandSelection" name="bandsILeadList" size="4">
                            {
                                allBands.map(band => {
                                    if (band.createdBy == authState.user.uid) {
                                        return (
                                            <option onClick={() => setSelectedBandId(band.id)} key={band.id} value={band.id}>{band.name}</option>
                                        )
                                    }
                                })
                            }
                        </select>
                        <button id="bandsILeadListDelete">Delete</button>
                    </div>
                    <div id="bandsILeadMembersList">
                        <h5>Band Members</h5>
                        <select name="bandsILeadMembersList" size="4">
                            {
                                selectedBandMembers.map(member => {
                                    return (
                                        <option onClick={() => setSelectedMemberId(member.uid)} key={member.uid} value={member.uid}>{member.firstName + ' ' + member.lastName}</option>
                                    )
                                })
                            }
                        </select>
                        <div id="addDeleteBandMember">
                            <input value={memberToAddUsername} onChange={(e) => setMemberToAddUsername(e.target.value.trim())} type="text" placeholder="username..." />
                            <button onClick={addMemberHandler} id="addBandMemberSave">Add</button>
                            <button onClick={deleteMemberHandler} id="bandsILeadListDelete">Delete</button>
                        </div>
                    </div>
                </div>
                <div id="profileAddBandContainer">
                    <div id="profileAddBandTitle">Add/ Edit Band</div>
                    <form id="profileAddBandForm">
                        <input type="text" placeholder="Name" />
                        <input type="text" placeholder="City" />
                        <input type="text" placeholder="State" />
                        <input type="text" placeholder="ZIP" />
                        <input type="text" placeholder="Band Website" />
                        <input type="text" placeholder="Date Established" />
                    </form>
                    <div id="profileAddBandPhotoContainer">
                        <p>Add Band Photo</p>
                        <img src="../assets/cameraIcon.png" />
                    </div>
                    <div id="profileAddBandToDirectory">
                        <input type="checkbox" name="" id="" />
                        <p>Add band to directory</p>
                    </div>
                    <button id="addBandSaveBtn">Save</button>
                </div>
            </div>


            <div id="profileBandsIBelongToContent">
                <div className="bandsAndMembersList">
                    <div id="bandsIBelongToList">
                        <select id="bandsIBelingToBandSelection" name="bandsIBelongToList" size="4">
                            {
                                allBands.map(band => {
                                    if (thisUserProfile.joinedBands.indexOf(band.id) !== -1) {
                                        return (
                                            <option onClick={() => setSelectedBandId(band.id)} key={band.id} value={band.id}>{band.name}</option>
                                        )
                                    }
                                })
                            }
                        </select>
                        <button id="bandsIBelongToListDelete">Leave</button>
                    </div>
                    <div id="bandsIBelongToMembersList">
                        <h5>Band Members</h5>
                        <select name="bandsIBelongToMembersList" size="4">
                            {
                                selectedBandMembers.map(member => {
                                    return (
                                        <option key={member.uid} value={member.uid}>{member.firstName + ' ' + member.lastName}</option>
                                    )
                                })
                            }
                        </select>
                    </div>
                </div>
                <div id="profileAddBandContainer">
                    <div id="profileAddBandTitle">Band Info</div>
                    <form id="profileAddBandForm">
                        <input type="text" name="" />
                        <input type="text" name="" />
                        <input type="text" name="" />
                        <input type="text" name="" />
                        <input type="text" name="" />
                        <input type="text" name="" />
                    </form>
                </div>
            </div>
        </React.Fragment>
    )

}