
const Signup2 = () => {

    const { signUp } = React.useContext(MainContext);

    const [email, setEmail] = React.useState('');
    const [password1, setPassword1] = React.useState('');
    const [password2, setPassword2] = React.useState('');

    const [firstName, setFirstName] = React.useState('');
    const [lastName, setLastName] = React.useState('');
    const [phone, setPhone] = React.useState('');
    const [zip, setZip] = React.useState('');

    const signUpHandler = () => {

        if (firstName == '' || lastName == '' || email == '' || password1 == '') {
            window.alert('Please fill in the required information');
            return;
        }

        if (password1 == password2) {

            //create profile object
            const profile = {
                firstName: firstName,
                lastName: lastName,
                phone: phone,
                zip: zip
            }

            signUp(email, password1, profile);
        } else {
            window.alert("passwords dont match");
        }
    }

    return (
        <div id="registrationContainer">

            <div className="registrationBoxes" id="registerBox">
                <h3>Register as New User</h3>
                <div className="registrationForm">
                    <input required onChange={(e) => setFirstName(e.target.value)} value={firstName} type="text" name="firstName" id="firstName" placeholder="First Name" />
                    <input required onChange={(e) => setLastName(e.target.value)} value={lastName} type="text" name="lastName" id="lastName" placeholder="Last Name" />
                    <input onChange={(e) => setPhone(e.target.value)} value={phone} type="text" name="phone" id="phone" placeholder="Text / Phone #" />
                    <input onChange={(e) => setZip(e.target.value)} value={zip} type="text" name="zip" id="zip" placeholder="Zip Code" />
                    <input required onChange={(e) => setEmail(e.target.value)} value={email} type="email" name="email" id="email" placeholder="Email" />
                    <input required onChange={(e) => setPassword1(e.target.value)} value={password1} type="password" name="password1" id="inp-signupPassword1" placeholder="Password" />
                    <input required onChange={(e) => setPassword2(e.target.value)} value={password2} type="password" name="password1" id="inp-signupPassword2" placeholder="Confirm Password" />
                    <button onClick={signUpHandler}>Submit</button>
                </div>
            </div>

        </div>
    )

}