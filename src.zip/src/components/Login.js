
const Login = () => {

    const { signIn, appState, updateAppState, signInGoogle, sendResetPasswordLink } = React.useContext(MainContext);

    const [email, setEmail] = React.useState('');
    const [emailForgotPassword, setEmailForgotPassword] = React.useState('');
    const [password, setPassword] = React.useState('');

    const forgotPasswordHandler = () => {
        $('#modal-forgotPassword').modal('show');
    }
    const sendResetPasswordLinkHandler = () => {
        sendResetPasswordLink(emailForgotPassword);
        $('#modal-forgotPassword').modal('hide');
    }

    return (
        <div id="comp-signIn">

            {/* capture options modal */}
            <div className="modal fade" id="modal-forgotPassword" tabIndex="-1" role="dialog">
                <div className="modal-dialog modal-dialog-centered" role="document">
                    <div className="modal-content">
                        <div className="modal-header">
                            <h5 className="modal-title">Forgot password?</h5>
                            <button type="button" className="close" data-dismiss="modal">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div className="modal-body">
                            <div className="container">
                                <input type="email" className="form-control" id="inp-emailForgotPassword" placeholder="Email" aria-describedby="emailHelp" onInput={(e) => {setEmailForgotPassword(e.target.value)}}></input>
                                <div className="float-right flexItem">
                                    <button type="button" id="btn-signIn" className="btn btn-primary btn-sm" onClick={sendResetPasswordLinkHandler}>Send reset password link</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div className="container flexItem">
                <form>
                    <div className="form-group">
                        <label style={{color: 'black'}}>Email address</label>
                        <input type="email" className="form-control" id="inp-email" aria-describedby="emailHelp" onInput={(e) => {setEmail(e.target.value)}}></input>
                        <small id="emailHelp" className="form-text text-muted">We'll never share your email with anyone
                            else.</small>
                    </div>
                    <div className="form-group">
                        <label style={{color: 'black'}}>Password</label>
                        <input type="password" className="form-control" id="inp-password" onInput={(e) => {setPassword(e.target.value)}}></input>
                    </div>
                    <button type="button" id="btn-signIn" className="btn btn-primary" onClick={() => {signIn(email, password)}}>Sign in</button>
                </form>
            </div>
            <div style={{width: '50%'}} className="flexHor flexItem">
                <div className="container flexItem">
                    <button id="btn-signUpForm" type="button" className="btn btn-primary" onClick={() => {updateAppState({mode: 'SIGNUP'})}}>Create new account</button>
                </div>
                <div className="container flexItem">
                    <button id="btn-signInGoogle" type="button" className="btn btn-primary" onClick={signInGoogle}><img src="https://upload.wikimedia.org/wikipedia/commons/5/53/Google_%22G%22_Logo.svg" width="32" alt="Sign in with google"></img>Sign In</button>
                </div>
                <div className="container flexItem">
                    <button id="btn-forgotPassword" type="button" className="btn btn-primary" onClick={forgotPasswordHandler}>Forgot Password</button>
                </div>
            </div>
            
        </div>
    );

}