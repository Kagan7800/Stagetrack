
const Whiteboard = (props) => {

    return (
        <div className="whiteboard">
            
        </div>
    )

}