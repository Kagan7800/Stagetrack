
const Mixer = (props) => {

    // UI Handlers
    // new 12/5

    function closeMixerNew() {
        document.getElementById("mixerCombo").style.display = "none";
        var x = document.getElementsByTagName("header")[0];
        x.style.display = "flex";
        document.getElementById("openbtn").style.display = "block";
    }

    function mixerPanelToggleSwitch(x) {
        if (x == 0) {
            document.getElementById("mixerPanelToggleOff").style.color = "#a92d0b";
            document.getElementById("mixerPanelToggleOn").style.color = "black";
        } else {
            document.getElementById("mixerPanelToggleOff").style.color = "black";
            document.getElementById("mixerPanelToggleOn").style.color = "#5fb713";
        }
    }

    // mixer combo draggable

    // var dragMixerItem = document.querySelector("#draggableMixerItem");
    // var mixerCombo = document.querySelector("#mixerCombo");

    // var activeMixer = false;
    // var currentXMixer;
    // var currentYMixer;
    // var initialXMixer;
    // var initialYMixer;
    // var xOffsetMixer = 0;
    // var yOffsetMixer = 0;

    // mixerCombo.addEventListener("touchstart", dragStartMixer, false);
    // mixerCombo.addEventListener("touchend", dragEndMixer, false);
    // mixerCombo.addEventListener("touchmove", dragMixer, false);

    // mixerCombo.addEventListener("mousedown", dragStartMixer, false);
    // mixerCombo.addEventListener("mouseup", dragEndMixer, false);
    // mixerCombo.addEventListener("mousemove", dragMixer, false);

    // function dragStartMixer(e) {
    //     if (e.type === "touchstart") {
    //         initialXMixer = e.touches[0].clientX - xOffsetMixer;
    //         initialYMixer = e.touches[0].clientY - yOffsetMixer;
    //     } else {
    //         initialXMixer = e.clientX - xOffsetMixer;
    //         initialYMixer = e.clientY - yOffsetMixer;
    //     }

    //     if (e.target === dragMixerItem) {
    //         activeMixer = true;
    //     }
    // }

    // function dragEndMixer(e) {
    //     initialXMixer = currentXMixer;
    //     initialYMixer = currentYMixer;

    //     activeMixer = false;
    // }

    // function dragMixer(e) {
    //     if (activeMixer) {

    //         e.preventDefault();

    //         if (e.type === "touchmove") {
    //             currentXMixer = e.touches[0].clientX - initialXMixer;
    //             currentYMixer = e.touches[0].clientY - initialYMixer;
    //         } else {
    //             currentXMixer = e.clientX - initialXMixer;
    //             currentYMixer = e.clientY - initialYMixer;
    //         }

    //         xOffsetMixer = currentXMixer;
    //         yOffsetMixer = currentYMixer;

    //         setTranslate(currentXMixer, currentYMixer, dragMixerItem);
    //     }
    // }

    // function setTranslate(xPos, yPos, el) {
    //     el.style.transform = "translate3d(" + xPos + "px, " + yPos + "px, 0)";
    // }


    return (
        <div id="mixerCombo">
            <div id="draggableMixerItem">
                <div id="mixerPanelNew">
                    <div id="mixerPanelNewInner">
                        <div id="mixerPanelNewUpper">
                            <div id="mixerPanelVolumeMasterOuter">
                                <div className="mixerPanelVolumeLeft">
                                    <img src="assets/newMixerClip.png" className="newMixerClip" />
                                    <h4>14db</h4>
                                    <input type="image" src="assets/newMixerVolumeUp1.png" className="newMixerClip" />
                                    <input type="image" src="assets/newMixerVolumeDown1.png" className="newMixerClip" />
                                    <h5>Volume<br/>Master</h5>
                                </div>
                                <div className="mixerPanelVolumeRight">
                                    <img src="assets/newMixerVolumeBarDouble.png" className="newMixerVolumeDoubleBars" />
                                </div>
                            </div>
                            <div className="mixerPanelVolumeTrackOuter">
                                <div className="mixerPanelVolumeLeftSingle">
                                    <img src="assets/newMixerClip.png" className="newMixerClipSingle" />
                                    <h4>14db</h4>
                                    <input type="image" src="assets/newMixerVolumeUp2.png" className="newMixerClipSingle" />
                                    <input type="image" src="assets/newMixerVolumeDown2.png"
                                        className="newMixerClipSingle" />
                                    <h5 className="whiteText">Volume<br/>Track 1</h5>
                                </div>
                                <div className="mixerPanelVolumeRightSingle">
                                    <img src="assets/newMixerVolumeBarSingle.png" className="newMixerVolumeBars" />
                                </div>
                            </div>
                            <div className="mixerPanelVolumeTrackOuter">
                                <div className="mixerPanelVolumeLeftSingle">
                                    <img src="assets/newMixerClip.png" className="newMixerClipSingle" />
                                    <h4>14db</h4>
                                    <input type="image" src="assets/newMixerVolumeUp2.png" className="newMixerClipSingle" />
                                    <input type="image" src="assets/newMixerVolumeDown2.png"
                                        className="newMixerClipSingle" />
                                    <h5 className="whiteText">Volume<br/>Track 2</h5>
                                </div>
                                <div className="mixerPanelVolumeRightSingle">
                                    <img src="assets/newMixerVolumeBarSingle.png" className="newMixerVolumeBars" />
                                </div>
                            </div>
                            <div className="mixerPanelVolumeTrackOuter">
                                <div className="mixerPanelVolumeLeftSingle">
                                    <img src="assets/newMixerClip.png" className="newMixerClipSingle" />
                                    <h4>14db</h4>
                                    <input type="image" src="assets/newMixerVolumeUp2.png" className="newMixerClipSingle" />
                                    <input type="image" src="assets/newMixerVolumeDown2.png"
                                        className="newMixerClipSingle" />
                                    <h5 className="whiteText">Volume<br/>Track 3</h5>
                                </div>
                                <div className="mixerPanelVolumeRightSingle">
                                    <img src="assets/newMixerVolumeBarSingle.png" className="newMixerVolumeBars" />
                                </div>
                            </div>
                            <div className="mixerPanelVolumeTrackOuter">
                                <div className="mixerPanelVolumeLeftSingle">
                                    <img src="assets/newMixerClip.png" className="newMixerClipSingle" />
                                    <h4>14db</h4>
                                    <input type="image" src="assets/newMixerVolumeUp2.png" className="newMixerClipSingle" />
                                    <input type="image" src="assets/newMixerVolumeDown2.png"
                                        className="newMixerClipSingle" />
                                    <h5 className="whiteText">Volume<br/>Track 4</h5>
                                </div>
                                <div className="mixerPanelVolumeRightSingle">
                                    <img src="assets/newMixerVolumeBarSingle.png" className="newMixerVolumeBars" />
                                </div>
                            </div>
                            <div className="mixerPanelVolumeTrackOuter">
                                <div className="mixerPanelVolumeLeftSingle">
                                    <img src="assets/newMixerClip.png" className="newMixerClipSingle" />
                                    <h4>14db</h4>
                                    <input type="image" src="assets/newMixerVolumeUp2.png" className="newMixerClipSingle" />
                                    <input type="image" src="assets/newMixerVolumeDown2.png"
                                        className="newMixerClipSingle" />
                                    <h5 className="whiteText">Volume<br/>Track 5</h5>
                                </div>
                                <div className="mixerPanelVolumeRightSingle">
                                    <img src="assets/newMixerVolumeBarSingle.png" className="newMixerVolumeBars" />
                                </div>
                            </div>
                            <div className="mixerPanelVolumeTrackOuter">
                                <div className="mixerPanelVolumeLeftSingle">
                                    <img src="assets/newMixerClip.png" className="newMixerClipSingle" />
                                    <h4>14db</h4>
                                    <input type="image" src="assets/newMixerVolumeUp2.png" className="newMixerClipSingle" />
                                    <input type="image" src="assets/newMixerVolumeDown2.png"
                                        className="newMixerClipSingle" />
                                    <h5 className="whiteText">Volume<br/>Track 6</h5>
                                </div>
                                <div className="mixerPanelVolumeRightSingle">
                                    <img src="assets/newMixerVolumeBarSingle.png" className="newMixerVolumeBars" />
                                </div>
                            </div>
                            <div className="mixerPanelVolumeTrackOuter">
                                <div className="mixerPanelVolumeLeftSingle">
                                    <img src="assets/newMixerClip.png" className="newMixerClipSingle" />
                                    <h4>14db</h4>
                                    <input type="image" src="assets/newMixerVolumeUp2.png" className="newMixerClipSingle" />
                                    <input type="image" src="assets/newMixerVolumeDown2.png"
                                        className="newMixerClipSingle" />
                                    <h5 className="whiteText">Volume<br/>Track 7</h5>
                                </div>
                                <div className="mixerPanelVolumeRightSingle">
                                    <img src="assets/newMixerVolumeBarSingle.png" className="newMixerVolumeBars" />
                                </div>
                            </div>
                            <div className="mixerPanelVolumeTrackOuter">
                                <div className="mixerPanelVolumeLeftSingle">
                                    <img src="assets/newMixerClip.png" className="newMixerClipSingle" />
                                    <h4>14db</h4>
                                    <input type="image" src="assets/newMixerVolumeUp2.png" className="newMixerClipSingle" />
                                    <input type="image" src="assets/newMixerVolumeDown2.png"
                                        className="newMixerClipSingle" />
                                    <h5 className="whiteText">Volume<br/>Track 8</h5>
                                </div>
                                <div className="mixerPanelVolumeRightSingle">
                                    <img src="assets/newMixerVolumeBarSingle.png" className="newMixerVolumeBars" />
                                </div>
                            </div>
                            <div className="mixerPanelVolumeTrackOuter">
                                <div className="mixerPanelVolumeLeftSingle">
                                    <img src="assets/newMixerClip.png" className="newMixerClipSingle" />
                                    <h4>14db</h4>
                                    <input type="image" src="assets/newMixerVolumeUp2.png" className="newMixerClipSingle" />
                                    <input type="image" src="assets/newMixerVolumeDown2.png"
                                        className="newMixerClipSingle" />
                                    <h5 className="whiteText">Volume<br/>Track 9</h5>
                                </div>
                                <div className="mixerPanelVolumeRightSingle">
                                    <img src="assets/newMixerVolumeBarSingle.png" className="newMixerVolumeBars" />
                                </div>
                            </div>
                        </div>
                        <div id="mixerPanelNewLower">
                            <div id="mixerPanelNewLowerLeft">
                                <button className="mixerPanelLowerAudioBtn">Audio</button>
                            </div>
                            <div id="mixerPanelNewLowerMiddle">
                                <h5>Master Mix</h5>
                                <div className="mixerPanelToggleContainer">
                                    <button id="mixerPanelToggleOff"
                                        onClick={() => mixerPanelToggleSwitch(0)}>Off</button>
                                    <button id="mixerPanelToggleOn"
                                        onClick={() => mixerPanelToggleSwitch(1)}>On</button>
                                </div>
                                <h6>Master Mix Assign</h6>
                                <button className="mixerPanelLowerHostBtn">Host</button>
                            </div>
                            <div id="mixerPanelNewLowerRight">
                                <h5>Input Gain</h5>
                                <img src="assets/newMixerInputGainColor.png" />
                                <div id="controlPanelMasterVolume">
                                    <input type="range" min="1" max="10" value="2"
                                        id="controlPanelMasterVolumeSlider" />
                                </div>
                                <input type="image" src="assets/mixerInternalMic.png" />
                            </div>
                        </div>
                    </div>
                </div>
                <div id="tracksContainerNew">
                    <div className="tracksNew">
                        <div className="trackLabelsNew">
                            <div className="trackLabelNewTrackName">#1 - [Name]</div>
                            <div className="trackLabelNewMContainer">
                                <button className="trackLabelMBtn">M</button>
                                <button className="trackLabelDeleteBtn">Delete</button>
                            </div>
                            <div className="trackLabelNewSContainer">
                                <button className="trackLabelSBtn">S</button>
                                <button className="trackLabelNotesBtn">Notes</button>
                            </div>
                        </div>
                        <div className="trackLineNumbersNew">
                            <div className="trackLineNumNew">1.0</div>
                            <div className="trackLineNumNew">0.5</div>
                            <div className="trackLineNumNew">0.0</div>
                            <div className="trackLineNumNew">-0.5</div>
                            <div className="trackLineNumNew">-1.0</div>
                        </div>
                        <div className="trackLinesNew">
                            {/* Do NOT delete the letter 'a' below. It is used for styling purposes.
                            It is hidden. You can append text or numbers to it. */}
                            <div className="trackLineSingleNew">a</div>
                            <div className="trackLineSingleNew">a</div>
                            <div className="trackLineSingleNew">a</div>
                            <div className="trackLineSingleNew">a</div>
                            <div className="trackLineSingleNew">a</div>
                        </div>
                    </div>
                    <div className="tracksNew">
                        <div className="trackLabelsNew">
                            <div className="trackLabelNewTrackName">#1 - [Name]</div>
                            <div className="trackLabelNewMContainer">
                                <button className="trackLabelMBtn">M</button>
                                <button className="trackLabelDeleteBtn">Delete</button>
                            </div>
                            <div className="trackLabelNewSContainer">
                                <button className="trackLabelSBtn">S</button>
                                <button className="trackLabelNotesBtn">Notes</button>
                            </div>
                        </div>
                        <div className="trackLineNumbersNew">
                            <div className="trackLineNumNew">1.0</div>
                            <div className="trackLineNumNew">0.5</div>
                            <div className="trackLineNumNew">0.0</div>
                            <div className="trackLineNumNew">-0.5</div>
                            <div className="trackLineNumNew">-1.0</div>
                        </div>
                        <div className="trackLinesNew">
                            
                            <div className="trackLineSingleNew">a</div>
                            <div className="trackLineSingleNew">a</div>
                            <div className="trackLineSingleNew">a</div>
                            <div className="trackLineSingleNew">a</div>
                            <div className="trackLineSingleNew">a</div>
                        </div>
                    </div>
                    <div className="tracksNew">
                        <div className="trackLabelsNew">
                            <div className="trackLabelNewTrackName">#1 - [Name]</div>
                            <div className="trackLabelNewMContainer">
                                <button className="trackLabelMBtn">M</button>
                                <button className="trackLabelDeleteBtn">Delete</button>
                            </div>
                            <div className="trackLabelNewSContainer">
                                <button className="trackLabelSBtn">S</button>
                                <button className="trackLabelNotesBtn">Notes</button>
                            </div>
                        </div>
                        <div className="trackLineNumbersNew">
                            <div className="trackLineNumNew">1.0</div>
                            <div className="trackLineNumNew">0.5</div>
                            <div className="trackLineNumNew">0.0</div>
                            <div className="trackLineNumNew">-0.5</div>
                            <div className="trackLineNumNew">-1.0</div>
                        </div>
                        <div className="trackLinesNew">
                            
                            <div className="trackLineSingleNew">a</div>
                            <div className="trackLineSingleNew">a</div>
                            <div className="trackLineSingleNew">a</div>
                            <div className="trackLineSingleNew">a</div>
                            <div className="trackLineSingleNew">a</div>
                        </div>
                    </div>
                </div>
            </div>
            <a href="javascript:void(0)" id="closeMixerNew" onClick={closeMixerNew}>&times;</a>
        </div>
    )

}