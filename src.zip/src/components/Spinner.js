
const Spinner = () => {

    return (
        <div>
            <div className="spinner-border text-info" style={{width: '100px', height: '100px'}}></div>
        </div>
    )

}