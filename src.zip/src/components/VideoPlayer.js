
const VideoPlayer = (props) => {

    React.useEffect(() => {
        // before unmounting the component
        return function cleanup() {
            //disposing the video js player is exists
            // const videos = document.getElementsByClassName('video-js');
            // for (let vid of videos) {
            //     console.log("disposing video")
            //     const id = vid.id;
            //     const thisVideo = videojs(id);
            //     thisVideo.dispose();
            // }
            try {
                const thisVideo = videojs(props.id);
                thisVideo.dispose();
            } catch (error) {
                
            }
        }
    }, []);

    React.useEffect(() => {

        const thisVideo = videojs(props.id);
        if (props.src) {
            thisVideo.src({ type: 'video/webm', src: props.src });
        }

        thisVideo.play().then(() => {
            thisVideo.pause();
            thisVideo.currentTime(0);
        });

    }, []);

    return (
        <div className="videoplayer">
            <video muted id={props.id} className="video-js vjs-theme-city vjs-4-3 videoGridVideo" width={props.width} height={props.height} controls={props.controls?true:false} data-setup='{"fluid": true}'>
                <source src={props.src} type="video/webm"></source>
            </video>
        </div>
    )

}