
const Form = () => {

    const [count, setCount] = React.useState(0);
    const {appMode, setAppMode} = React.useContext(MainContext);

    const clickHandler = () => {
        setCount(count+1);
    }

    const toggleModeHandler = () => {
        if (appMode == "LOGIN") setAppMode("LOGOUT")
        else setAppMode("LOGIN");
    }

    return (
        <div>
            <h1>Hello Testing</h1>
            <button onClick={toggleModeHandler}>Toggle Mode</button>
            <h2>Count: {count}</h2>
            <button onClick={clickHandler}>Click</button>
        </div>
    );
}
