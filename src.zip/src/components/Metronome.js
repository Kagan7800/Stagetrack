
const Metronome = (props) => {

    const {
        shareClickWithPeers,
    } = React.useContext(SessionContext);

    // Metronome function

    var bpmCounterRunPractice;
    function bpmBeanCounterPractice() {
        var timeSigSelectionAlt;
        var i = 1;
        var element1;
        var element2;
        var element3;
        var element4;
        var bpmValueAlt;
        timeSigSelectionAlt = document.getElementById("timeSigSelectAlt").value;
        bpmValueAlt = parseInt(document.getElementById("newRecordingBPMNumAlt").value);

        if (isNaN(bpmValueAlt)) {
            bpmCounterRunPractice = false;
        }

        var timeTracker = 60 / bpmValueAlt * 1000;
        var x = setInterval(leadTimeCounter, timeTracker);

        function leadTimeCounter() {
            if (bpmCounterRunPractice == true && timeSigSelectionAlt == 4) {
                switch (i) {
                    case 1:
                        element1 = document.getElementById("bpmCounter1Alt");
                        element1.classList.add("newFourActive");
                        element4 = document.getElementById("bpmCounter4Alt");
                        element4.classList.remove("newFourActive");
                        i++;
                        break;
                    case 2:
                        element1 = document.getElementById("bpmCounter1Alt");
                        element1.classList.remove("newFourActive");
                        element2 = document.getElementById("bpmCounter2Alt");
                        element2.classList.add("newFourActive");
                        i++;
                        break;
                    case 3:
                        element2 = document.getElementById("bpmCounter2Alt");
                        element2.classList.remove("newFourActive");
                        element3 = document.getElementById("bpmCounter3Alt");
                        element3.classList.add("newFourActive");
                        i++;
                        break;
                    case 4:
                        element3 = document.getElementById("bpmCounter3Alt");
                        element3.classList.remove("newFourActive");
                        element4 = document.getElementById("bpmCounter4Alt");
                        element4.classList.add("newFourActive");
                        i = 1;
                        break;
                }
            } else if (bpmCounterRunPractice == true && timeSigSelectionAlt == 8) {
                switch (i) {
                    case 1:
                        element1 = document.getElementById("bpmCounter1Alt");
                        element1.classList.add("newFourActive");
                        element4 = document.getElementById("bpmCounter4Alt");
                        element4.classList.remove("newFourActive");
                        element4.classList.remove("bpmCounterNumTransformed");
                        document.getElementById("bpmCounter4EAlt").style.display = "none";
                        i++;
                        break;
                    case 2:
                        element1 = document.getElementById("bpmCounter1Alt");
                        element1.classList.add("bpmCounterNumTransformed");
                        document.getElementById("bpmCounter1EAlt").style.display = "block";
                        i++;
                        break;
                    case 3:
                        element1 = document.getElementById("bpmCounter1Alt");
                        element1.classList.remove("newFourActive");
                        element1.classList.remove("bpmCounterNumTransformed");
                        document.getElementById("bpmCounter1EAlt").style.display = "none";
                        element2 = document.getElementById("bpmCounter2Alt");
                        element2.classList.add("newFourActive");
                        i++;
                        break;
                    case 4:
                        element2 = document.getElementById("bpmCounter2Alt");
                        element2.classList.add("bpmCounterNumTransformed");
                        document.getElementById("bpmCounter2EAlt").style.display = "block";
                        i++;
                        break;
                    case 5:
                        element2 = document.getElementById("bpmCounter2Alt");
                        element2.classList.remove("newFourActive");
                        element2.classList.remove("bpmCounterNumTransformed");
                        document.getElementById("bpmCounter2EAlt").style.display = "none";
                        element3 = document.getElementById("bpmCounter3Alt");
                        element3.classList.add("newFourActive");
                        i++;
                        break;
                    case 6:
                        element2 = document.getElementById("bpmCounter3Alt");
                        element3.classList.add("bpmCounterNumTransformed");
                        document.getElementById("bpmCounter3EAlt").style.display = "block";
                        i++;
                        break;
                    case 7:
                        element3 = document.getElementById("bpmCounter3Alt");
                        element3.classList.remove("newFourActive");
                        element3.classList.remove("bpmCounterNumTransformed");
                        document.getElementById("bpmCounter3EAlt").style.display = "none";
                        element4 = document.getElementById("bpmCounter4Alt");
                        element4.classList.add("newFourActive");
                        i++;
                        break;
                    case 8:
                        element4 = document.getElementById("bpmCounter4Alt");
                        element4.classList.add("bpmCounterNumTransformed");
                        document.getElementById("bpmCounter4EAlt").style.display = "block";
                        i = 1;
                        break;
                }
            } else if (bpmCounterRunPractice == true && timeSigSelectionAlt == 12) {
                switch (i) {
                    case 1:
                        element1 = document.getElementById("bpmCounter1Alt");
                        element1.classList.add("newFourActive");
                        element4 = document.getElementById("bpmCounter4Alt");
                        element4.classList.remove("newFourActive");
                        element4.classList.remove("bpmCounterNumTransformed");
                        document.getElementById("bpmCounter4EAlt").style.display = "none";
                        document.getElementById("bpmCounter4AndAlt").style.display = "none";
                        i++;
                        break;
                    case 2:
                        element1 = document.getElementById("bpmCounter1Alt");
                        element1.classList.add("bpmCounterNumTransformed");
                        document.getElementById("bpmCounter1EAlt").style.display = "block";
                        i++;
                        break;
                    case 3:
                        document.getElementById("bpmCounter1AndAlt").style.display = "block";
                        i++;
                        break;
                    case 4:
                        element1 = document.getElementById("bpmCounter1Alt");
                        element1.classList.remove("newFourActive");
                        element1.classList.remove("bpmCounterNumTransformed");
                        document.getElementById("bpmCounter1EAlt").style.display = "none";
                        document.getElementById("bpmCounter1AndAlt").style.display = "none";
                        element2 = document.getElementById("bpmCounter2Alt");
                        element2.classList.add("newFourActive");
                        i++;
                        break;
                    case 5:
                        element2 = document.getElementById("bpmCounter2Alt");
                        element2.classList.add("bpmCounterNumTransformed");
                        document.getElementById("bpmCounter2EAlt").style.display = "block";
                        i++;
                        break;
                    case 6:
                        document.getElementById("bpmCounter2AndAlt").style.display = "block";
                        i++;
                        break;
                    case 7:
                        element2 = document.getElementById("bpmCounter2Alt");
                        element2.classList.remove("newFourActive");
                        element2.classList.remove("bpmCounterNumTransformed");
                        document.getElementById("bpmCounter2EAlt").style.display = "none";
                        document.getElementById("bpmCounter2AndAlt").style.display = "none";
                        element3 = document.getElementById("bpmCounter3Alt");
                        element3.classList.add("newFourActive");
                        i++;
                        break;
                    case 8:
                        element2 = document.getElementById("bpmCounter3Alt");
                        element3.classList.add("bpmCounterNumTransformed");
                        document.getElementById("bpmCounter3EAlt").style.display = "block";
                        i++;
                        break;
                    case 9:
                        document.getElementById("bpmCounter3AndAlt").style.display = "block";
                        i++;
                        break;
                    case 10:
                        element3 = document.getElementById("bpmCounter3Alt");
                        element3.classList.remove("newFourActive");
                        element3.classList.remove("bpmCounterNumTransformed");
                        document.getElementById("bpmCounter3EAlt").style.display = "none";
                        document.getElementById("bpmCounter3AndAlt").style.display = "none";
                        element4 = document.getElementById("bpmCounter4Alt");
                        element4.classList.add("newFourActive");
                        i++;
                        break;
                    case 11:
                        element4 = document.getElementById("bpmCounter4Alt");
                        element4.classList.add("bpmCounterNumTransformed");
                        document.getElementById("bpmCounter4EAlt").style.display = "block";
                        i++;
                        break;
                    case 12:
                        document.getElementById("bpmCounter4AndAlt").style.display = "block";
                        i = 1;
                        break;
                }
            } else if (bpmCounterRunPractice == true && timeSigSelectionAlt == 16) {
                switch (i) {
                    case 1:
                        element1 = document.getElementById("bpmCounter1Alt");
                        element1.classList.add("newFourActive");
                        element4 = document.getElementById("bpmCounter4Alt");
                        element4.classList.remove("newFourActive");
                        element4.classList.remove("bpmCounterNumTransformed");
                        document.getElementById("bpmCounter4EAlt").style.display = "none";
                        document.getElementById("bpmCounter4AndAlt").style.display = "none";
                        document.getElementById("bpmCounter4AAlt").style.display = "none";
                        i++;
                        break;
                    case 2:
                        element1 = document.getElementById("bpmCounter1Alt");
                        element1.classList.add("bpmCounterNumTransformed");
                        document.getElementById("bpmCounter1EAlt").style.display = "block";
                        i++;
                        break;
                    case 3:
                        document.getElementById("bpmCounter1AndAlt").style.display = "block";
                        i++;
                        break;
                    case 4:
                        document.getElementById("bpmCounter1AAlt").style.display = "block";
                        i++;
                        break;
                    case 5:
                        element1 = document.getElementById("bpmCounter1Alt");
                        element1.classList.remove("newFourActive");
                        element1.classList.remove("bpmCounterNumTransformed");
                        document.getElementById("bpmCounter1EAlt").style.display = "none";
                        document.getElementById("bpmCounter1AndAlt").style.display = "none";
                        document.getElementById("bpmCounter1AAlt").style.display = "none";
                        element2 = document.getElementById("bpmCounter2Alt");
                        element2.classList.add("newFourActive");
                        i++;
                        break;
                    case 6:
                        element2 = document.getElementById("bpmCounter2Alt");
                        element2.classList.add("bpmCounterNumTransformed");
                        document.getElementById("bpmCounter2EAlt").style.display = "block";
                        i++;
                        break;
                    case 7:
                        document.getElementById("bpmCounter2AndAlt").style.display = "block";
                        i++;
                        break;
                    case 8:
                        document.getElementById("bpmCounter2AAlt").style.display = "block";
                        i++;
                        break;
                    case 9:
                        element2 = document.getElementById("bpmCounter2Alt");
                        element2.classList.remove("newFourActive");
                        element2.classList.remove("bpmCounterNumTransformed");
                        document.getElementById("bpmCounter2EAlt").style.display = "none";
                        document.getElementById("bpmCounter2AndAlt").style.display = "none";
                        document.getElementById("bpmCounter2AAlt").style.display = "none";
                        element3 = document.getElementById("bpmCounter3Alt");
                        element3.classList.add("newFourActive");
                        i++;
                        break;
                    case 10:
                        element2 = document.getElementById("bpmCounter3Alt");
                        element3.classList.add("bpmCounterNumTransformed");
                        document.getElementById("bpmCounter3EAlt").style.display = "block";
                        i++;
                        break;
                    case 11:
                        document.getElementById("bpmCounter3AndAlt").style.display = "block";
                        i++;
                        break;
                    case 12:
                        document.getElementById("bpmCounter3AAlt").style.display = "block";
                        i++;
                        break;
                    case 13:
                        element3 = document.getElementById("bpmCounter3Alt");
                        element3.classList.remove("newFourActive");
                        element3.classList.remove("bpmCounterNumTransformed");
                        document.getElementById("bpmCounter3EAlt").style.display = "none";
                        document.getElementById("bpmCounter3AndAlt").style.display = "none";
                        document.getElementById("bpmCounter3AAlt").style.display = "none";
                        element4 = document.getElementById("bpmCounter4Alt");
                        element4.classList.add("newFourActive");
                        i++;
                        break;
                    case 14:
                        element4 = document.getElementById("bpmCounter4Alt");
                        element4.classList.add("bpmCounterNumTransformed");
                        document.getElementById("bpmCounter4EAlt").style.display = "block";
                        i++;
                        break;
                    case 15:
                        document.getElementById("bpmCounter4AndAlt").style.display = "block";
                        i++;
                        break;
                    case 16:
                        document.getElementById("bpmCounter4AAlt").style.display = "block";
                        i = 1;
                        break;
                }
            } else {
                clearInterval(x);
                document.getElementById("newRecordingBPMNumAlt").value = "";
                document.getElementById("timeSigSelectAlt").value = "4";
                element1.classList.remove("newFourActive");
                element1.classList.remove("bpmCounterNumTransformed");
                document.getElementById("bpmCounter1EAlt").style.display = "none";
                document.getElementById("bpmCounter1AndAlt").style.display = "none";
                document.getElementById("bpmCounter1AAlt").style.display = "none";
                element2.classList.remove("newFourActive");
                element2.classList.remove("bpmCounterNumTransformed");
                document.getElementById("bpmCounter2EAlt").style.display = "none";
                document.getElementById("bpmCounter2AndAlt").style.display = "none";
                document.getElementById("bpmCounter2AAlt").style.display = "none";
                element3.classList.remove("newFourActive");
                element3.classList.remove("bpmCounterNumTransformed");
                document.getElementById("bpmCounter3EAlt").style.display = "none";
                document.getElementById("bpmCounter3AndAlt").style.display = "none";
                document.getElementById("bpmCounter3AAlt").style.display = "none";
                element4.classList.remove("newFourActive");
                element4.classList.remove("bpmCounterNumTransformed");
                document.getElementById("bpmCounter4EAlt").style.display = "none";
                document.getElementById("bpmCounter4AndAlt").style.display = "none";
                document.getElementById("bpmCounter4AAlt").style.display = "none";
                bpmCounterRunPractice = false;
                bpmValueAlt = "";
            }
        }
    }
    
    function closeMetronome() {
        document.getElementById("metronomePanel").style.display = "none";
        metronomePanelSwitch(2);
        bpmCounterRunPractice = false;
        bpmBeanCounterPractice();
    }

    function metronomePanelSwitch(x) {
        if (x == 1) {
            // when metronome starts
            document.getElementById("metronomePanelOne").style.display = "none";
            document.getElementById("metronomePanelTwo").style.display = "flex";
            bpmCounterRunPractice = true;
            bpmBeanCounterPractice();

            document.getElementById("metronomePanel").style.position = 'relative';
            document.getElementById("metronomePanel").style.top = '0';
            document.getElementById("metronomePanel").style.height = 'auto';
            document.getElementById("metronomePanelTwo").style.height = 'auto';
            document.getElementById("newRecordingPanelSixBLeftAlt").style.margin = '0';
            
        } else {
            // when metronome stops
            document.getElementById("metronomePanelOne").style.display = "flex";
            document.getElementById("metronomePanelTwo").style.display = "none";
            bpmCounterRunPractice = false;
            bpmBeanCounterPractice();
            document.getElementById("metronomePanel").style.position = 'absolute';
            document.getElementById("metronomePanel").style.top = '75px';
            document.getElementById("metronomePanel").style.height = '400px';
            document.getElementById("metronomePanelTwo").style.height = '400px';
            document.getElementById("newRecordingPanelSixBLeftAlt").style.margin = '10% 0 20px 0'
        }
    }

    return(
        <div id="metronomePanel">
            <div id="metronomePanelOne">
                <div className="metronomePanelOuterContainer">
                    <div id="newRecordingPanelTwoInnerContainerRight">
                        <h5>Metronome</h5>
                        <div id="newRecordingBPMLabel">BPM</div>
                        <input type="text" id="newRecordingBPMNumAlt"></input>
    
                        <h4>Time Signature</h4>
                        <div id="newRecordingTimeSignatureContainer">
                            <select name="timeSigSelect" id="timeSigSelectAlt" className="newRecordingTimeSignatureNum" >
                                <option value="4">4</option>
                                <option value="8">8</option>
                                <option value="12">12</option>
                                <option value="16">16</option>
                            </select>
                            <div id="newRecordingSlash">/</div>
                            <select className="newRecordingTimeSignatureNum" >
                                <option value="4">4</option>
                            </select>
                        </div>
                    </div>
                </div>
                <button className="metronomeNavBtns" onClick={() => metronomePanelSwitch(1)}>Next</button>
            </div>
            <div id="metronomePanelTwo">
                <div id="newRecordingPanelSixBLeftAlt">
                    <div>
                        <h5 id="bpmCounter1Alt">1</h5>
                        <p className="bpmCounterAddonsE" id="bpmCounter1EAlt">e</p>
                        <p className="bpmCounterAddonsAnd" id="bpmCounter1AndAlt">&</p>
                        <p className="bpmCounterAddonsA" id="bpmCounter1AAlt">a</p>
                    </div>
                    <div>
                        <h5 id="bpmCounter2Alt">2</h5>
                        <p className="bpmCounterAddonsE" id="bpmCounter2EAlt">e</p>
                        <p className="bpmCounterAddonsAnd" id="bpmCounter2AndAlt">&</p>
                        <p className="bpmCounterAddonsA" id="bpmCounter2AAlt">a</p>
                    </div>
                    <div>
                        <h5 id="bpmCounter3Alt">3</h5>
                        <p className="bpmCounterAddonsE" id="bpmCounter3EAlt">e</p>
                        <p className="bpmCounterAddonsAnd" id="bpmCounter3AndAlt">&</p>
                        <p className="bpmCounterAddonsA" id="bpmCounter3AAlt">a</p>
                    </div>
                    <div>
                        <h5 id="bpmCounter4Alt">4</h5>
                        <p className="bpmCounterAddonsE" id="bpmCounter4EAlt">e</p>
                        <p className="bpmCounterAddonsAnd" id="bpmCounter4AndAlt">&</p>
                        <p className="bpmCounterAddonsA" id="bpmCounter4AAlt">a</p>
                    </div>
                </div>                                         
                <button className="metronomeNavBtns" onClick={() => metronomePanelSwitch(2)}>Back</button>
            </div>

            <a href="javascript:void(0)" id="closeMetronome" onClick={() => {closeMetronome(); shareClickWithPeers("closeMetronome")}}>&times;</a>
        </div>
    )

}