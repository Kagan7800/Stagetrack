
const RecordMenu = (props) => {

    const {startLoader, endLoader, allVideos, setNewTracks, newTracks} = React.useContext(MainContext);

    const [newAudioName, setNewAudioName] = React.useState(getDateString());

    function getDateString() {
        const date = new Date();
        const year = date.getFullYear();
        const month = `${date.getMonth() + 1}`.padStart(2, '0');
        const day =`${date.getDate()}`.padStart(2, '0');
        return `${year}-${month}-${day}-${date.getHours()}:${date.getMinutes()}:${date.getSeconds()}`
    }

    // private handlers
    const checkNewAudioName = (name) => {
        const names = playlist.tracks.map(t => t.name);
        const videoNames = allVideos.map(vid => vid.name);
        if (name == '') return false;
        if (names.indexOf(name) !== -1) {
            return false
        }
        if (videoNames.indexOf(name) !== -1) {
            return false
        }
        return true;
    }

    const addAudioHandler = async () => {
        //adds video along with its audio track to the song
        //get the video blob, extract audio, save the audio into newTracks and load into playlist, 
        //save video into newVideos, and load into the video views
        startLoader();
        if (checkNewAudioName(newAudioName)) {

            //create track id from name by removing existing spaces
            const nameSplit = newAudioName.split(' ');
            var TrackId = '';
            for (let substr of nameSplit) {
                TrackId += substr;
            }

            setNewTracks([...newTracks, {blob: props.newAudioBlob, name: newAudioName.trim(), id: TrackId}]);

            //load audio
            playlist.load([
                {
                    "src": props.newAudioBlob,
                    "name": newAudioName.trim(),
                }
            ]).then(() => {
                endLoader();
                playlist.initExporter();
            });
            
            //video is already added from the upadate in allVideos global array. Videos in editSong comp are updated as listening to
            // allVideos
            props.close();



        }
        else {
            endLoader();
            window.alert('Invalid Video Name!');
        }

    }

    return (
        <div id="recordMenu" className="recordMenu">
            <div className="container">
                <button type="button" className="close float-right" data-dismiss="modal" aria-label="Close" style={{margin: '20px'}} onClick={() => props.updateShowAudioCaptureMenu(false)}>
                    <span aria-hidden="true">&times;</span>
                </button>
                <div id="recordingPopup" className="recordingPopup">

                    <div id="recordTrackName" style={{ maring: '25px' }}>
                        <input type="text" id="inp-recordTrackName" placeholder="Enter unique track name" value={newAudioName} onChange={(e) => setNewAudioName(e.target.value)}></input>
                    </div>

                    <div className="flexHor">
                        <button id="btn-addVideo" type="button" className="btn btn-primary flexItem" onClick={addAudioHandler}>Add Audio</button>
                    </div>
                </div>
            </div>
        </div>
    )

}