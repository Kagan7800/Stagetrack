
const YellowBox = (props) => {

    const {
        createNote,
        openedResource,
        setOpenedResource,
        ybMode,
        setYbMode,
        stopUserDisplayStream,
    } = React.useContext(MainContext);

    const {
        thisSessionData,
        broadcast,
        note,
        setNote,
        remoteUserDisplay,
        setRemoteUserDisplay,
        shareScreen,
    } = React.useContext(SessionContext);

    const [url, setUrl] = React.useState("");

    var docFileFormats = ['pdf', 'odf'];
    var imageFileFormats = ['png', 'jpg', 'gif'];
    var videoFileFormats = ['mp4', 'webm', 'avi', 'AVI'];

    const broadCastNote = () => {
        const body = document.getElementById('newContentTextarea').value;
        broadcast({
            type: "SETNOTE",
            body: body,
        });

    }

    const keepNoteHandler = () => {
        // save the note
        var title = window.prompt("Please provide title for the note");
        if (title !== null && title !== "") {
            title = title.trim();
            if (thisSessionData !== null) {
                createNote(thisSessionData.bandId, {title, body: note});
            }
        }
    }

    React.useEffect(() => {

        if (openedResource) {
            const name = openedResource.name;
            const nameSplit = name.split(".");
            if (docFileFormats.includes(nameSplit[nameSplit.length-1])) {
                setYbMode("DOC");
            }
            if (imageFileFormats.includes(nameSplit[nameSplit.length-1])) {
                setYbMode("IMAGE");
            }
            if (videoFileFormats.includes(nameSplit[nameSplit.length-1])) {
                setYbMode("VIDEO")
            }

            // broadcast({
            //     type: 'OPENEDRESOURCE',
            //     openedResource: openedResource,
            // })

        }

    }, [openedResource]);

    const resourcesClickHandler = () => {
        document.getElementById('btn-resourceLibrary').click(); 
        if (openedResource) {
            const name = openedResource.name;
            const nameSplit = name.split(".");
            if (docFileFormats.includes(nameSplit[nameSplit.length-1])) {
                setYbMode("DOC");
            }
            if (imageFileFormats.includes(nameSplit[nameSplit.length-1])) {
                setYbMode("IMAGE");
            }
            if (videoFileFormats.includes(nameSplit[nameSplit.length-1])) {
                setYbMode("VIDEO")
            }
        }
    }

    const urlClickHandler = () => {
        const url = window.prompt("URL");
        if (url !== null && url !== "") {
            setUrl(url);
        }
        setYbMode("URL");
    }

    const shareScreenHandler = () => {
        if (remoteUserDisplay) {
            stopUserDisplayStream(remoteUserDisplay.stream);
        }
        setYbMode("SCREENSHARE");
        shareScreen();
    }

    const openPopup = () => {
        document.getElementById('blur').style.display = 'block';
        document.getElementById('yellowBox').classList.add("yb-popup");
    }

    const closePopup = () => {
        setOpenedResource(null);
        setYbMode("NOTES");
        document.getElementById('blur').style.display = 'none';
        document.getElementById('yellowBox').classList.remove("yb-popup");
    }

    // handling collapsing animation
    $('#yb-left-collapsible').on('show.bs.collapse', function () {
        // make button invisible and make close butotn visible
        document.getElementById("open-yb-left").style.display = 'none';
        document.getElementById("close-yb-left").style.display = 'block';
    });
    $('#yb-left-collapsible').on('hidden.bs.collapse', function () {
        // make button invisible and make close butotn visible
        document.getElementById("open-yb-left").style.display = 'block';
        document.getElementById("close-yb-left").style.display = 'none';
    })

    React.useEffect(() => {
        document.getElementById('yb-right').addEventListener('click', () => {
            $("#yb-left-collapsible").collapse('hide');
        });
    }, []);

    React.useEffect(() => {
        if (ybMode == "SCREENSHARE") {
            const container = document.getElementById("remoteUserDisplay");
            if (container) {
                if (remoteUserDisplay) {
                    container.srcObject = remoteUserDisplay.stream;
                    remoteUserDisplay.stream.getVideoTracks()[0].addEventListener('ended', () => {
                        setRemoteUserDisplay(null);
                    });
                }
                else container.srcObject = null;
            }
        }
    }, [ybMode, remoteUserDisplay]);



    return (
        <div className="flexHor" id="yellowBox">
            <a href="javascript:void(0)" style={{position: 'absolute', top: '0px', left: '100%', fontSize: '32px', color:'red'}} onClick={closePopup}>&times;</a>

            <button id="open-yb-left" className="btn btn-outline-secondary btn-sm" type="button" data-toggle="collapse" data-target="#yb-left-collapsible" aria-expanded="false" aria-controls="collapseExample">
                &#9776;
            </button>

            <div className="collapse width" id="yb-left-collapsible">
                <a id="close-yb-left" href="javascript:void(0)" className="closebtn float-right" onClick={() => $("#yb-left-collapsible").collapse('hide')}></a>
                <a href="javascript:void(0)" className="float-left" style={{fontSize: '18px', color:'blue', position: 'relative', zIndex: '100'}} onClick={openPopup}>&#9744;</a>
                <div className="flexVer" id="yb-left">
                    <div className="flexItem flexVer" style={{borderBottom: '1px solid gray', width: '90%'}}>
                        <h6>
                            {
                                ybMode == "NOTES"?
                                "Notes"
                                : null
                            }
                            {
                                ybMode == "IMAGE" || ybMode == "DOC"?
                                "Resources"
                                : null
                            }
                            {
                                ybMode == "WHITEBOARD"?
                                "Whiteboard"
                                : null
                            }
                            {
                                ybMode == "SCREENSHARE"?
                                "Share Screen"
                                : null
                            }
                        </h6>
                    </div>
                    
                    {/* open item name */}
                    {
                        ybMode == "DOC" || ybMode == "IMAGE" || ybMode == "VIDEO"?
                            <div className="flexItem flexHor">
                                <div style={{margin: '2px'}}>
                                    <p style={{color: 'red'}} onClick={closePopup} className="yb-btn">&times;</p>
                                </div>
                                <div style={{overflowWrap: 'anywhere'}} className="flexItem">
                                    <p>{openedResource.name}</p>
                                </div>
                            </div>
                        : null
                    }

                    <div className="flexItem flexVer">
                        <div>
                            <p style={{color: 'gray', fontWeight: '600', fontSize: '14px'}} className="yb-btn" onClick={() => {document.getElementById('btn-notes').click(); setYbMode("NOTES")}}>Notes</p>
                        </div>
                        <div>
                            <p style={{color: 'gray', fontWeight: '600', fontSize: '14px'}} className="yb-btn" onClick={() => {resourcesClickHandler();}}>Resources</p>
                        </div>
                        <div>
                            <p style={{color: 'gray', fontWeight: '600', fontSize: '14px'}} className="yb-btn" onClick={() => document.getElementById('btn-songLibrary').click()}>Songs</p>
                        </div>
                        <div>
                            <p style={{color: 'gray', fontWeight: '600', fontSize: '14px'}} className="yb-btn" onClick={urlClickHandler}>URL</p>
                        </div>
                        <div>
                            <p style={{color: 'gray', fontWeight: '600', fontSize: '14px'}} className="yb-btn" onClick={() => setYbMode("WHITEBOARD")}>Whiteboard</p>
                        </div>
                        <div>
                            <p style={{color: 'gray', fontWeight: '600', fontSize: '14px'}} className="yb-btn" onClick={() => setYbMode("SCREENSHARE")}>Share Screen</p>
                        </div>
                        {
                            ybMode == "NOTES"?
                                <div>
                                    <p onClick={keepNoteHandler} style={{color: 'gray', fontWeight: '600', fontSize: '14px'}} className="yb-btn">Save</p>
                                </div>
                            : null
                        }
                    </div>
                </div>
            </div>
            
            <div style={{padding: '10px'}} id="yb-right">

                {
                    ybMode == "NOTES"?
                        <div>
                            <textarea value={note} onChange={(e) => {setNote(e.target.value); broadCastNote()}} id="newContentTextarea" placeholder="..."></textarea>
                        </div>
                    : null
                }
                {
                    ybMode == "DOC"?
                        <div id="pdfViewerWrapper">
                            <iframe id="pdfViewer" src = {`../ViewerJS/#${openedResource.url}`} width='100%' height='100%' allowFullScreen webkitallowfullscreen="true"></iframe>
                        </div>
                    : null
                }
                {
                    ybMode == "IMAGE"?
                        <div>
                            <img src={openedResource.url} style={{width: '100%', height: '100%'}}></img>
                        </div>
                    : null
                }
                {
                    ybMode == "VIDEO"?
                        <div>
                            <VideoPlayer id={"ybVideoResource"} src={openedResource.url} controls={true} />
                        </div>
                    : null
                }
                {
                    ybMode == "WHITEBOARD"?
                        <div>
                            <Draw/>
                        </div>
                    : null
                }
                {
                    ybMode == "URL"?
                        <div style={{width: '100%', height: '100%'}}>
                            <iframe src={url} style={{widht: '500px', height: '500px'}} title="URL"></iframe> 
                        </div>
                    : null
                }
                {
                    ybMode == "SCREENSHARE"?
                        
                        <div>
                            <button onClick={shareScreenHandler} type="button" class="btn btn-primary btn-sm">Share your screen</button>
                            <video class="streamVideo" style={{width: '100%'}} autoPlay id="remoteUserDisplay"></video>
                        </div>
                    : null
                }

            </div>
            
        </div>
    )

}