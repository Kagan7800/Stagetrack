var /**@const{!string}*/pdfjs_version = "v1.1.114";
